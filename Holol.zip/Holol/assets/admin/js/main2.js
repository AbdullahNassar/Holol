/*File Upload 
 =========================*/
$(document).ready(function () {
    "use strict";
    $("#image2").on("change", function () {
        document.getElementById("progressBar2").style.width = 0 + '%';
        document.getElementById("progressBar2").innerHTML = 0 + '%';
        $('.total-upload2').html('');
        $("#status2").html('');
        $(this).next("p").text($(this).val());
    });
});

/* Upload Progress Bar Script
 Script written by Adam Khoury @ DevelopPHP.com */
/* Video Tutorial: http://www.youtube.com/watch?v=EraNFJiY0Eg 
 ===============================*/
$(document).ready(function () {
    "use strict";
    
    var url=$('#url2').val();
    var storage=$('#storage2').val();
    function get_elment(el) {
        return document.getElementById(el);
    }
    function progressHandler(event) {
        get_elment("loaded_n_total2").innerHTML = "<span class='total-upload2'>Uploaded  " + event.loaded + " bytes of " + event.total + "</span>";
        var percent = (event.loaded / event.total) * 100;
        var rounPercent = get_elment("progressBar2").value = Math.round(percent);
        get_elment("progressBar2").style.width = rounPercent + '%';
        get_elment("progressBar2").innerHTML = rounPercent + '%';
        get_elment("status2").innerHTML = Math.round(percent) + "% uploaded...";
    }
    function completeHandler(event) {
        get_elment("status2").innerHTML = event.target.responseText;
        get_elment("progressBar2").value = 0;
        $("#upload-btn2").removeAttr("disabled");
//        cons
//        $("#img").val(event.success);

//        ;
//        alert(event.success);
    }
    function errorHandler(event) {

        get_elment("status2").innerHTML = "Upload Failed";
        $("#upload-btn2").removeAttr("disabled");
    }
    function abortHandler(event) {
        get_elment("status2").innerHTML = "Upload Aborted";
    }
    function uploadFile() {
        var file = get_elment("image2").files[0],
                formdata = new FormData(),
                ajax = new XMLHttpRequest();

        formdata.append("image2", file);
        formdata.append("_token", $('[name="csrf_token"]').attr('content'));
        formdata.append("storage", storage);
        


        ajax.upload.addEventListener("progress", progressHandler, false);
        ajax.addEventListener("load", completeHandler, false);
        ajax.addEventListener("error", errorHandler, false);
        ajax.addEventListener("abort", abortHandler, false);
        ajax.open("POST", url);
        ajax.send(formdata);
        ajax.onreadystatechange = function () {
            var response=JSON.parse(this.response);
//            console.log(response);
            if (this.readyState == 4 && this.status == 200) {
                $("#img2").val(response.success);
            }
        };
    }

    $('#upload-btn2').on('click', function () {
        uploadFile();
        $(this).attr("disabled", true);
    });
});
