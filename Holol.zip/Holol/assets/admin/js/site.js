
/**
 * 
 * admin-about
 */
(function ($) {


    "use strict";
    var fromabout = {
        initialized: false,
        initialize: function () {
            if (this.initialized)
                return;
            this.initialized = true;
            this.build();
            this.events();
        },
        build: function () {
            this.validations();
        },
        events: function () {},
        validations: function () {
            var fromabout = $(".admin-about"),
                    url = fromabout.attr("action");
            fromabout.validate({
                submitHandler: function (form) {
                    var submitButton = $(this.submitButton);
                    // submitButton.button("loading");
                    $.ajax({
                        method: "POST",
                        url: url,
                        data: $(form).serialize(),
                        dataType: "json",
                        success: function (data) {
                            if (data.status == "success") {


                                $(".alert-success").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-danger").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-success").stop().fadeOut().addClass("hidden");
//                                     window.open(data.url); 
                                    location.href = data.url;
                                }, 1000);
                                form.get[0].reset();
                            } else {

//                                $(".alert-danger").html(mess + '<br>' + data.data);
                                $(".alert-danger").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-success").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-danger").stop().fadeOut().addClass("hidden");

                                }, 1000);
                                form.get[0].reset();
                            }
                            form.get[0].reset();
                        },
                        complete: function () {
                            // submitButton.button("reset");
                        }
                    });
                },
                rules: {
                    abourTitlear: {
                        required: true
                    },
                    abourTitleen: {
                        required: true
                    },
                    abourContentar: {
                        required: true
                    },
                    abourContenten: {
                        required: true
                    },
                    abourOurVisionar: {

                        required: true
                    },
                    abourOurVisionen: {

                        required: true
                    },
                    abourOurMissionar: {

                        required: true
                    },
                    abourOurMissionen: {

                        required: true
                    },
                    abourPackageTitlear: {
                        required: true,

                    },
                    abourPackageTitleen: {
                        required: true,

                    },
                    abourPackageContentar: {
                        required: true,

                    },
                    abourPackageContenten: {
                        required: true,

                    }
                },
                highlight: function (element) {
                    $(element).parent().removeClass("has-success").addClass("has-error");
                    if (typeof $.fn.isotope !== 'undefined') {
                        $('.filter-elements').isotope('layout');
                    }
                },
                success: function (element) {
                    $(element).parent().removeClass("has-error").addClass("has-success").find("label.error").remove();
                }
            });
            $.ajaxSetup({
                headers: {

                    'csrf_token': $('[name="csrf_token"]').attr('content')
                }
            });
        }
    };
    fromabout.initialize();
})(jQuery);


/**
 * 
 * admin-contact
 */
(function ($) {


    "use strict";
    var fromcontact = {
        initialized: false,
        initialize: function () {
            if (this.initialized)
                return;
            this.initialized = true;
            this.build();
            this.events();
        },
        build: function () {
            this.validations();
        },
        events: function () {},
        validations: function () {
            var from = $(".admin-contact"),
                    url = from.attr("action");
            from.validate({
                submitHandler: function (form) {
                    var submitButton = $(this.submitButton);
                    // submitButton.button("loading");
                    $.ajax({
                        method: "POST",
                        url: url,
                        data: $(form).serialize(),
                        dataType: "json",
                        success: function (data) {
                            if (data.status == "success") {


                                $(".alert-success").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-danger").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-success").stop().fadeOut().addClass("hidden");
//                                     window.open(data.url); 
                                    location.href = data.url;
                                }, 1000);
                                form.get[0].reset();
                            } else {

//                                $(".alert-danger").html(mess + '<br>' + data.data);
                                $(".alert-danger").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-success").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-danger").stop().fadeOut().addClass("hidden");

                                }, 1000);
                                form.get[0].reset();
                            }
                            form.get[0].reset();
                        },
                        complete: function () {
                            // submitButton.button("reset");
                        }
                    });
                },
                rules: {
                    contactPhone: {
                        required: true
                    },
                    contactEmail: {
                        required: true
                    },
                    contactAddressar: {
                        required: true
                    },
                    contactAddressen: {
                        required: true
                    },
                    contactFacebook: {

                        required: true
                    },
                    contactTwiter: {

                        required: true
                    },
                    contactGmail: {

                        required: true
                    },
                    contactLinkedin: {

                        required: true
                    }
                },
                highlight: function (element) {
                    $(element).parent().removeClass("has-success").addClass("has-error");
                    if (typeof $.fn.isotope !== 'undefined') {
                        $('.filter-elements').isotope('layout');
                    }
                },
                success: function (element) {
                    $(element).parent().removeClass("has-error").addClass("has-success").find("label.error").remove();
                }
            });
            $.ajaxSetup({
                headers: {

                    'csrf_token': $('[name="csrf_token"]').attr('content')
                }
            });
        }
    };
    fromcontact.initialize();
})(jQuery);


/**
 * 
 * admin-servies
 */
(function ($) {


    "use strict";
    var fromservices = {
        initialized: false,
        initialize: function () {
            if (this.initialized)
                return;
            this.initialized = true;
            this.build();
            this.events();
        },
        build: function () {
            this.validations();
        },
        events: function () {},
        validations: function () {
            var fromabout = $(".form-services"),
                    url = fromabout.attr("action");
            fromabout.validate({
                submitHandler: function (form) {
                    var submitButton = $(this.submitButton);
                    // submitButton.button("loading");
                    $.ajax({
                        method: "POST",
                        url: url,
                        data: $(form).serialize(),
                        dataType: "json",
                        success: function (data) {
                            if (data.status == "success") {


                                $(".alert-success").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-danger").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-success").stop().fadeOut().addClass("hidden");
//                                     window.open(data.url); 
                                    location.href = data.url;
                                }, 1000);
                                form.get[0].reset();
                            } else {

//                                $(".alert-danger").html(mess + '<br>' + data.data);
                                $(".alert-danger").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-success").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-danger").stop().fadeOut().addClass("hidden");

                                }, 1000);
                                form.get[0].reset();
                            }
                            form.get[0].reset();
                        },
                        complete: function () {
                            // submitButton.button("reset");
                        }
                    });
                },
                rules: {
                    namear: {
                        required: true
                    },
                    nameen: {
                        required: true
                    },
                    contenten: {
                        required: true
                    },
                    contentar: {
                        required: true
                    },
                    _order: {

                        required: true
                    }
                },
                highlight: function (element) {
                    $(element).parent().removeClass("has-success").addClass("has-error");
                    if (typeof $.fn.isotope !== 'undefined') {
                        $('.filter-elements').isotope('layout');
                    }
                },
                success: function (element) {
                    $(element).parent().removeClass("has-error").addClass("has-success").find("label.error").remove();
                }
            });
            $.ajaxSetup({
                headers: {

                    'csrf_token': $('[name="csrf_token"]').attr('content')
                }
            });
        }
    };
    fromservices.initialize();
})(jQuery);


/**
 * 
 * admin-packages
 */
(function ($) {


    "use strict";
    var frompackages = {
        initialized: false,
        initialize: function () {
            if (this.initialized)
                return;
            this.initialized = true;
            this.build();
            this.events();
        },
        build: function () {
            this.validations();
        },
        events: function () {},
        validations: function () {
            var frompackages = $(".form-packages"),
                    url = frompackages.attr("action");
            frompackages.validate({
                submitHandler: function (form) {
                    var submitButton = $(this.submitButton);
                    // submitButton.button("loading");
                    $.ajax({
                        method: "POST",
                        url: url,
                        data: $(form).serialize(),
                        dataType: "json",
                        success: function (data) {
                            if (data.status == "success") {


                                $(".alert-success").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-danger").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-success").stop().fadeOut().addClass("hidden");
//                                     window.open(data.url); 
                                    location.href = data.url;
                                }, 1000);
                                form.get[0].reset();
                            } else {

//                                $(".alert-danger").html(mess + '<br>' + data.data);
                                $(".alert-danger").stop().removeClass("hidden").hide().fadeIn();
                                $(".alert-success").stop().addClass("hidden");
                                setTimeout(function () {
                                    $(".alert-danger").stop().fadeOut().addClass("hidden");

                                }, 1000);
                                form.get[0].reset();
                            }
                            form.get[0].reset();
                        },
                        complete: function () {
                            // submitButton.button("reset");
                        }
                    });
                },
                rules: {
                    namear: {
                        required: true
                    },
                    nameen: {
                        required: true
                    },
                    contenten: {
                        required: true
                    },
                    detailsar: {
                        required: true
                    },
                    detailsen: {

                        required: true
                    },
                    _order: {
                        required: true
                    },
                    residencar: {
                        required: true
                    },
                    residencen: {
                        required: true
                    },
                    package_program_namear: {
                        required: true
                    },
                    package_program_nameen: {

                        required: true
                    },
                    package_program_contentar: {
                        required: true
                    },
                    package_program_contenten: {
                        required: true
                    },
                    order: {
                        required: true
                    },
                    package_program_order: {

                        required: true
                    }, package_prices_num_per_ar: {
                        required: true
                    },
                    package_prices_num_per_en: {
                        required: true
                    },
                    package_prices_price: {
                        required: true
                    },
                    package_prices_order: {

                        required: true
                    }
                },
                highlight: function (element) {
                    $(element).parent().removeClass("has-success").addClass("has-error");
                    if (typeof $.fn.isotope !== 'undefined') {
                        $('.filter-elements').isotope('layout');
                    }
                },
                success: function (element) {
                    $(element).parent().removeClass("has-error").addClass("has-success").find("label.error").remove();
                }
            });
            $.ajaxSetup({
                headers: {

                    'csrf_token': $('[name="csrf_token"]').attr('content')
                }
            });
        }
    };
    frompackages.initialize();
})(jQuery);
(function ($) {
    Dropzone.options.imageUpload = {
        maxFilesize: 8000000,
        acceptedFiles: ".jpeg,.jpg,.png,.gif,.mp4,.webm,.mkv,.m4v",
        addRemoveLinks: true,
        init: function (file) {


            this.on("removedfile", function (file) {
                var url = 'deleteDropzoneImage';
                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {name: file.name, _token: $('#csrf-token').val()},
                    dataType: 'json',
                    success: function (data) {
                        document.getElementById('image_' + data.name).remove();

                    }
                });
            });
        },
        success: function (file, done) {
            $('#dropzone_image').append('<input id="image_' + file.name + '" type="hidden" name="image[]" value="' + done.success + '" />');
            // console.log(done.success);

        }
    };
})(jQuery);