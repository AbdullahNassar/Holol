<?php $__env->startSection('content'); ?>
<div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/icons/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> تواصل معنا <?php else: ?> Contact Us <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> تواصل معنا <?php else: ?> Contact Us <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->
                    <section class="section-md contact-fix contact-page">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="section-head">
                                        <h2 class="section-title">
                                        <?php if(Config::get('app.locale') == 'ar'): ?> تواصـــل معنــا <?php else: ?> Contact Us <?php endif; ?>
                                        </h2>
                                        <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('contacts')); ?> <?php else: ?> <?php echo e($data->get('contacts_en')); ?> <?php endif; ?>
                                        </p>
                                    </div>           
                                    <form class="form" method="post" action="<?php echo e(URL::to('/send')); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" name="first_name" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم الاول <?php else: ?> First Name <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" name="last_name" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم الاخير <?php else: ?> Last Name <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="email" name="email" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> البريد الالكتروني <?php else: ?> E-mail Address <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="tel" name="phone" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> رقم الهاتف <?php else: ?> Phone Number <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <textarea class="form-control" name="message" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> اكتب رسالتك <?php else: ?> Write Message <?php endif; ?>" rows="8" required></textarea>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button type="submit" class="custom-btn"><?php if(Config::get('app.locale') == 'ar'): ?> ارســــــــــــــال <?php else: ?> Send <?php endif; ?></button>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                            </div><!-- End row -->
                                        </form>
                                </div><!-- End col -->
                                <div class="col-md-5">
                                    <div class="section-img">
                                        <img src="<?php echo e(asset('assets/site/images/png.png')); ?>" alt="">
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>