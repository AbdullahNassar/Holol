<div class="header">
                <div class="top-header">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 col-xs-5">
                                <div class="head-contact">
                                    <button class="btn btn-responsive-nav" data-toggle="collapse" data-target=".contact-list">
                                        <i class="fa fa-bars"></i>
                                    </button>
                                    
                                    <ul class="contact-list collapse">
                                        <li>
                                            <i class="fa fa-phone"></i>
                                            <span><?php echo e($contact->get('phone')); ?></span>
                                        </li>
                                        <li>
                                            <i class="fa fa-envelope"></i>
                                            <span><?php echo e($contact->get('email')); ?></span>
                                        </li>
                                        <li>
                                            <i class="fa fa-map-marker"></i>
                                            <span><?php echo e($contact->get('address')); ?></span>
                                        </li>
                                    </ul><!-- End Contact-List -->
                                </div><!-- End Right-Side -->
                            </div><!-- End col -->
                            <div class="col-md-4 col-xs-7">
                                <div class="head-social">
                                    <ul class="social-list">
                                        <li>
                                            <a href="<?php echo e($contact->get('youtube')); ?>">
                                                <i class="fa fa-youtube"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('instagram')); ?>">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('google')); ?>">
                                                <i class="fa fa-google-plus"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('twitter')); ?>">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('facebook')); ?>">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                    </ul><!-- End Social-List -->
                                </div><!-- End Left-Side -->
                            </div><!-- End col -->
                        </div><!-- End row -->
                    </div><!-- End container -->
                </div><!-- End Top-Header -->
                <div class="container">
                    <a href="index.html" class="logo">
                        <img src="<?php echo e(asset('assets/site/images/Logo.png')); ?>" alt="logo-img">
                    </a>
                    <button class="btn btn-responsive-nav" data-toggle="collapse" data-target=".navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a href="<?php echo e(URL::to('/contact')); ?>" class="custom-btn">تواصل معنا</a>
                    
                </div><!-- End container -->
                <div class="navbar-collapse collapse">
                    <div class="container">
                        <nav class="nav-main">
                            <ul class="nav navbar-nav">
                                <li class="<?php if(Route::currentRouteName()=='site.home'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/')); ?>">الرئيسية</a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.about'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/about')); ?>">من نحن</a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.marks'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/marks')); ?>">العلامات التجارية</a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.products'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/products')); ?>">المنتجات</a></li>
                            </ul>
                        </nav><!-- End nav-main -->
                    </div><!-- End container -->
                </div><!-- End navbar-collapse -->
            </div><!-- End Header -->
