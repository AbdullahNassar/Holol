<?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="main">
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($package->title); ?>

                                            <?php else: ?>
                                            <?php echo e($package->title_en); ?>

                                            <?php endif; ?> 
                        </h2>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('site.home')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?>
                                        الرئيسية
                                        <?php else: ?>
                                        Home
                                        <?php endif; ?></a>
                                </li>
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('site.services')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?>
                                   خدماتنا
                                   <?php else: ?>
                                   Our Services
                                   <?php endif; ?></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($package->title); ?>

                                            <?php else: ?>
                                            <?php echo e($package->title_en); ?>

                                            <?php endif; ?>  
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div><!--End page head-->
                <div class="page-content">
                    <section class="section-md pattern-bg single-package">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="package-slider">
                                        <div id="slider" class="flexslider">
                                            <img src="<?php echo e(asset('assets/site/images/'.$package->image)); ?>">
                                        </div><!--End flexslider-->
                                    </div><!--End package-slider-->
                                </div><!-- End col-lg-6 -->
                                <div class="col-lg-6">
                                    <div class="package-detail">
                                        <div class="package-detail-head">
                                            <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($package->title); ?>

                                                        <?php else: ?>
                                                        <?php echo e($package->title_en); ?>

                                                        <?php endif; ?></h3>
                                            <span><?php if(Config::get('app.locale') == 'ar'): ?>
                                                        تبدأ من: 
                                                        <?php else: ?>
                                                        Starts From: 
                                                        <?php endif; ?></span>
                                            <span class="price">2800 
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        درهم 
                                                        <?php else: ?>
                                                        AED 
                                                        <?php endif; ?></span>
                                        </div><!-- End Package-Detail-Head -->
                                        <div class="package-detail-content">
                                            <p>
                                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($package->content); ?>

                                                        <?php else: ?>
                                                        <?php echo e($package->content_en); ?>

                                                        <?php endif; ?>
                                            </p>
                                            <ul class="feature-list">
                                                <li>
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        خدمات مميزة أثناء الرحلة
                                                        <?php else: ?>
                                                        Special services during the flight
                                                        <?php endif; ?>
                                                </li>
                                                <li>
                                                    
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        توفير كافة سبل الراحة
                                                        <?php else: ?>
                                                        Providing all comforts
                                                        <?php endif; ?>
                                                </li>
                                                <li>
                                                    
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        دقة فى تنفيذ برنامج الرحلة 
                                                        <?php else: ?>
                                                        Accuracy in the implementation of the flight program
                                                        <?php endif; ?>
                                                </li>
                                            </ul><!-- End Feature-List -->
                                        </div><!-- End Package-Detail-Content -->
                                    </div>
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <section class="section-md detail package-cont-detail">
                        <div class="container">
                            <div class="section-head">
                                <h3 class="title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        التفاصيل
                                                        <?php else: ?>
                                                        Details
                                                        <?php endif; ?>
                                </h3>
                            </div><!-- End Section-Head -->
                            <div class="section-content">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="trip-info">
                                            <p>
                                                 <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($package->details); ?>

                                                        <?php else: ?>
                                                         <?php echo e($package->details_en); ?>

                                                        <?php endif; ?>
                                            </p>
                                            <div class="trip-time">
                                                <h3  class="title">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        مواعيد الرحلة
                                                        <?php else: ?>
                                                        Flight Dates
                                                        <?php endif; ?>
                                                </h3>
                                                <p>
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        مدة الرحلة يومان لزيارة المناسك 
                                                        <?php else: ?>
                                                        Trip duration 2 days to visit the rites
                                                        <?php endif; ?>
                                                </p>
                                                <div class="trip-date">
                                                    <p>
                                                        <span>
                                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        الذهاب : 
                                                        <?php else: ?>
                                                        Going :
                                                        <?php endif; ?>
                                                        </span>
                                                          <?php echo e($package->date_from); ?>

                                                    </p>
                                                    <p>
                                                        <span>
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        العودة : 
                                                        <?php else: ?>
                                                        Back :
                                                        <?php endif; ?>
                                                        </span>
                                                        <?php echo e($package->date_to); ?>

                                                    </p>
                                                </div><!-- End-Times-->
                                            </div><!-- End Trip-Time -->
                                            <div class="package-price">
                                                <h3  class="title">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        اسعار الباقة
                                                        <?php else: ?>
                                                        Package Price
                                                        <?php endif; ?>
                                                </h3>
                                                <div class="price-item">
                                                    <div class="price-item-head">
                                                        <i class="fa fa-user"></i>
                                                    </div><!-- End Price-Item-Head -->
                                                    <div class="price-item-content">
                                                        <p>
                                                            <span> <?php echo e($package->price); ?></span>
                                                            
                                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        للشخص الواحد
                                                        <?php else: ?>
                                                        For one person
                                                        <?php endif; ?>
                                                        </p>
                                                    </div><!-- End Price-item-Contant -->
                                                </div><!-- End Price-Item -->
                                                <div class="price-item">
                                                    <div class="price-item-head">
                                                        <i class="fa fa-user"></i>
                                                        <i class="fa fa-user"></i>
                                                    </div><!-- End Price-Item-Head -->
                                                    <div class="price-item-content">
                                                        <p>
                                                            <span> 2400 </span>
                                                            
                                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        لشخصين
                                                        <?php else: ?>
                                                        For two persons
                                                        <?php endif; ?>
                                                        </p>
                                                    </div><!-- End Price-item-Contant -->
                                                </div><!-- End Price-Item -->
                                                <div class="price-item">
                                                    <div class="price-item-head">
                                                        <i class="fa fa-user"></i>
                                                        <i class="fa fa-user"></i>
                                                        <i class="fa fa-user"></i>
                                                    </div><!-- End Price-Item-Head -->
                                                    <div class="price-item-content">
                                                        <p>
                                                            <span> 2300 </span>
                                                            
                                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        لثلاثة اشخاص
                                                        <?php else: ?>
                                                        For three persons
                                                        <?php endif; ?>
                                                        </p>
                                                    </div><!-- End Price-item-Contant -->
                                                </div><!-- End Price-Item -->
                                            </div><!-- End Package-Price -->
                                            <div class="trip-stay">
                                                <h3  class="title">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        الاقامة
                                                        <?php else: ?>
                                                        Residence
                                                        <?php endif; ?>
                                                </h3>
                                                <p>
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($package->residence); ?>

                                                        <?php else: ?>
                                                         <?php echo e($package->residence_en); ?>

                                                        <?php endif; ?>
                                                </p>
                                            </div><!-- End Staying -->
                                            <div class="trip-program-wrap">
                                                <h3  class="title">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        برنامج الرحلة
                                                        <?php else: ?>
                                                        Flight Program
                                                        <?php endif; ?>
                                                </h3>
                                                <div class="trip-program">
                                                     <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($package->program_description); ?>

                                                        <?php else: ?>
                                                         <?php echo e($package->program_d_en); ?>

                                                        <?php endif; ?>
                                                </div><!-- End-trip-program-->
                                            </div><!-- End Trip-Program -->
                                        </div><!-- End Trip-Info -->
                                    </div><!-- End col -->
                                    <div class="col-lg-4">
                                        <div class="book-now">
                                            <form method="post" action="">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="row">
                                                    <div class="col-lg-6 col-md-6">
                                                        <div class="form-group">
                                                            <input class="form-control" name="first_name" type="text" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم الاول <?php else: ?> First Name <?php endif; ?>" required>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                    <div class="col-lg-6 col-md-6">
                                                        <div class="form-group">
                                                            <input class="form-control" name="last_name" type="text" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم الاخير <?php else: ?> Last Name <?php endif; ?>" required>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                    <div class="col-lg-12">
                                                        <div class="form-group">
                                                            <input class="form-control" name="phone" type="tel" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الهاتف <?php else: ?> Mobile <?php endif; ?>" required>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                    <div class="col-lg-12">
                                                        <div class="form-group">
                                                            <input class="form-control" name="email" type="email" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> البريد الالكتروني <?php else: ?> E-mail Address <?php endif; ?>" required>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                    <div class="col-lg-12">
                                                        <div class="form-group">
                                                            <input class="form-control" name="address" type="text" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> العنوان <?php else: ?> Address <?php endif; ?>" required>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                    <div class="col-lg-12">
                                                        <div class="form-group">
                                                            <select class="form-control" name="package_name">
                                                                <option>          </option>
                                                                <?php $__currentLoopData = $t_packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t_package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option><?php if(Config::get('app.locale') == 'ar'): ?>
                                                                        <?php echo e($package->title); ?>

                                                                        <?php else: ?>
                                                                        <?php echo e($package->title_en); ?>

                                                                        <?php endif; ?>
                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                    <div class="col-lg-12">
                                                        <div class="form-group">
                                                            <textarea class="form-control" name="details" type="tel" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> ملاحظة <?php else: ?> Note <?php endif; ?>"  rows="4" required></textarea>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                    <div class="col-lg-12">
                                                        <div class="form-group">
                                                            <button class="custom-btn green-btn" type="submit">
                                                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                                                احجز الان
                                                                <?php else: ?>
                                                                Book Now
                                                                <?php endif; ?>
                                                            </button>
                                                        </div><!-- End Form-Group -->
                                                    </div><!-- End col -->
                                                </div><!-- End row -->
                                            </form><!-- End Form -->
                                        </div><!-- End Book-Now -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                </div><!--End page-content--> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>