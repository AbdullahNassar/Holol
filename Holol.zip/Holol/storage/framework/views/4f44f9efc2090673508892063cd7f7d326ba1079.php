<?php $__env->startSection('title'); ?>
لوحة التحكم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <section>
                        <div class="box-item">
                            <div class="box-item-head">
                                <h3 class="title">لوحة التحكم</h3>
                                <i class="fa fa-angle-down"></i>
                            </div><!-- End Box-Item-Head -->
                            <div class="box-item-content">
                                
                            </div><!-- End Box-Item-Content -->
                        </div><!-- End Box-Item -->
                    </section><!--End Section-->

                    <div class="page-content">
                    <section class="section-md about about-2 pattern-bg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <img src="<?php echo e(asset('assets/site/images/about.png')); ?>" alt="">
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->                    
                </div><!--End page-content-->    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>