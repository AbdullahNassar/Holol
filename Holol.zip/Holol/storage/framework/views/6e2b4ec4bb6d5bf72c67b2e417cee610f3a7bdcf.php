
<!DOCTYPE html>
<html>
    <head>
        <!-- Meta Tags
        ========================== -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <!-- Site Title
        ========================== -->
        <title><?php if(Config::get('app.locale') == 'ar'): ?> حلول <?php else: ?> Holol <?php endif; ?></title>

        
        <!-- Favicon
        ===========================-->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/site/images/fav-icon.png')); ?>">
        
        <!-- Base & Vendors
        ========================== -->
        <link href="<?php echo e(asset('assets/site/vendor/normalize/normalize.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/site/vendor/bootstrap-grid/bootstrap-grid.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/font-awesome/css/font-awesome.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/bxslider/css/jquery.bxslider.css')); ?>">
        <!-- Site Style
        ========================== -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/test.css')); ?>">
        <link href="<?php echo e(asset('assets/site/sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/site/custom.css')); ?>" rel="stylesheet">
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js')}}"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js')}}"></script>
        <![endif]-->
    </head>
    <body>
       <div id="preloader">
           <div class="cogs-1" id="loading">
               <i class="fa fa-cog layer-1"></i>
               <i class="fa fa-cog layer-2"></i>
               <i class="fa fa-cog layer-3"></i>
           </div>
       </div>
       <div id="wrapper">   
           <div class="side-menu closed" id="main-nav">
                <div class="side-menu-container">
                    <div class="icon-bar-container">
                        <a href="" class="icon-bar">
                            <i class="fa fa-align-right"></i>
                        </a><!--End icon-bar-->
                    </div><!--End icon-bar-container-->
                    <ul class="side-menu-nav side-nav" id="navigation">
                        <li>
                            <a href="#home">
                                <img src="<?php echo e(asset('assets/site/images/icons/01.png')); ?>">
                                <img src="<?php echo e(asset('assets/site/images/icons/01-1.png')); ?>">
                                <?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?>
                            </a>
                        </li>        
                        <li>
                            <a href="#about">
                                <img src="<?php echo e(asset('assets/site/images/icons/02.png')); ?>">
                                <img src="<?php echo e(asset('assets/site/images/icons/02-1.png')); ?>">       
                                <?php if(Config::get('app.locale') == 'ar'): ?> من نحن <?php else: ?> About Us <?php endif; ?>
                            </a>
                        </li>
                        <li>
                            <a href="#services">
                                <img src="<?php echo e(asset('assets/site/images/icons/03.png')); ?>">
                                <img src="<?php echo e(asset('assets/site/images/icons/03-1.png')); ?>">
                                    
                                <?php if(Config::get('app.locale') == 'ar'): ?> خدماتنا <?php else: ?> Services <?php endif; ?>
                            </a>
                        </li>
                        <li>
                            <a href="#portfolio">
                                <img src="<?php echo e(asset('assets/site/images/icons/04.png')); ?>">
                                <img src="<?php echo e(asset('assets/site/images/icons/04-1.png')); ?>">
                                    
                                <?php if(Config::get('app.locale') == 'ar'): ?> اعمالنا <?php else: ?> Portfolios <?php endif; ?>
                            </a>
                        </li>
                        <li>
                        <li>
                            <a href="#blog">
                                <img src="<?php echo e(asset('assets/site/images/icons/11.png')); ?>">
                                <img src="<?php echo e(asset('assets/site/images/icons/11-1.png')); ?>">
                                <?php if(Config::get('app.locale') == 'ar'): ?> المدونة <?php else: ?> Blog <?php endif; ?>
                            </a>
                        </li>
                        <li>
                            <a href="#contact">
                                <img src="<?php echo e(asset('assets/site/images/icons/05.png')); ?>">
                                <img src="<?php echo e(asset('assets/site/images/icons/05-1.png')); ?>">               
                                <?php if(Config::get('app.locale') == 'ar'): ?> اتصل بنا <?php else: ?> Contact Us <?php endif; ?>
                            </a>
                        </li>
                        <li class="external">
                          <?php if(Config::get('app.locale') == 'ar'): ?>
                        <a href="<?php echo e(route('site.lang','en')); ?>">
                          <img src="<?php echo e(asset('assets/site/images/icons/10.png')); ?>">
                          <img src="<?php echo e(asset('assets/site/images/icons/10-1.png')); ?>">  
                          English
                        </a>
                        <?php else: ?>
                        <a href="<?php echo e(route('site.lang','ar')); ?>">
                          <img src="<?php echo e(asset('assets/site/images/icons/10.png')); ?>">
                          <img src="<?php echo e(asset('assets/site/images/icons/10-1.png')); ?>">  
                          Arabic
                        </a>
                        <?php endif; ?>
                        <?php echo e(csrf_field()); ?>

                      </li>
                    </ul>
                </div><!--End side-menu-container-->
           </div><!--End side-menu-->
           <div id="main">
               <div id="home" class="page home" data-pos="home">
                    <div class="header">
                        <div class="container">
                            <a href="<?php echo e(route('site.home')); ?>" class="logo">
                                <img src="<?php echo e(asset('assets/site/images/logo.png')); ?>" alt="logo-img">
                            </a>
                        </div><!-- End container -->
                    </div><!-- End Header -->
                    <div class="home-slider">
                        <div class="slider">
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slider-item <?php if($loop->index==0): ?> active <?php endif; ?>">
                                <img src="<?php echo e(asset('storage/uploads/slider').'/'.$slider->image); ?>" alt="">
                            </div><!--End slider-item-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!--End <!-End slider-->
                        <div class="slider-caption">
                            <?php if(Config::get('app.locale') == 'ar'): ?>
                            <p>
                                <?php echo e($data->get('slider_ar')); ?>

                                <br><?php echo e($data->get('slider2_ar')); ?>

                            </p>
                            <?php else: ?>
                            <p>
                                <?php echo e($data->get('slider_en')); ?>

                                <br><?php echo e($data->get('slider2_en')); ?>

                            </p>
                            <?php endif; ?>
                        </div><!-- End Slider-Caption -->
                    </div><!--End home-slider-->  
                </div><!--End home-->
               <div id="about" class="page">
                   <section class="about">
                       <div class="container-fluid">
                           <div class="row">
                               <div class="col-lg-7">
                                   <div class="section-head">
                                       <h3 class="section-title">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                           <?php echo e($data->get('about_head_ar')); ?>

                                        <?php else: ?>
                                            <?php echo e($data->get('about_head_en')); ?>

                                        <?php endif; ?>
                                       </h3>
                                       <p>
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                           <?php echo e($data->get('about_content_ar')); ?>

                                        <?php else: ?>
                                            <?php echo e($data->get('about_content_en')); ?>

                                        <?php endif; ?>
                                       </p>
                                   </div><!-- End Section-Head -->
                                   <div class="section-content">
                                       <div class="row">
                                           <div class="col-md-6">
                                               <div class="feature-box">
                                                   <div class="feature-box-head">
                                                       <img src="<?php echo e(asset('assets/site/images/icons/06.png')); ?>" alt="icon-1">
                                                   </div><!-- End feature-box-Head -->
                                                   <div class="feature-box-body">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                       <h3 class="title">قيمنا</h3>
                                                       <p>
                                                           <?php echo e($data->get('morals_ar')); ?>  
                                                       </p>
                                                    <?php else: ?>
                                                        <h3 class="title">Our Morals</h3>
                                                       <p>
                                                           <?php echo e($data->get('morals_en')); ?> 
                                                       </p>
                                                    <?php endif; ?>
                                                    </div><!-- End feature-box-Body -->
                                               </div><!-- End feature-box -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="feature-box">
                                                    <div class="feature-box-head">
                                                        <img src="<?php echo e(asset('assets/site/images/icons/07.png')); ?>" alt="icon-2">
                                                    </div><!-- End feature-box-Head -->
                                                    <div class="feature-box-body">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <h3 class="title">رؤيتنا</h3>
                                                        <p>
                                                            <?php echo e($data->get('vision_ar')); ?>  
                                                        </p>
                                                        <?php else: ?>
                                                        <h3 class="title">Our Vision</h3>
                                                        <p>
                                                            <?php echo e($data->get('vision_en')); ?> 
                                                        </p>
                                                        <?php endif; ?>
                                                    </div><!-- End feature-box-Body -->
                                                </div><!-- End feature-box -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="feature-box">
                                                    <div class="feature-box-head">
                                                        <img src="<?php echo e(asset('assets/site/images/icons/08.png')); ?>" alt="icon-3">
                                                    </div><!-- End feature-box-Head -->
                                                    <div class="feature-box-body">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <h3 class="title">رسالتنا</h3>
                                                        <p>
                                                            <?php echo e($data->get('message_ar')); ?>      
                                                        </p>
                                                        <?php else: ?>
                                                        <h3 class="title">Our Message</h3>
                                                        <p>
                                                            <?php echo e($data->get('message_en')); ?>     
                                                        </p>
                                                        <?php endif; ?>
                                                    </div><!-- End feature-box-Body -->
                                                </div><!-- End feature-box -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="feature-box">
                                                    <div class="feature-box-head">
                                                        <img src="<?php echo e(asset('assets/site/images/icons/09.png')); ?>" alt="icon-4">
                                                    </div><!-- End feature-box-Head -->
                                                    <div class="feature-box-body">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <h3 class="title">أهدافنا</h3>
                                                        <p>
                                                            <?php echo e($data->get('goals_ar')); ?>  
                                                        </p>
                                                        <?php else: ?>
                                                        <h3 class="title">Our Goals</h3>
                                                        <p>
                                                            <?php echo e($data->get('goals_en')); ?>   
                                                        </p>
                                                        <?php endif; ?>
                                                    </div><!-- End feature-box-Body -->
                                                </div><!-- End feature-box -->
                                            </div><!-- End col -->
                                        </div><!-- End row -->
                                    </div><!-- End Section-Content -->
                                </div><!--End col -->
                                <div class="col-lg-5">
                                    <div class="section-img">
                                        <img src="<?php echo e(asset('storage/uploads/static').'/'.$data->get('about_image')); ?>" alt="about">
                                    </div><!-- End Section-Img -->
                                </div><!--End col -->
                            </div><!--End row -->
                        </div><!-- End container -->
                    </section><!-- En Section -->
                </div><!--End about Page-->
               <div id="services" class="page">
                   <section class="services">
                       <div class="container-fluid">
                           <div class="section-content">
                               <div class="row">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($service->id == 1): ?>
                                    <div class="col-lg-4">
                                       <div class="service-block service-lg">
                                           <div class="service-block-img">
                                               <img src="<?php echo e(asset('storage/uploads/service').'/'.$service->icon); ?>">
                                           </div><!-- End service-block-img -->
                                           <ul class="service-block-body" id="more-page">
                                               <li>
                                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                                   <a href="#single-service1" class="title">
                                                       <?php echo e($service->name_ar); ?>

                                                   </a>
                                                <?php else: ?>
                                                    <a href="#single-service1" class="title">
                                                       <?php echo e($service->name_en); ?>

                                                   </a>
                                                <?php endif; ?>
                                               </li>
                                           </ul><!-- End service-block-body -->
                                       </div><!-- End service-block -->
                                    </div><!-- End col -->
                                    <?php endif; ?>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <div class="col-lg-8">
                                        <div class="row">
                                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($service->id > 1 && $service->id < 6): ?>
                                            <div class="col-md-6">
                                                <div class="service-block">
                                                    <div class="service-block-img">
                                                        <img src="<?php echo e(asset('storage/uploads/service').'/'.$service->icon); ?>">
                                                    </div><!-- End service-block-img -->
                                                    <ul class="service-block-body" id="more-page">
                                                        <li>
                                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                                               <a href="#single-service<?php echo e($service->id); ?>" class="title">
                                                                   <?php echo e($service->name_ar); ?>

                                                               </a>
                                                            <?php else: ?>
                                                                <a href="#single-service<?php echo e($service->id); ?>" class="title">
                                                                   <?php echo e($service->name_en); ?>

                                                               </a>
                                                            <?php endif; ?>
                                                        </li>
                                                    </ul><!-- End service-block-body -->
                                                </div><!-- End service-block -->
                                            </div><!-- End col -->
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!-- End row -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!--End container-fluid-->
                    </section><!--End services-->
                </div><!--End services Pages-->
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="single-service<?php echo e($service->id); ?>" class="page">
                   <section class="service-detail">
                       <div class="container-fluid">
                           <div class="row">
                               <div class="col-lg-5">
                                   <div class="service-detail-img">
                                       <img src="<?php echo e(asset('storage/uploads/service').'/'.$service->image); ?>">
                                   </div><!-- End Service-Detail-Img -->
                               </div><!-- End col -->
                               <div class="col-lg-7">
                                   <div class="service-detail-content">
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                       <h3 class="title">
                                           <?php echo e($service->name_ar); ?>

                                       </h3>
                                       <p>
                                           <?php echo e($service->content_ar); ?>

                                       </p>
                                    <?php else: ?>
                                        <h3 class="title">
                                           <?php echo e($service->name_en); ?>

                                        </h3>
                                        <p>
                                           <?php echo e($service->content_en); ?>

                                        </p>
                                    <?php endif; ?>
                                   </div><!-- End Service-Detail-Content -->
                               </div><!-- End col -->
                           </div><!-- End row -->
                       </div><!-- End Container -->
                   </section><!-- End Section -->
                </div><!--End Blog Post Pages-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div id="portfolio" class="page">
                   <section class="works">
                       <div class="page-head">
                            <h3 class="title">
                                  <?php if(Config::get('app.locale') == 'ar'): ?>
                                   حلولنا لنجاح مشروعك. 
                                  <?php else: ?>
                                   Solutions for project success
                                  <?php endif; ?>
                            </h3>   
                        </div><!-- End page-head -->
                        <div class="container-fluid">
                            <div class="section-content">
                                <ul id="filters" class="filters">
                                    <li>
                                        <a href="#" data-filter="*" class="selected">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                             الكل
                                            <?php else: ?>
                                             All
                                            <?php endif; ?>
                                        </a>
                                    </li>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="#" data-filter=".item-<?php echo e($loop->index + 1); ?>">
                                          <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($category->cat_name_ar); ?>

                                          <?php else: ?>
                                            <?php echo e($category->cat_name_en); ?>

                                          <?php endif; ?>
                                        </a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                                </ul>
                                <div class="row">
                                    <ul id="gallery" class="gallery sort-destination">
                                      <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="isotope-item item-<?php echo e($loop->index + 1); ?>">
                                            <div class="portofolio-item" href="#">
                                                <div class="portofolio-item-img">
                                                    <img src="<?php echo e(asset('storage/uploads/portfolio/'. $portfolio->icon)); ?>" alt="work-1">
                                                </div><!-- End Portofolio-Item-Img -->
                                                <ul class="portofolio-item-content" id="more-page">
                                                    <li>
                                                        <a href="#work-detail<?php echo e($portfolio->id); ?>" class="title">
                                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                                              <?php echo e($portfolio->name_ar); ?>

                                                            <?php else: ?>
                                                              <?php echo e($portfolio->name_en); ?>

                                                            <?php endif; ?>
                                                        </a>
                                                    </li>
                                                </ul><!-- End Portofolio-Item-Content -->
                                            </div>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>           
                                </div>
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                </div><!--End Portfolio Pages-->
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="work-detail<?php echo e($portfolio->id); ?>" class="page">
                 <section class="service-detail">
                   <div class="container-fluid">
                     <div class="row">
                       <div class="col-lg-5">
                         <div class="service-detail-img">
                           <img src="<?php echo e(asset('storage/uploads/portfolio/'. $portfolio->image)); ?>">
                         </div><!-- End Service-Detail-Img -->
                       </div><!-- End col -->
                       <div class="col-lg-7">
                         <div class="service-detail-content">
                           <h3 class="title">
                             <?php if(Config::get('app.locale') == 'ar'): ?>
                               <?php echo e($portfolio->name_ar); ?>

                             <?php else: ?>
                               <?php echo e($portfolio->name_en); ?>

                             <?php endif; ?>
                           </h3>
                           <p>
                             <?php if(Config::get('app.locale') == 'ar'): ?>
                               <?php echo e($portfolio->content_ar); ?>

                             <?php else: ?>
                               <?php echo e($portfolio->content_en); ?>

                             <?php endif; ?>
                           </p>
                           <a href="<?php echo e($portfolio->url); ?>" class="custom-btn">المزيد</a>
                         </div><!-- End Service-Detail-Content -->
                       </div><!-- End col -->
                     </div><!-- End row -->
                   </div><!-- End Container -->
                 </section><!-- End Section -->
                </div><!--End Blog Post Pages--> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <div id="blog" class="page">
                    <section class="blog">
                        <div class="page-head">
                            <h3 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> اخبار وحلول <?php else: ?> Holol Blog <?php endif; ?>
                            </h3>       
                        </div><!-- End page-head -->
                        <div class="section-content">
                            <div class="container-fluid">
                                <div class="row">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                    <div class="col-md-6 col-lg-4">
                                        <div class="blog-box hover-active">
                                            <div class="blog-box-img custom-hover">
                                                <div class="blog-box-img custom-hover-holder">
                                                   <img src="<?php echo e(asset('storage/uploads/blog').'/'.$post->icon); ?>">
                                                    <div class="date">
                                                        <span class="en-text"><?php echo e($post->day_ar); ?> </span>
                                                        <span><?php echo e($post->month_ar); ?> <?php echo e($post->year_ar); ?></span>
                                                    </div><!--End date-->
                                               </div><!--End custom-hover-holder-->
                                            </div><!--End Blog-box-img-->
                                            <div class="blog-box-content">
                                                <h2 class="title title-md">
                                                    <?php echo e($post->title_ar); ?>

                                                </h2>
                                                <p>
                                                    <?php echo e($post->head_ar); ?>

                                                </p>
                                                <ul id="more-page">
                                                    <li>
                                                        <a href="#blog-post<?php echo e($post->id); ?>" class="more-btn">      
                                                            اقرا المزيد +
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div><!--End Blog-box-content-->
                                        </div><!-- End Blog-Box -->
                                    </div><!-- End col -->
                                    <?php else: ?>
                                    <div class="col-md-6 col-lg-4">
                                        <div class="blog-box hover-active">
                                            <div class="blog-box-img custom-hover">
                                                <div class="blog-box-img custom-hover-holder">
                                                   <img src="<?php echo e(asset('storage/uploads/blog').'/'.$post->icon); ?>">
                                                    <div class="date">
                                                        <span class="en-text"><?php echo e($post->day_en); ?> </span>
                                                        <span><?php echo e($post->month_en); ?> <?php echo e($post->year_en); ?></span>
                                                    </div><!--End date-->
                                               </div><!--End custom-hover-holder-->
                                            </div><!--End Blog-box-img-->
                                            <div class="blog-box-content">
                                                <h2 class="title title-md">
                                                    <?php echo e($post->title_en); ?> 
                                                </h2>
                                                <p>
                                                    <?php echo e($post->head_en); ?>

                                                </p>
                                                <ul id="more-page">
                                                    <li>
                                                        <a href="#blog-post<?php echo e($post->id); ?>" class="more-btn">      
                                                            Read More +
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div><!--End Blog-box-content-->
                                        </div><!-- End Blog-Box -->
                                    </div><!-- End col -->
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!-- End row -->
                            </div><!-- End  container-fluid-->
                        </div><!-- End Section-Content -->
                    </section><!-- En Section -->
                    
                </div><!--End Blog Pages-->
               <div id="contact" class="page">
                    <section class="contact">
                        <div class="page-head">
                            <h3 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                <?php echo e($data->get('contact_ar')); ?> 
                                <?php else: ?>
                                <?php echo e($data->get('contact_en')); ?>

                                <?php endif; ?>  
                            </h3>       
                        </div><!-- End page-head -->
                        <div class="section-content">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-lg-7">
                                        <form action="<?php echo e(route('site.message')); ?>" enctype="multipart/form-data" method="post" onsubmit="return false;" class="form">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'en'): ?> Full Name <?php else: ?> الاسم بالكامل <?php endif; ?>" name="name">
                                            </div><!-- End Form-Group -->
                                            <div class="form-group">
                                                <input type="email" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'en'): ?> Email Address <?php else: ?> البريد الالكترونى <?php endif; ?>" name="email">
                                            </div><!-- End Form-Group -->
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder=" <?php if(Config::get('app.locale') == 'en'): ?> Subject <?php else: ?> الموضوع <?php endif; ?>" name="subject">
                                            </div><!-- End Form-Group -->
                                            <div class="form-group">
                                                <textarea class="form-control" placeholder="<?php if(Config::get('app.locale') == 'en'): ?> Message <?php else: ?> الرسالة <?php endif; ?>" name="message"></textarea>
                                            </div><!-- End Form-Group -->
                                            <div class="form-group">
                                                <button type="submit" class="custom-btn addBTN"><?php if(Config::get('app.locale') == 'en'): ?> Send Message <?php else: ?> ارسل رسالة  <?php endif; ?></button>
                                            </div><!-- End Form-Group -->
                                        </form><!-- End form -->
                                    </div><!-- End col -->
                                    <div class="col-lg-5">
                                        <div class="contact-info">
                                            <div class="contact-widget">
                                                <div class="contact-icon">
                                                    <i class="fa fa-map-marker"></i>
                                                </div><!-- End Contact-Widget-Head -->
                                                <div class="contact-body">
                                                    <span><?php if(Config::get('app.locale') == 'en'): ?> Send Address <?php else: ?> العنوان  <?php endif; ?></span>
                                                    <span> 
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                            <?php echo e($contact->get('address_ar')); ?> 
                                                        <?php else: ?>
                                                            <?php echo e($contact->get('address_en')); ?>

                                                        <?php endif; ?>  
                                                    </span>
                                                </div><!-- End Contact-Body -->
                                            </div><!-- End Contact-Widget -->
                                            <div class="contact-widget">
                                                <div class="contact-icon">
                                                    <i class="fa fa-envelope"></i>
                                                </div><!-- End Contact-Widget-Head -->
                                                <div class="contact-body">
                                                    <span><?php if(Config::get('app.locale') == 'en'): ?> Email Address <?php else: ?> البريد الالكترونى <?php endif; ?> </span>
                                                    <span class="en-text"> <?php echo e($contact->get('email')); ?> </span>
                                                </div><!-- End Contact-Body -->
                                            </div><!-- End Contact-Widget -->
                                            <div class="contact-widget">
                                                <div class="contact-icon">
                                                    <i class="fa fa-phone"></i>
                                                </div><!-- End Contact-Widget-Head -->
                                                <div class="contact-body">
                                                    <span> <?php if(Config::get('app.locale') == 'en'): ?> Phone <?php else: ?> الهاتف <?php endif; ?></span>
                                                    <span class="en-text"> <?php echo e($contact->get('phone')); ?></span>
                                                </div><!-- End Contact-Body -->
                                            </div><!-- End Contact-Widget -->
                                        </div><!-- End Contact-Info -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End container-fluid -->
                        </div><!-- End section-content -->
                    </section><!-- En Section -->
                </div><!--End Contact Pages-->

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div id="blog-post<?php echo e($post->id); ?>" class="page">
                   <section class="blog-post">
                       <div class="page-head">
                           <h3 class="title">
                            <?php if(Config::get('app.locale') == 'ar'): ?>
                               <?php echo e($post->title_ar); ?>

                            <?php else: ?> 
                                <?php echo e($post->title_en); ?>

                            <?php endif; ?>
                           </h3>         
                        </div><!-- End page-head -->
                        <div class="section-content">
                            <div class="blog-box blog-post">
                                <div class="blog-box-img">
                                    <div class="date">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        <span class="en-text"><?php echo e($post->day_ar); ?> </span>
                                        <span><?php echo e($post->month_ar); ?> <?php echo e($post->year_ar); ?></span>
                                        <?php else: ?> 
                                        <span class="en-text"><?php echo e($post->day_en); ?> </span>
                                        <span><?php echo e($post->month_en); ?> <?php echo e($post->year_en); ?></span>
                                        <?php endif; ?>
                                    </div><!--End date-->
                                    <img src="<?php echo e(asset('storage/uploads/blog').'/'.$post->image); ?>" alt="...">
                                </div><!--End Blog-box-img-->
                                <div class="blog-box-content">
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                    <h2 class="title title-md">
                                        <?php echo e($post->head_ar); ?>

                                    </h2>   
                                    <p>
                                        <?php echo e($post->content_ar); ?>

                                    </p> 
                                    <?php else: ?> 
                                    <h2 class="title title-md">
                                        <?php echo e($post->head_en); ?>

                                    </h2>   
                                    <p>
                                        <?php echo e($post->content_en); ?>

                                    </p>
                                    <?php endif; ?>      
                                    <div class="blog-post-share">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        <p>مشاركة: </p>
                                        <?php else: ?> 
                                        <p>Share: </p>
                                        <?php endif; ?>
                                        <ul class="social-list">
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-linkedin"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa fa-instagram"></i>
                                                </a>
                                            </li>
                                        </ul><!-- End Social-List -->
                                    </div>
                                </div><!--End Blog-box-content-->
                            </div><!-- End Blog-Box -->
                                        
                        </div><!-- End section-content -->
                    </section><!-- En blog-post -->
                </div><!--End Blog Post Pages-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <div id="overlay"></div>
            </div><!--end main-->
        </div><!--wrapper-->

        <!-- JS Base & Vendors
        ========================== -->
        <script src="<?php echo e(asset('assets/site/vendor/jquery/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/TweenMax.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/bxslider/js/jquery.bxslider.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/perfect-scrollbar/js/perfect-scrollbar.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/isotope/isotope.js')); ?>"></script>
        
        <!-- Site JS
        ========================== -->
        <script src="<?php echo e(asset('assets/site/js/main.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/process.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/sweetalert.min.js')); ?>" type="text/javascript"></script>
        <!-- BEGIN JIVOSITE CODE {literal} -->
        <script type='text/javascript'>
        (function(){ var widget_id = '5W68d9JnHg';var d=document;var w=window;function l(){
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
        <!-- {/literal} END JIVOSITE CODE -->
    </body>
</html>