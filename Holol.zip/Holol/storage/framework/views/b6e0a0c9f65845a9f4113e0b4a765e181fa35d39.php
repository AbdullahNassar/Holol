<?php $__env->startSection('title'); ?>
الفئات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">تعديل</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" action="<?php echo e(route('admin.category.edit' , ['id' => $categorie->cat_id])); ?>" enctype="multipart/form-data" method="post" onsubmit="return false;">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>أسم الفئة</label>
                                    <input type="hidden" name="s_id" value="<?php echo e($categorie->cat_id); ?>">
                                    <input  value="<?php echo e($categorie->cat_name); ?>" type="text" name="cat_name"  class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>التفعيل</label>
                                    <div class="tg-item">
                                        <select class="form-control" required name="active">
                                            <option value="<?php echo e($categorie->active); ?>"><?php if($categorie->active == 1): ?>
                                                                                  نعم
                                                                                  <?php elseif($categorie->active == 0): ?>
                                                                                  لا
                                                                                  <?php endif; ?> 
                                            </option>
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select>
                                    </div>
                                </div><!-- End Form-Group -->
                            </div>
                        </div>
                        <div class="form-action">
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="custom-btn addBTN" type="submit">حفظ التغييرات</button>
                                </div><!--End Col-->
                            </div><!--End Row-->
                        </div><!--End Form-action-->
                    </div>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">جدول  الفئات</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <div id="sample_editable_1_wrapper" class="dataTables_wrapper no-footer">
                    <div class="table-scrollable">
                        <table class="table table-striped dataTable no-footer" role="grid">
                            <thead>
                                <tr role="row">
                                    <th> # </th>
                                    <th> اسم الفئة </th>
                                    <th> التفعيل  </th>
                                    <th> تعديل </th>
                                    <th> حذف </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="even">
                                    <td class="sorting_1"><?php echo e($loop->index + 1); ?> </td>
                                    <td>
                                        <?php echo e($category->cat_name); ?>

                                    </td>
                                    <td> 
                                        <?php if($category->active): ?>
                                        نعم
                                        <?php else: ?>
                                        لا
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="custom-btn small green" href="<?php echo e(route('admin.category.edit' , ['id' => $category->cat_id])); ?>"> تعديل </a>
                                    </td>
                                    <td>
                                        <button type="button" class="delete custom-btn small red btndelet" data-url="<?php echo e(route('admin.category.delete' , ['id' => $category->cat_id])); ?>"> حذف </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div><!-- End Box-Item-Content -->
            </div><!-- End Box-Item -->
    </section>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>