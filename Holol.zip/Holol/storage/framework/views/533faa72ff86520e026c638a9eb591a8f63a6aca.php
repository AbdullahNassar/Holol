<?php $__env->startSection('content'); ?>
                <section class="home-slider">
                    <div id="slider">
                        <div class="fullwidthbanner-container">
                            <div id="revolution-slider">
                                <ul>
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-transition="random" data-slotamount="7" data-masterspeed="800">
                                        <img src="<?php echo e(asset('storage/uploads/slider').'/'.$slider->image); ?>" alt="">
                                        <div class="tp-caption sfr stt custom-font-1 tp-resizeme"
                                             data-x="right"
                                             data-hoffset="0"
                                             data-y="140"
                                             data-speed="400"
                                             data-start="700"
                                             data-easing="easeInOut">
                                            <?php echo e($slider->head_ar); ?>

                                        </div>
                                        <div class="tp-caption sfr stb custom-font-2 tp-resizeme"
                                             data-x="right"
                                             data-hoffset="0"
                                             data-y="290"
                                             data-speed="400"
                                             data-start="1000"
                                             data-easing="easeInOut">
                                             <?php echo e($slider->content_ar); ?>

                                        </div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div><!--End fullwidthbanner-container-->
                    </div><!--End slider-->
                </section><!--End home-slider-->  
                <div class="page-content">
                    <section class="section-md about">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="section-head">
                                        <h3 class="section-title">
                                            من نحن
                                        </h3>
                                        <p>
                                            <?php echo e($data->get('about_content')); ?>

                                        </p>
                                        <a href="<?php echo e(URL::to('/about')); ?>" class="more">
                                            المزيد
                                            <i class="fa fa-plus"></i>
                                        </a>
                                    </div>
                                </div><!-- End col -->
                                <div class="col-md-5">
                                    <div class="section-img">
                                        <img src="<?php echo e(asset('storage/uploads/static').'/'.$data->get('about_image')); ?>" alt="about">
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    
                    <section class="colored mission-vision">
                        <div class="mission-part">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6 absolute-img mission-img">
                                        <img src="<?php echo e(asset('assets/site/images/mission-img.jpg')); ?>">
                                    </div><!-- End col -->
                                    <div class="col-md-6 mission-content">
                                        <h3 class="title title-lg"> رؤية الشركة</h3>
                                        <p>
                                            <?php echo e($data->get('vision')); ?>

                                        </p>
                                    </div><!-- End Mission-Content -->
                                </div><!-- End row -->
                            </div><!-- End container -->
                        </div><!-- End Mission-Part -->
                        <div class="vision-part">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-6 absolute-img vision-img">
                                        <img src="<?php echo e(asset('assets/site/images/vision-img.jpg')); ?>">
                                    </div><!-- End col -->
                                    <div class="col-md-6 vision-content">
                                        <h3 class="title title-lg"> اهداف الشركة</h3>
                                        <p>
                                            <?php echo e($data->get('goals')); ?>

                                        </p>
                                    </div><!-- End Vision-Content -->
                                </div><!-- End row -->
                            </div><!-- End container -->
                        </div><!-- End Vision-Part -->
                    </section><!-- End Section -->
                    <section class="section-lg our-clients text-center">
                        <div class="container">
                            <div class="section-head">
                                <h3 class="section-title">عملاؤنا</h3><!-- End Section-Title -->
                                <p>
                                    <?php echo e($data->get('clients')); ?>

                                </p>
                            </div><!-- End Section-Head -->
                            <div class="section-content">
                                <div class="owl-carousel" id="clients-carousel">
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="client-item">
                                        <div class="client-item-img">
                                            <img src="<?php echo e(asset('storage/uploads/client').'/'.$client->image); ?>" alt="about">
                                        </div>
                                    </div><!--End Client-item-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </div><!--End clients-carousel-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Our-clients-section-->
                </div><!-- End Page-Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>