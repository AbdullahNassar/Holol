<?php $__env->startSection('title'); ?>
البرامج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">اضافة</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form form-packages" method="post" action="">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                            <h3 class="mt-repeater-title">برنامج الباقة</h3><br>
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الأسم</label>
                                    <input type="hidden" name="s_id" value="<?php echo e($program->id); ?>">
                                    <input type="text" class="form-control" name="program_title" value="<?php echo e($program->name); ?>">
                                </div><!--End Form-group-->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Name</label>
                                    <input type="text" class="form-control" name="program_title_en" value="<?php echo e($program->name_en); ?>">
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>المحتوى</label>
                                    <textarea class="form-control" rows="5" name="program_description"><?php echo e($program->content); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>content</label>
                                    <textarea class="form-control" rows="5" name="program_d_en"><?php echo e($program->content_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الترتيب</label>
                                    <input type="text" class="form-control" name="program_order" value="<?php echo e($program->_order); ?>">
                                </div><!-- End Form-Group -->
                            </div>
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>الباقة</label>
                                    <select class="form-control" name="package">
                                        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($package->id); ?>"><?php echo e($package->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                        </div>
                        </div>
                        <div class="form-action">
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="custom-btn" type="submit">حفظ التغييرات</button>
                                </div><!--End Col-->
                            </div><!--End Row-->
                        </div><!--End Form-action-->
                    </div>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>