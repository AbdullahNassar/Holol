<?php $__env->startSection('title'); ?>
الرسائل
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">جدول الرسائل</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                
                <div id="sample_editable_1_wrapper" class="dataTables_wrapper no-footer">
                    <div class="row">

                    </div>
                    <div class="table-scrollable">
                        <table class="table table-striped dataTable no-footer" id="sample_editable_1" role="grid" aria-describedby="sample_editable_1_info">
                            <thead>
                                <tr role="row">
                                    <th class="sorting" tabindex="0" aria-controls="sample_editable_1" rowspan="1" colspan="1" style="width: 68.4667px;"  aria-label=" # : activate to sort column descending"> # </th>
                                    <th class="sorting" tabindex="0" aria-controls="sample_editable_1" rowspan="1" colspan="1" style="width: 143.733px;" aria-label=" الأسم : activate to sort column ascending"> الإسم </th>
                                    <th class="sorting" tabindex="0" aria-controls="sample_editable_1" rowspan="1" colspan="1" style="width: 162.667px;" aria-label=" التفعيل  : activate to sort column ascending"> التليفون  </th>
                                    <th class="sorting_asc" tabindex="0" aria-controls="sample_editable_1" rowspan="1" colspan="1" style="width: 153.25px;" aria-label=" الترتيب : activate to sort column ascending"> البريد الالكتروني  </th>
                                    <th class="sorting" tabindex="0" aria-controls="sample_editable_1" rowspan="1" colspan="1" style="width: 177.717px;" aria-label=" العمليات : activate to sort column ascending"> الرساله </th></tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $objects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="even">
                                    <td class="sorting_1"><?php echo e($object->id); ?> </td>
                                    <td>
                                        <?php echo e($object->name); ?>

                                    </td>
                                    <td> 
                                        <?php echo e($object->phone); ?>

                                    </td>
                                    <td>
                                        <?php echo e($object->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($object->message); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div><!-- End Box-Item-Content -->
            </div><!-- End Box-Item -->
    </section>

</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>