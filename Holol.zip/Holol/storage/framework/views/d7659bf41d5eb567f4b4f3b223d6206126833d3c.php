<?php $__env->startSection('content'); ?>
<div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/icons/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> فريق الأطباء <?php else: ?> Doctors Team <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> فريق الأطباء <?php else: ?> Doctors Team <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->
                    <section class="section-lg contact-fix">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?> فريق الأطباء <?php else: ?> Doctors Team <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('doctors')); ?> <?php else: ?> <?php echo e($data->get('doctors_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <div class="widget-box team-item">
                                            <div class="widget-box-img">
                                                <img src="<?php echo e(asset('storage/uploads/doctors').'/'.$doctor->image); ?>" alt="...">
                                            </div><!--End Widget-box-img-->
                                            <div class="widget-box-content">
                                                <div class="cont">
                                                    <h3 class="title">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($doctor->name); ?> <?php else: ?> <?php echo e($doctor->name_en); ?> <?php endif; ?>
                                                    </h3>
                                                    <span class="text">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($doctor->title); ?> <?php else: ?> <?php echo e($doctor->title_en); ?> <?php endif; ?>
                                                    </span>
                                                    <ul class="social-list">
                                                       <li>
                                                            <a href="<?php echo e($doctor->facebook); ?>">
                                                                <i class="fa fa-facebook"></i>
                                                            </a>
                                                        </li>
                                                         <li>
                                                            <a href="<?php echo e($doctor->twitter); ?>">
                                                                <i class="fa fa-twitter"></i>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e($doctor->google); ?>">
                                                                <i class="fa fa-google-plus"></i>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="<?php echo e($doctor->linkedin); ?>">
                                                                <i class="fa fa-linkedin"></i>
                                                            </a>
                                                        </li>                                                        
                                                    </ul><!-- End Social-List -->
                                                </div><!--End cont-head-->
                                            </div><!--End Widegt-box-content-->
                                        </div><!--End Widget-box-->
                                    </div><!--End Col-md-3-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>