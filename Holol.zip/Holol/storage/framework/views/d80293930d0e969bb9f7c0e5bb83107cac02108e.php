<?php $__env->startSection('title'); ?>
لوحة التحكم
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <section>
                        <div class="box-item">
                            <div class="box-item-head">
                                <h3 class="title">لوحة التحكم</h3>
                                <i class="fa fa-angle-down"></i>
                            </div><!-- End Box-Item-Head -->
                            <div class="box-item-content">
                                
                            </div><!-- End Box-Item-Content -->
                        </div><!-- End Box-Item -->
                    </section><!--End Section-->

                    <div class="page-content">
                    <section class="section-md about about-2 pattern-bg">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-7">
                                    <div class="section-head">
                                        <h3 class="section-title has-bg">عن عيادتنا</h3><br>
                                    </div><!-- End Section-Head -->
                                    <div class="section-content">
                                        <p>
                                            هنالك العديد من الأنواع المتوفرة لنصوص لوريم إيبسوم، ولكن الغالبية تم تعديلها بشكل ما عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص. إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص. بينما تعمل جميع مولّدات نصوص إن كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات.
                                        </p>
                                    </div><!-- End Section-Content -->
                                </div><!-- End col -->
                                <div class="col-lg-5">
                                    <div class="section-img-2">
                                        <div class="img-2-pattern">
                                            <img src="<?php echo e(asset('assets/site/images/safe_image(11).jpg')); ?>" alt="">
                                        </div><!-- End With-Pattern -->
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->                    
                </div><!--End page-content-->    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>