<?php $__env->startSection('content'); ?>

<div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/icons/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> احجز موعد <?php else: ?> Book Your Appointment <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> احجز موعد <?php else: ?> Book Your Appointment <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->

                    <section class="section-md contact-fix appointment-page">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-9">                                            
                                    <form class="form" method="post" action="<?php echo e(URL::to('/book')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" name="full_name" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم كاملا <?php else: ?> Full Name <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" name="phone" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> رقم الهاتف <?php else: ?> Phone Number <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-9">
                                                <div class="form-group">
                                                    <input type="email" name="email" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> البريد الالكتروني <?php else: ?> E-mail Address <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select class="form-control"  name="gender" required>
                                                        <option>              </option>
                                                        <option value="<?php if(Config::get('app.locale') == 'ar'): ?> ذكر <?php else: ?> Male <?php endif; ?>"><?php if(Config::get('app.locale') == 'ar'): ?> ذكر <?php else: ?> Male <?php endif; ?></option>
                                                        <option value="<?php if(Config::get('app.locale') == 'ar'): ?> انثى <?php else: ?> Female <?php endif; ?>"><?php if(Config::get('app.locale') == 'ar'): ?> انثى <?php else: ?> Female <?php endif; ?></option>
                                                        <option value="<?php if(Config::get('app.locale') == 'ar'): ?> طفل <?php else: ?> Kid <?php endif; ?>"><?php if(Config::get('app.locale') == 'ar'): ?> طفل <?php else: ?> Kid <?php endif; ?></option>
                                                    </select>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" name="book_date" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> ميعاد الحجز <?php else: ?> Booking Date <?php endif; ?>">
                                                </div><!--End Form-group-->
                                            </div><!--End Col-md-6-->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <input type="text" name="book_time" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> وقت الحجز <?php else: ?> Booking Time <?php endif; ?>">
                                                </div><!--End Form-group-->
                                            </div><!--End Col-md-6-->
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <textarea class="form-control" name="message" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> اكتب رسالتك <?php else: ?> Write Your Message <?php endif; ?>" rows="8"></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <button type="submit" class="custom-btn"><?php if(Config::get('app.locale') == 'ar'): ?> ارســــــــــــــال <?php else: ?> Send <?php endif; ?></button>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                        </div><!-- End row -->
                                    </form>
                                </div><!-- End col -->
                                <div class="col-md-3 section-img">
                                    <img src="<?php echo e(asset('assets/site/images/test.png')); ?>" alt="">
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>