                <footer class="footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?> منسك الخير <?php else: ?> Mansak El Kheir <?php endif; ?>
                                        </h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <ul class="contact-list">
                                            <li>
                                                <i class="fa fa-phone"></i>
                                                <span><?php echo e($data->get('phone')); ?></span>
                                                
                                            </li>
                                            <li>
                                                <i class="fa fa-envelope"></i>
                                                <span><?php echo e($data->get('email')); ?></span>
                                                
                                            </li>
                                            <li class="location">
                                                <i class="fa fa-map-marker"></i>
                                                <span><?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('address')); ?> <?php else: ?> <?php echo e($data->get('address_en')); ?> <?php endif; ?>
                                                </span>
                                                
                                            </li>
                                        </ul><!-- End Contact-List -->
                                    </div><!-- End Widget-Content -->
                                </div><!-- End Footer-Widget -->
                            </div><!-- End col -->
                            <div class="col-lg-2 col-sm-6">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?> روابط سريعة <?php else: ?> Fast Links <?php endif; ?>
                                        </h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <ul class="important-links">
                                            <li>
                                                <a href="<?php echo e(URL::to('/')); ?>"><?php echo e(trans('app.home')); ?></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(URL::to('/about')); ?>"><?php echo e(trans('app.about')); ?></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(URL::to('/contact')); ?>"><?php echo e(trans('app.contact')); ?></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(URL::to('/')); ?>">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?> الشروط والاحكام <?php else: ?> Terms and Conditions <?php endif; ?>
                                                </a>
                                            </li>
                                        </ul><!-- End Important-Links -->
                                    </div><!-- End Widget-Content -->
                                </div><!-- End Footer-Widget -->
                            </div><!-- End col -->
                            <div class="col-lg-2 col-sm-6">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?> الباقات و العروض <?php else: ?> Packages and Offers <?php endif; ?>
                                        </h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <ul class="important-links">
                                            <li>
                                                <a href="<?php echo e(URL::to('/packages')); ?>">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?> باقات الحج <?php else: ?> Hajj Packages <?php endif; ?>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(URL::to('/packages')); ?>">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?> باقات العمرة <?php else: ?> Umrah Packages <?php endif; ?>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e(URL::to('/Services')); ?>">
                                                <?php if(Config::get('app.locale') == 'ar'): ?> السياحة الخارجية <?php else: ?> Foreign Tourism <?php endif; ?>
                                                    </a>
                                            </li>
                                        </ul><!-- End Important-Links -->
                                    </div><!-- End Widget-Content -->
                                </div><!-- End Footer-Widget -->
                            </div><!-- End col -->
                            <div class="col-lg-4 subscribe">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?> النشرة البريدية <?php else: ?> News letter <?php endif; ?>
                                        </h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <form class="subscribe-form" method="" action="">
                                            <div class="form-group">
                                                <input class="form-control" type="text" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> اكتب ايميلك <?php else: ?> Write E-mail <?php endif; ?>">
                                                <button class="subscribe-btn" type="submit">
                                                <?php if(Config::get('app.locale') == 'ar'): ?> اشترك <?php else: ?> Subscribe <?php endif; ?></button>
                                            </div><!--End Form-group-->
                                        </form>
                                        <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?> سجل بريدك الالكتروني ليصلك جديد العروض السياحية والتخفيضات من منسك الخير <?php else: ?> Register your e-mail to receive new tourist offers and discounts from the Good Minsk <?php endif; ?>
                                        </p>
                                    </div><!-- End Widget-Content -->
                                </div><!-- End Footer-Widget -->
                            </div><!-- End col -->
                        </div><!-- End row -->
                    </div><!-- End container -->
                </footer><!-- End Footer -->
                <div class="copy-right">
                    <div class="container">
                        <div class="float-right">
                            <?php if(Config::get('app.locale') == 'ar'): ?> © جميع الحقوق محفوظة لصالح <?php else: ?> © All Rights Reserved Mansak Al Khar <?php endif; ?>
                            <a href="<?php echo e(URL::to('/')); ?>">
                            <?php if(Config::get('app.locale') == 'ar'): ?> منسك الخير <?php else: ?> Mansak El Kheir <?php endif; ?></a>
                        </div>
                        <div class="float-left">
                            <?php if(Config::get('app.locale') == 'ar'): ?> تصميم و برمجة <?php else: ?> Design and develope <?php endif; ?>
                            <a href="http://upureka.com/">Upureka</a>
                        </div>
                    </div><!-- End container -->
                </div><!-- End Copy-Right -->
                
            </div><!--End main-->    
        </div><!--End wrapper-->
        
        <!-- Base & Vendors
        ========================== -->        
        <script src="<?php echo e(asset('assets/site/vendor/jquery/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/popper.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/bootstrap/js/bootstrap.js')); ?>"></script>
        
        <!-- site-js
        ========================== -->
        <script src="<?php echo e(asset('assets/site/js/main.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/js/custom.js')); ?>"></script>
    </body>
</html>