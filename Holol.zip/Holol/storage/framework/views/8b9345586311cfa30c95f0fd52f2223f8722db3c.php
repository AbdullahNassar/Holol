<?php $__env->startSection('content'); ?>
<div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/icons/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> المدونة <?php else: ?> Blog <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> المدونة <?php else: ?> Blog <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->
                    <section class="section-lg contact-fix">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                   <?php if(Config::get('app.locale') == 'ar'): ?> مقالات العيادة <?php else: ?> Clinic Articles <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('blog')); ?> <?php else: ?> <?php echo e($data->get('blog_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4">
                                        <div class="blog-item">
                                            <div class="blog-item-img">
                                                <img src="<?php echo e(asset('storage/uploads/blog').'/'.$post->image); ?>" alt="...">
                                                <div class="blog-item-hover">
                                                    <a href="<?php echo e(route('site.post' , ['id' => $post->id])); ?>" class="">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> اقرأ المزيد <?php else: ?> Read More <?php endif; ?><i class="fa fa-angle-left"></i>
                                                    </a>
                                                </div><!--End Blog-item-hover-->
                                            </div><!--End Widget-box-img-->
                                            <div class="blog-item-content">
                                                <div class="blog-info">
                                                    <h3 class="text">
                                                        <span><?php if(Config::get('app.locale') == 'ar'): ?> بواسطة <?php else: ?> By <?php endif; ?></span> 
                                                        <span><?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($post->name); ?> <?php else: ?> <?php echo e($post->name_en); ?> <?php endif; ?></span>
                                                        <span><?php echo e($post->created_at); ?> </span>
                                                    </h3>
                                                </div><!--End cont-head-->
                                                <h2 class="title">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($post->title); ?> <?php else: ?> <?php echo e($post->title_en); ?> <?php endif; ?>
                                                </h2>
                                            </div><!--End Widegt-box-content-->
                                        </div><!--End Widget-box-->
                                    </div><!--End Col-md-4-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>