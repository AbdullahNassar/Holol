<?php $__env->startSection('title'); ?>
الأطباء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">جدول المستخدمين</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <div class="row">
                    <div class="col-md-6">
                        <div class="btn-group">
                            <a href="<?php echo e(route('admin.user.add')); ?>" class="box-btn ">
                                اضافة مستخدم جديد
                                <i class="fa fa-plus"></i>
                            </a>
                        </div>
                    </div><!-- End col -->
                </div><!--End Row-->
                <div id="sample_editable_1_wrapper" class="dataTables_wrapper no-footer">
                    <div class="row">

                    </div>
                    <div class="table-scrollable">
                        <table class="table table-striped dataTable no-footer" role="grid">
                            <thead>
                                <tr role="row">
                                    <th> الترتيب </th>
                                    <th> الصورة </th>
                                    <th> الاسم </th>
                                    <th> البريد الالكترونى </th>
                                    <th> تعديل </th>
                                    <th> حذف </th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="even">
                                    <td class="sorting_1"><?php echo e($user->id); ?> </td>
                                    <td style="max-width: 200px;">
                                        <img src="<?php echo e(asset('storage/uploads/users/'. $user->image)); ?>">
                                    </td>
                                    <td>
                                        <?php echo e($user->name); ?>

                                        
                                    </td>
                                    <td>
                                        <?php echo e($user->email); ?>

                                        
                                    </td>
                                    <td>
                                        <a class="custom-btn small green" href="<?php echo e(route('admin.user.edit' , ['id' => $user->id])); ?>"> تعديل </a>
                                    </td>
                                    <td>
                                        <a class="delete custom-btn small red" href="<?php echo e(route('admin.user.delete' , ['id' => $user->id])); ?>"> حذف </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div><!-- End Box-Item-Content -->
            </div><!-- End Box-Item -->
    </section>

</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>