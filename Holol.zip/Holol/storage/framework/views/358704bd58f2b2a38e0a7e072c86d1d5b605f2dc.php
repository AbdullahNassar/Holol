<aside class="main-sidebar">
    <!-- Logo -->
    <a href="<?php echo e(route('admin.home')); ?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <img class="logo-mini" src="<?php echo e(asset('assets/admin/images/logo.png')); ?>">
        <!-- logo for regular state and mobile devices -->
        <img class="logo-lg" src="<?php echo e(asset('assets/admin/images/logo.png')); ?>">
    </a>
    <ul class="sidebar-links">
        <li  class="<?php if(Route::currentRouteName()=='admin.home'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.home')); ?>">
                <i class="fa fa-dashboard"></i>
                <span>لوحة التحكم</span>
            </a>
        </li>
        <li  class="<?php if(Route::currentRouteName()=='admin.slider.index'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.slider.index')); ?>">
                <i class="fa fa-picture-o"></i>
                <span>الإسلايدر</span>
            </a>
        </li>

        <li  class="<?php if(Route::currentRouteName()=='admin.message'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.message')); ?>">
                <i class="fa fa-comments"></i>
                <span>الرسائل</span>
            </a>
        </li>
        <li  class="<?php if(Route::currentRouteName()=='admin.reservation'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.reservation')); ?>">
                <i class="fa fa-bar-chart"></i>
                <span>الحجوزات</span>
            </a>
        </li>
        <li  class="<?php if(Route::currentRouteName()=='admin.services.index'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.services.index')); ?>">
                <i class="fa fa-table"></i>
                <span>الخدمات</span>
            </a>
        </li>
        <li class="<?php if(Route::currentRouteName()=='admin.packages.index'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.packages.index')); ?>">
                <i class="fa fa-cubes"></i>
                <span>الباقات</span>
            </a>
        </li>
        <li class="<?php if(Route::currentRouteName()=='admin.programmes'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.programmes')); ?>">
                <i class="fa fa-cubes"></i>
                <span>البرامج</span>
            </a>
        </li>
        <li class="<?php if(Route::currentRouteName()=='admin.about'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.about')); ?>">
                <i class="fa fa-cubes"></i>
                <span>من نحن</span>
            </a>
        </li>
        <li class="<?php if(Route::currentRouteName()=='admin.contact'): ?> active <?php endif; ?>">
            <a href="<?php echo e(route('admin.contact')); ?>">
                <i class="fa fa-cubes"></i>
                <span>اتصل بنا</span>
            </a>
        </li>
    </ul><!--End sidebar-->
</aside><!--End Main-aside-->