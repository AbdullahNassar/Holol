<?php $__env->startSection('content'); ?>
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            <?php echo e($p->name); ?>

                        </h2>
                        <ol class="breadcrumb">
                          <li><a href="<?php echo e(URL::to('/')); ?>">الرئيسية</a></li>
                          <li class="active"><?php echo e($p->name); ?></li>
                        </ol>
                    </div><!--End Container-->
                </div><!-- End Page-Head -->
                <div class="page-content">
                    <section class="section-lg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="brand-detail-img">
                                        <img src="<?php echo e(asset('storage/uploads/product').'/'.$p->image); ?>">
                                    </div><!-- End Product-Img -->
                                </div><!-- End col -->
                                <div class="col-md-6">
                                    <div class="brand-detail">
                                        <div class="brand-detail-head">
                                            <h3 class="title"><?php echo e($p->name); ?></h3>
                                        </div><!-- End brand-Details-Head -->
                                        <div class="brand-detail-content">
                                            <p>
                                                 <?php echo e($p->content); ?> 
                                            </p>
                                        </div><!-- End Product-Details-Contact -->
                                    </div><!-- End brand-detail -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section>
                </div><!--End page-content-->   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>