<aside class="main-sidebar">
                <!-- Logo -->
                <a href="<?php echo e(route('admin.home')); ?>" class="logo">
                  <!-- mini logo for sidebar mini 50x50 pixels -->
                    <img class="logo-mini" src="<?php echo e(asset('assets/admin/images/logo.png')); ?>">
                  <!-- logo for regular state and mobile devices -->
                    <img class="logo-lg" src="<?php echo e(asset('assets/admin/images/logo.png')); ?>">
                </a>
                <ul class="sidebar-links">
                    <li class="<?php if(Request::route()->getName() == 'admin.home'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.home')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>الرئيسية</span>
                        </a>
                    </li>
                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-newspaper-o"></i>
                            <span>صفحات الموقع</span>
                        </a>
                        <ul class="treeview-menu">
                            <li class="<?php if(Request::route()->getName() == 'admin.slider'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.slider')); ?>">
                                    <span>الإسلايد شو</span>
                                </a>
                            </li>
                            <li class="<?php if(Request::route()->getName() == 'admin.about'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.about')); ?>">
                                    <span>من نحن</span>
                                </a>
                            </li>
                            <li class="<?php if(Request::route()->getName() == 'admin.services'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.services')); ?>">
                                    <span>الخدمات</span>
                                </a>
                            </li>
                            <li class="<?php if(Request::route()->getName() == 'admin.service.data'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.service.data')); ?>">
                                    <span>ثوابت الخدمات</span>
                                </a>
                            </li>
                            <li class="<?php if(Request::route()->getName() == 'admin.doctors'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.doctors')); ?>">
                                    <span>الأطباء</span>
                                </a>
                            </li>
                            <li class="<?php if(Request::route()->getName() == 'admin.data'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.data')); ?>">
                                    <span>البيانات الثابتة</span>
                                </a>
                            </li>
                            <li class="<?php if(Request::route()->getName() == 'admin.stories'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.stories')); ?>">
                                    <span>قصص النجاح</span>
                                </a>
                            </li>
                            <li class="<?php if(Request::route()->getName() == 'admin.gallery'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                                <a href="<?php echo e(route('admin.gallery')); ?>">
                                    <span>معرض الصور</span>
                                </a>
                            </li>
                        </ul><!--End Level-one-tree-->
                    </li>    
                    <li class="<?php if(Request::route()->getName() == 'admin.posts'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.posts')); ?>">
                            <i class="fa fa-newspaper-o"></i>
                            <span>الأخبار</span>
                        </a>
                    </li>              
                    <li class="<?php if(Request::route()->getName() == 'admin.reservation'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.reservation')); ?>">
                            <i class="fa fa-cubes"></i>
                            <span>الحجوزات</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.message'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.message')); ?>">
                            <i class="fa fa-envelope-open"></i>
                            <span>الرسائل</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.contacts'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.contacts')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>بيانات الموقع</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.users'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.users')); ?>">
                            <i class="fa fa-cubes"></i>
                            <span>المستخدمون</span>
                        </a>
                    </li>
                </ul><!--End sidebar-->
            </aside><!--End Main-aside-->
