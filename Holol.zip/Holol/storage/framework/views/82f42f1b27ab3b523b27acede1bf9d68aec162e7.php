<?php $__env->startSection('content'); ?>
<div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            المنتجات
                        </h2>
                        <ol class="breadcrumb">
                          <li><a href="<?php echo e(URL::to('/')); ?>">الرئيسية</a></li>
                          <li class="active">المنتجات</li>
                        </ol>
                    </div><!--End Container-->
                </div><!-- End Page-Head -->
                <div class="page-content">
                    <section class="section-lg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="toggle-container style-2" id="product">
                                         <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="panel">
                                            <a href="#item-<?php echo e($loop->index + 1); ?>" data-toggle="collapse" data-parent="#product">
                                                <?php echo e($cat->cat_name); ?>

                                            </a>
                                            <div class="panel-collapse collapse <?php if($loop->index == 0): ?> in <?php endif; ?>" id="item-<?php echo e($loop->index + 1); ?>">
                                                <div class="panel-content">
                                                    <?php if($cat->parent == 1): ?>   
                                                    <ul class="">
                                                        <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($s->category_id == $cat->cat_id): ?>
                                                        <li><a href="<?php echo e(route('site.sub' , ['id' => $s->sub_id])); ?>"><?php echo e($s->sub_name); ?></a></li>
                                                         <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                    <?php endif; ?>
                                                </div><!-- end content -->
                                            </div><!--End panel-collapse-->
                                        </div><!--End Panel-->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div><!--End toggle-container-->
                                </div><!-- End col -->
                                <div class="col-md-9">
                                    <div class="row">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="widget">
                                                <div class="widget-head">
                                                    <img src="<?php echo e(asset('storage/uploads/product').'/'.$p->image); ?>" alt="">
                                                </div><!-- End widget-Head -->
                                                <div class="widget-content">
                                                    <a href="<?php echo e(route('site.product' , ['id' => $p->p_id])); ?>">
                                                        <?php echo e($p->name); ?>

                                                    </a>
                                                    <p>
                                                        <?php echo e($p->sub_name); ?>

                                                    </p>
                                                </div><!-- End widget-Content -->
                                            </div><!-- End widget -->
                                        </div><!-- End col -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div><!-- End row -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                </div><!--End page-content-->  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>