<?php $__env->startSection('content'); ?>
                <div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/icons/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> معرض الصور <?php else: ?> Gallery <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> معرض الصور <?php else: ?> Gallery <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->
                <div class="page-content">
                    <section class="section-lg contact-fix gallery">
                        <div class="container">
                            <div class="section-head">
                                <ul class="mix-list">
                                   <li class="active filter" data-filter="all"><?php if(Config::get('app.locale') == 'ar'): ?> الكل <?php else: ?> All <?php endif; ?></li>
                                   <li class="filter" data-filter=".clinic"><?php if(Config::get('app.locale') == 'ar'): ?> العيادة <?php else: ?> Clinic <?php endif; ?></li>
                                   <li class="filter" data-filter=".certification"><?php if(Config::get('app.locale') == 'ar'): ?> الشهادات <?php else: ?> Certification <?php endif; ?></li>
                                   <li class="filter" data-filter=".team"><?php if(Config::get('app.locale') == 'ar'): ?> فريق الأطباء <?php else: ?> Doctors Team <?php endif; ?></li>
                                </ul>
                            </div><!--End Section-head-->
                            <div class="section-content">
                                <div class="row" id="gallery">
                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-sm-4 mix <?php echo e($image->type); ?>">
                                        <div class="gallery-item">
                                            <div class="gallery-img">
                                                <a href="<?php echo e(asset('storage/uploads/gallery').'/'.$image->image); ?>" class="image-corners">
                                                    <img src="<?php echo e(asset('storage/uploads/gallery').'/'.$image->image); ?>">
                                                    <div class="gallery-hover">
                                                        <i class="fa fa-plus"></i>
                                                    </div><!--End Gallery-hover-->
                                                </a>
                                            </div><!-- End Block-Head -->
                                        </div><!--End gallery-item-->
                                    </div><!--End Col-md-4-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>