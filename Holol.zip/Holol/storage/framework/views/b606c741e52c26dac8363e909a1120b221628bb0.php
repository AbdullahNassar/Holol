<?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="main">
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            <?php if(Config::get('app.locale') == 'ar'): ?> اتصل بنا <?php else: ?> Contact Us <?php endif; ?>
                        </h2>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('site.home')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page"><?php if(Config::get('app.locale') == 'ar'): ?> اتصل بنا <?php else: ?> Contact Us <?php endif; ?></li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <div class="page-content">
                    <section class="section-md">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8">
                                    <form class="contact-form" method="post" action="">
                                    	<?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <h3 class="title-lg">
                                            	<?php if(Config::get('app.locale') == 'ar'): ?> أرسل رسالة <?php else: ?> Send a message <?php endif; ?>
                                            </h3>
                                        </div><!-- End form-group -->
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <input type="text" name="name" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم <?php else: ?> Name <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <input type="text" name="phone" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الهاتف <?php else: ?> Phone <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <input type="email" name="email" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> البريد الالكتروني <?php else: ?> E-mail Address <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <textarea class="form-control" name="message" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الرسالة <?php else: ?> Message <?php endif; ?>" rows="9"></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <button class="custom-btn" type="submit">
                                                    	<?php if(Config::get('app.locale') == 'ar'): ?> أرسل <?php else: ?> Send <?php endif; ?>
                                                    </button>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                        </div><!-- End row -->
                                    </form><!-- End contact-form -->
                                </div><!-- End col -->
                                <div class="col-lg-4">
                                    <div class="contact-info">
                                        <h3 class="title-lg"><?php if(Config::get('app.locale') == 'ar'): ?> معلومات التواصل <?php else: ?> Contact Us <?php endif; ?></h3>
                                        <ul class="contact-list">
                                            <li>
                                                <?php if(Config::get('app.locale') == 'ar'): ?><span>الهاتف: </span><?php else: ?><span>Phone: </span><?php endif; ?>
                                                <span>
                                                    <i class="fa fa-phone"></i>
                                                    <?php echo e($data->get('phone')); ?>

                                                </span>
                                            </li>
                                            <li>
                                                <?php if(Config::get('app.locale') == 'ar'): ?><span>البريد الالكتروني: </span><?php else: ?><span>E-mail: </span><?php endif; ?>
                                                <span>
                                                    <i class="fa fa-envelope"></i>
                                                    <?php echo e($data->get('email')); ?>

                                                </span>
                                            </li>
                                            <li class="location">
                                                <?php if(Config::get('app.locale') == 'ar'): ?><span>العنوان: </span><?php else: ?><span>Address: </span><?php endif; ?>
                                                <span>
                                                    <i class="fa fa-map-marker"></i>
                                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('address')); ?> <?php else: ?> <?php echo e($data->get('address_en')); ?> <?php endif; ?>
                                                </span>
                                            </li>
                                        </ul><!-- End Contact-List -->
                                    </div><!-- End Contact-Info -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <div class="map-wrap">
                        <div id="map"></div>
                    </div><!--End map-wrap-->
                </div><!--End page-content-->
<?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>