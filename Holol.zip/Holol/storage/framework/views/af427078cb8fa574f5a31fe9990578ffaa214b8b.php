<footer class="footer">
    <div class="pull-left">
        جميع الحقوق محفوظة لصالح  
        ©<a href="http://upureka.com">Upureka</a> 
    </div>
    <div class="pull-right">
        تصميم &amp; تطوير
        <a href="http://upureka.com" target="_blank">upureka</a>
    </div>
</footer><!--End footer-->