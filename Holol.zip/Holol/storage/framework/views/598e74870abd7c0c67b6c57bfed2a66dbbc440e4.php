<?php $__env->startSection('content'); ?>
                <section class="home-slider">
                    <div id="slider">
                        <div class="fullwidthbanner-container">
                            <div id="revolution-slider">
                                <ul>
                                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-transition="random" data-slotamount="7" data-masterspeed="800">
                                        <img src="<?php echo e(asset('storage/uploads/slider').'/'.$slider->image); ?>" alt="">
                                        <div class="tp-caption sfr stt custom-font-1 tp-resizeme"
                                             data-x="right"
                                             data-hoffset="0"
                                             data-y="140"
                                             data-speed="400"
                                             data-start="700"
                                             data-easing="easeInOut">
                                            <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($slider->_header); ?> <?php else: ?> <?php echo e($slider->_header_en); ?> <?php endif; ?>
                                        </div>
                                        <div class="tp-caption sfr stb custom-font-2 tp-resizeme"
                                             data-x="right"
                                             data-hoffset="0"
                                             data-y="290"
                                             data-speed="400"
                                             data-start="1000"
                                             data-easing="easeInOut">
                                             <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($slider->content); ?> <?php else: ?> <?php echo e($slider->content_en); ?> <?php endif; ?>
                                        </div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div><!--End fullwidthbanner-container-->
                    </div><!--End slider-->
                </section><!--End home-slider-->  
                    <section class="section-md about">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-5">
                                    <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="section-img">
                                        <img src="<?php echo e(asset('storage/uploads/about').'/'.$a->image); ?>" alt="about">
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->
                                <div class="col-md-7">
                                    <div class="section-head">
                                        <h3 class="section-title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?> من نحن <?php else: ?> About Us <?php endif; ?>
                                        </h3>
                                        <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($a->p1); ?> <?php else: ?> <?php echo e($a->p1_en); ?> <?php endif; ?>
                                        </p>
                                        <p>
                                             <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($a->p2); ?> <?php else: ?> <?php echo e($a->p2_en); ?> <?php endif; ?>
                                        </p>
                                        <a href="<?php echo e(URL::to('/about')); ?>" class="more">
                                            
                                            <?php if(Config::get('app.locale') == 'ar'): ?> المزيد <?php else: ?> More <?php endif; ?>
                                            <i class="fa fa-plus"></i>
                                        </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <section class="section-lg colored">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?> خدمات العيادة <?php else: ?> Clinic Services <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('services')); ?> <?php else: ?> <?php echo e($data->get('services_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="widget-box service">
                                            <div class="widget-box-img">
                                                <img src="<?php echo e(asset('storage/uploads/services').'/'.$service->image); ?>" alt="...">
                                            </div><!--End Widget-box-img-->
                                            <div class="widget-box-content">
                                                <div class="cont">
                                                    <a class="title" href="<?php echo e(route('site.service' , ['id' => $service->id])); ?>">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->_header); ?> <?php else: ?> <?php echo e($service->_header_en); ?> <?php endif; ?>
                                                    </a>
                                                    <span class="icon">
                                                        <img src="<?php echo e(asset('assets/site/images/icons/tooth-1.png')); ?>" alt="...">
                                                    </span>
                                                    <p>
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->_paragraph); ?> <?php else: ?> <?php echo e($service->_paragraph_en); ?> <?php endif; ?>
                                                    </p>
                                                </div><!--End cont-head-->
                                            </div><!--End Widegt-box-content-->
                                        </div><!--End Widget-box-->
                                    </div><!--End Col-md-4-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
                    <section class="section-lg">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> فريق الأطباء <?php else: ?> Doctors Team <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('doctors')); ?> <?php else: ?> <?php echo e($data->get('doctors_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6">
                                        <div class="widget-box">
                                            <div class="widget-box-img">
                                                <img src="<?php echo e(asset('storage/uploads/doctors').'/'.$doctor->image); ?>" alt="...">
                                            </div><!--End Widget-box-img-->
                                            <div class="widget-box-content">
                                                <div class="cont">
                                                    <h3 class="title">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($doctor->name); ?> <?php else: ?> <?php echo e($doctor->name_en); ?> <?php endif; ?>
                                                    </h3>
                                                    <span class="text">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($doctor->title); ?> <?php else: ?> <?php echo e($doctor->title_en); ?> <?php endif; ?>
                                                    </span>
                                                </div><!--End cont-head-->
                                            </div><!--End Widegt-box-content-->
                                        </div><!--End Widget-box-->
                                    </div><!--End Col-md-3-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
                    <section class="section-md testimonial">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?> قصص النجــاح <?php else: ?> Success Stories <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('stories')); ?> <?php else: ?> <?php echo e($data->get('stories_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <div class="col-md-7">
                                        
                                        <div class="slider-widget">

                                            <div id="success-story" class="success-story carousel slide" data-ride="carousel">
                                                <ol class="carousel-indicators">
                                                    <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li data-target="#success-story" data-slide-to="<?php echo e($loop->index); ?>" class="<?php if($loop->index==0): ?> active <?php endif; ?>"></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ol>
                                                <div class="carousel-inner" role="listbox">
                                                    <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="item <?php if($loop->index==0): ?> active <?php endif; ?>" >
                                                        <div class="caption">
                                                            <p>
                                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($story->story); ?> <?php else: ?> <?php echo e($story->story_en); ?> <?php endif; ?>
                                                            </p>
                                                            <div class="Caption-owner">
                                                                <h3 class="title title-sm">
                                                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($story->name); ?> <?php else: ?> <?php echo e($story->name_en); ?> <?php endif; ?>
                                                                </h3>
                                                                <span><?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($story->title); ?> <?php else: ?> <?php echo e($story->title_en); ?> <?php endif; ?></span>
                                                            </div><!-- End caption-Owner -->
                                                        </div><!-- End Caption -->
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>  
                                        </div><!-- End Slider Widget -->
                                    </div><!-- End col -->
                                    <div class="col-md-5">
                                        <div class="section-img">
                                            <img src="<?php echo e(asset('assets/site/images/png.png')); ?>" alt="">
                                        </div><!-- End Section-Img -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <section class="section-md contact-fix">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> تواصـــل معنــا <?php else: ?> Contact Us <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('contacts')); ?> <?php else: ?> <?php echo e($data->get('contacts_en')); ?> <?php endif; ?>
                                </p>
                            </div>                   
                            <div class="section-content">
                                <div class="row">
                                    <div class="col-md-7">
                                        <form class="form" method="post" action="<?php echo e(URL::to('/send')); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" name="first_name" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم الاول <?php else: ?> First Name <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" name="last_name" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم الاخير <?php else: ?> Last Name <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="email" name="email" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> البريد الالكتروني <?php else: ?> E-mail Address <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="tel" name="phone" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> رقم الهاتف <?php else: ?> Phone Number <?php endif; ?>" required>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <textarea class="form-control" name="message" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> اكتب رسالتك <?php else: ?> Write Message <?php endif; ?>" rows="8" required></textarea>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button type="submit" class="custom-btn"><?php if(Config::get('app.locale') == 'ar'): ?> ارســــــــــــــال <?php else: ?> Send <?php endif; ?></button>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                            </div><!-- End row -->
                                        </form>
                                    </div><!-- End col -->
                                    <div class="col-md-5">
                                        <div class="section-img">
                                            <img src="<?php echo e(asset('assets/site/images/png.png')); ?>" alt="">
                                        </div><!-- End Section-Img -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>