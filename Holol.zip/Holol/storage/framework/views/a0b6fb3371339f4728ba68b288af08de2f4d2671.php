<?php $__env->startSection('title'); ?>
البيانات الثابتة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">البيانات الثابتة</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" method="post" id="">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                            <div class="form-group">
                            <div class="choose-img">
                                <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                <input type="hidden" value="services" id="storage" >
                                <input type="hidden" name="image" value="<?php echo e($d->image); ?>" id="img" >
                                <input type="file" name="image" id="image" required>
                                    <?php if($d->image): ?>
                                    <img src="<?php echo e(asset('storage/uploads/services').'/'.$d->image); ?>"/>
                                    <?php else: ?>
                                    <p>اضغط لتحميل صورة</p>
                                    <?php endif; ?>
                            </div><!-- End Choose-Img -->
                            <div class="upload-action">
                                <button class="upload-btn" type="button" id="upload-btn">
                                    تحميل الصورة
                                </button>
                                <div class="progress">
                                    <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                    </div>
                                </div>
                                <h3 id="status"></h3>
                                <p id="loaded_n_total"></p>
                            </div><!--End upload-action-->
                        </div>
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>المحتوى الاول</label>
                                    <input value="<?php echo e($d->p1); ?>" name="p1" type="text" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>First Content</label>
                                    <input value="<?php echo e($d->p1_en); ?>" name="p1_en" type="text" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>المحتوى الثانى</label>
                                    <input type="text" name="p2" value="<?php echo e($d->p2); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Second Content</label>
                                    <input type="text" name="p2_en" value="<?php echo e($d->p2_en); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>اساسيات الخدمات</label>
                                    <input type="text" class="form-control" required name="block1" value="<?php echo e($d->block1); ?>"><br>
                                    <input type="text" class="form-control" required name="block2" value="<?php echo e($d->block2); ?>"><br>
                                    <input type="text" class="form-control" required name="block3" value="<?php echo e($d->block3); ?>"><br>
                                    <input type="text" class="form-control" required name="block4" value="<?php echo e($d->block4); ?>"><br>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>EN Blocks</label>
                                    <input type="text" class="form-control" required name="block1_en" value="<?php echo e($d->block1_en); ?>"><br>
                                    <input type="text" class="form-control" required name="block2_en" value="<?php echo e($d->block2_en); ?>"><br>
                                    <input type="text" class="form-control" required name="block3_en" value="<?php echo e($d->block3_en); ?>"><br>
                                    <input type="text" class="form-control" required name="block4_en" value="<?php echo e($d->block4_en); ?>"><br>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->

                        </div>
                            <div class="col-xs-12">
                                <div class="alert alert-success" style="display: none;" role="alert">
                                    تم تحديث البيانات بنجاح
                                </div>

                                <div class="alert alert-danger" style="display: none;" role="alert">

                                </div>
                            </div><!--End Col-->

                        </div><!--End Row-->


                    </div><!--End Form-body-->
                    <div class="form-action">
                        <div class="row">
                            <div class="col-xs-12">
                                <button class="custom-btn" type="submit">حفظ التغييرات</button>
                            </div><!--End Col-->
                        </div><!--End Row-->
                    </div><!--End Form-action-->
                    
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>