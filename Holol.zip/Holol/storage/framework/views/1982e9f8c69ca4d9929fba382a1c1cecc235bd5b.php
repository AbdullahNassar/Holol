<?php $__env->startSection('title'); ?>
البرامج
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">جدول  البرامج</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <div class="row">
                    <div class="col-md-6">
                        <div class="btn-group">
                            <a href="<?php echo e(route('admin.program.add')); ?>" class="box-btn ">
                                اضافة برنامج جديد
                                <i class="fa fa-plus"></i>
                            </a>
                        </div>
                    </div><!-- End col -->
                </div><!--End Row-->
                <div id="sample_editable_1_wrapper" class="dataTables_wrapper no-footer">
                    <div class="row">

                    </div>
                    <div class="table-scrollable">
                        <table class="table table-striped dataTable no-footer" role="grid">
                            <thead>
                                <tr role="row">
                                    <th> # </th>
                                    <th> الاسم </th>
                                    <th> المحتوى  </th>
                                    <th> الترتيب </th>
                                    <th> الباقة </th>
                                    <th> تعديل </th>
                                    <th> حذف </th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="even">
                                    <td class="sorting_1"><?php echo e($program->id); ?> </td>
                                    <td>
                                        <?php echo e($program->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($program->content); ?>

                                    </td>
                                    <td>
                                        <?php echo e($program->_order); ?>

                                    </td>
                                    <td>
                                        <?php echo e($program->title); ?>

                                    </td>
                                    <td>
                                        <a class="custom-btn small green" href="<?php echo e(route('admin.program.edit' , ['id' => $program->id])); ?>"> تعديل </a>
                                    </td>
                                    <td>
                                        <a class="delete custom-btn small red" href="<?php echo e(route('admin.program.delete' , ['id' => $program->id])); ?>"> حذف </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div><!-- End Box-Item-Content -->
            </div><!-- End Box-Item -->
    </section>

</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>