<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">اضافة</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" action="<?php echo e(route('admin.post.add')); ?>" enctype="multipart/form-data" method="post" onsubmit="return false;">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="choose-img">
                                        <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                        <input type="hidden" value="blog" id="storage" >
                                        <input type="hidden" name="image"  id="img" >
                                        <input type="file" name="image" id="image">
                                        <p style="font-size: large;">اضغط لتحميل صورة</p>
                                    </div><!-- End Choose-Img -->
                                    <div class="upload-action"><br>
                                        <button class="upload-btn" type="button" id="upload-btn">
                                            تحميل الصورة
                                        </button>
                                        <div class="progress">
                                            <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                            </div>
                                        </div>
                                        <h3 id="status"></h3>
                                        <p id="loaded_n_total"></p>
                                    </div><!--End upload-action-->
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="choose-img">
                                        <input type="hidden" value="<?php echo e(route('admin.upload.icon')); ?>" id="url2" >
                                        <input type="hidden" value="blog" id="storage2" >
                                        <input type="hidden" name="image2" id="img2" >
                                        <input type="file" name="image2" id="image2" required>
                                        <p style="font-size: large;">اضغط لتحميل أيكونة</p>
                                    </div><!-- End Choose-Img -->
                                    <div class="upload-action">
                                        <button class="upload-btn" type="button" id="upload-btn2">
                                            تحميل أيكونة
                                        </button>
                                        <div class="progress">
                                            <div id="progressBar2" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                            </div>
                                        </div>
                                        <h3 id="status2"></h3>
                                        <p id="loaded_n_total2"></p><br>

                                        <h5>التفعيل</h5><br>
                                        <select class="form-control" name="active">
                                            <option value="----------"></option>
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select>
                                        <br>
                                    </div><!--End upload-action-->
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>عنوان المنشور باللغة العربية</label>
                                    <input type="text" class="form-control" name="title_ar">
                                </div><!--End Form-group-->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Post Title in English</label>
                                    <input type="text" class="form-control" name="title_en">
                                </div><!--End Form-group-->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>وصف المنشور باللغة العربية</label>
                                    <textarea class="form-control" rows="5" name="head_ar"></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Post Header in English</label>
                                    <textarea class="form-control" rows="5" name="head_en"></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>محتوى المنشور باللغة العربية</label>
                                    <textarea class="form-control" rows="10" name="content_ar"></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Post Content in English</label>
                                    <textarea class="form-control" rows="10" name="content_en"></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>تاريخ المنشور باللغة العربية</label>
                                    <select class="form-control" name="day_ar" required>
                                            <option>اليوم</option>
                                            <?php for($f = 1; $f < 32; $f++): ?>
                                            <option value="<?php echo e($f); ?>"><?php echo e($f); ?></option>
                                            <?php endfor; ?>
                                    </select><hr>
                                    <select class="form-control" name="month_ar" required>
                                            <option>الشهر</option>
                                            <option value="يناير">يناير</option>
                                            <option value="فبراير">فبراير</option>
                                            <option value="مارس">مارس</option>
                                            <option value="ابريل">ابريل</option>
                                            <option value="مايو">مايو</option>
                                            <option value="يونيو">يونيو</option>
                                            <option value="يوليو">يوليو</option>
                                            <option value="أغسطس">أغسطس</option>
                                            <option value="سبتمبر">سبتمبر</option>
                                            <option value="أكتوبر">أكتوبر</option>
                                            <option value="نوفمبر">نوفمبر</option>
                                            <option value="ديسمبر">ديسمبر</option>
                                    </select><hr>
                                    <select class="form-control" name="year_ar" required>
                                            <option>السنة</option>
                                        <?php for($s = 2018; $s < 2050; $s++): ?>
                                            <option value="<?php echo e($s); ?>"><?php echo e($s); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Post Date in English</label>
                                    <select class="form-control" name="day_en" required>
                                            <option>Day</option>
                                            <?php for($i = 1; $i < 32; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                    </select><hr>
                                    <select class="form-control" name="month_en" required>
                                            <option>Month</option>
                                            <option value="January">January</option>
                                            <option value="February">February</option>
                                            <option value="March">March</option>
                                            <option value="April">April</option>
                                            <option value="May">May</option>
                                            <option value="June">June</option>
                                            <option value="July">July</option>
                                            <option value="August">August</option>
                                            <option value="September">September</option>
                                            <option value="October">October</option>
                                            <option value="November">November</option>
                                            <option value="December">December</option>
                                    </select><hr>
                                    <select class="form-control" name="year_en" required>
                                            <option>Year</option>
                                        <?php for($j = 2018; $j < 2050; $j++): ?>
                                            <option value="<?php echo e($j); ?>"><?php echo e($j); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                        </div>
                        <div class="form-action">
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="custom-btn addBTN" type="submit">حفظ التغييرات</button>
                                    <a href="<?php echo e(route('admin.posts')); ?>" class="custom-btn" style="margin-right: 20px;">أغلق</a>
                                </div><!--End Col-->
                            </div><!--End Row-->
                        </div><!--End Form-action-->
                    </div>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>