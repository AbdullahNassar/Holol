
<!DOCTYPE html>
<html>
    <head>
        <!-- Meta Tags
        ========================== -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <!-- Site Title
        ========================== -->
        <title>Dental</title>
        
        <!-- Favicon
		===========================-->
        
        <!-- Base & Vendors
        ========================== -->
        <?php if(Config::get('app.locale') == 'ar'): ?>
        <link href="<?php echo e(asset('assets/site/vendor/bootstrap/css/bootstrap-ar.css')); ?>" rel="stylesheet">
        <?php elseif(Config::get('app.locale') == 'en'): ?>
            <link href="<?php echo e(asset('assets/site/vendor/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet">
        <?php endif; ?>
        <link href="<?php echo e(asset('assets/site/vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/rs-plugin/css/settings.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/pace-1.0.2/themes/red/pace-theme-loading-bar.css')); ?>">
        <!-- Site Style
        ========================== -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/style.css')); ?>">
        <?php if(Config::get('app.locale') == 'en'): ?>
            <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/style-en.css')); ?>">
        <?php else: ?>
        <?php endif; ?>
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js')}}"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js')}}"></script>
        <![endif]-->
    </head>
    <body>
        <div class="preloader"></div>
        <div class="wrapper">
            <div class="header">
                <?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="main">
                <div class="page-content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div><!-- End Page-Content -->
                    <?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div><!--End Page-content-->
        </div><!-- End Wrapper -->

        <!-- JS Base & Vendors
        ========================== -->
        <script src="<?php echo e(asset('assets/site/vendor/jquery/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/bootstrap/js/bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/rs-plugin/js/jquery.themepunch.tools.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/rs-plugin/js/jquery.themepunch.revolution.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/owl-carousel/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/jquery.mixitup.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/pace-1.0.2/pace.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/prettyPhoto/js/jquery.prettyPhoto.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/Magnific-Popup-master/dist/jquery.magnific-popup.js')); ?>"></script>

        <!--<script src="http://maps.googleapis.com/maps/api/js"></script> 
        <script src="<?php echo e(asset('assets/site/js/google.js')); ?>"></script> -->
        
        <!-- Site JS
        ========================== -->
        <script src="<?php echo e(asset('assets/site/js/main.js')); ?>"></script>
    </body>
</html>