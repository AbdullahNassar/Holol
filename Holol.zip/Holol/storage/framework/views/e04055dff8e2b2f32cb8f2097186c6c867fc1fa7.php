<?php $__env->startSection('title'); ?>
الأخبار
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">حذف</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" method="post" action=""  id="dropzone_image">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                        <div class="form-group">
                            <div class="choose-img">
                                <input type="hidden" name="s_id" value="<?php echo e($post->id); ?>">
                                <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                <input type="hidden" value="posts" id="storage" >
                                <input type="hidden" name="image" value="<?php echo e($post->image); ?>" id="img" >
                                <input type="file" name="image" id="image">
                                    <?php if($post->image): ?>
                                    <img src="<?php echo e(asset('storage/uploads/posts').'/'.$post->image); ?>"/>
                                    <?php else: ?>
                                    <p>اضغط لتحميل صورة</p>
                                    <?php endif; ?>
                            </div><!-- End Choose-Img -->
                            <div class="upload-action">
                                <button class="upload-btn" type="button" id="upload-btn">
                                    تحميل الصورة
                                </button>
                                <div class="progress">
                                    <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                    </div>
                                </div>
                                <h3 id="status"></h3>
                                <p id="loaded_n_total"></p>
                            </div><!--End upload-action-->
                        </div>
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>العنوان</label>
                                    <input type="text" class="form-control" required name="title" value="<?php echo e($post->title); ?>">
                                </div><!--End Form-group-->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Title</label>
                                    <input type="text" class="form-control" required name="title_en" value="<?php echo e($post->title_en); ?>">
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>المحتوى</label>
                                    <textarea class="form-control" required rows="5" name="content"><?php echo e($post->content); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Content</label>
                                    <textarea class="form-control" required rows="5" name="content_en"><?php echo e($post->content_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الترتيب</label>
                                    <input type="text" class="form-control" required name="_order" value="<?php echo e($post->_order); ?>">
                                </div><!-- End Form-Group -->
                            </div>
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>التفعيل</label>
                                    <select class="form-control"  name="active" required>
                                        <option value="<?php echo e($post->active); ?>"><?php if($post->active == 1): ?>
                                                                                نعم
                                                                                <?php elseif($post->active == 0): ?>
                                                                                لا
                                                                                <?php endif; ?> 
                                        </option>
                                        <option value="1">نعم</option>
                                        <option value="0">لا</option>
                                    </select>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>User</label>
                                    <select class="form-control" required name="user_id">
                                        <option value="<?php echo e($post->user_id); ?>"><?php echo e($post->name); ?></option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                            </div><!--End Row-->
                        </div><!--End Form-body-->
                        <div class="form-action">
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="custom-btn" type="submit">حذف</button>
                                </div><!--End Col-->
                            </div><!--End Row-->
                        </div><!--End Form-action-->
                    </div>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>