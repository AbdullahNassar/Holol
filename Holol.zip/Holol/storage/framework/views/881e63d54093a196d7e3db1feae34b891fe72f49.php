<?php $__env->startSection('title'); ?>
Slider
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">تعديل</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" method="post" action="" >
                    <div class="form-body">
                        <div class="row">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="choose-img">
                                        <input type="hidden" name="s_id" value="<?php echo e($slider->id); ?>">
                                        <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                        <input type="hidden" value="slider" id="storage" >
                                        <input type="hidden" name="image" value="<?php echo e($slider->image); ?>" id="img" >
                                        <input type="file" name="image" id="image">
                                        <?php if($slider->image): ?>
                                        <img src="<?php echo e(asset('storage/uploads/slider').'/'.$slider->image); ?>"/>
                                        <?php else: ?>
                                        <p>اضغط لتحميل صورة</p>
                                        <?php endif; ?>
                                    </div><!-- End Choose-Img -->
                                    <div class="upload-action">
                                        <button class="upload-btn" type="button" id="upload-btn">
                                            تحميل الصورة
                                        </button>
                                        <div class="progress">
                                            <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                            </div>
                                        </div>

                                        <h3 id="status"></h3>
                                        <p id="loaded_n_total"></p><br>
                                        <h5>التفعيل</h5><br>
                                        <select class="form-control" name="active">
                                            <option value="<?php echo e($slider->active); ?>"><?php if($slider->active == 1): ?>
                                                                                  نعم
                                                                                  <?php elseif($slider->active == 0): ?>
                                                                                  لا
                                                                                  <?php endif; ?> 
                                            </option>
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select><hr>
                                        <h5>الترتيب</h5><br>
                                        <input type="text" name="_order" class="form-control" value="<?php echo e($slider->_order); ?>" required>
                                        <br>
                                    </div><!--End upload-action-->
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                        </div><!--End Row-->
                    </div><!--End Form-body-->
                    <div class="form-action">
                        <div class="row">
                            <div class="col-xs-12">
                                <button class="custom-btn" type="submit">حفظ التغييرات</button>
                            </div><!--End Col-->
                        </div><!--End Row-->
                    </div><!--End Form-action-->
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>