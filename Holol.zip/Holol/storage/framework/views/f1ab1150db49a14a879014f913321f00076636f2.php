<?php $__env->startSection('content'); ?>
<div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            اتصل بنا
                        </h2>
                        <ol class="breadcrumb">
                          <li><a href="<?php echo e(URL::to('/')); ?>">الرئيسية</a></li>
                          <li class="active">اتصل بنا</li>
                        </ol>
                    </div><!--End Container-->
                </div><!-- End Page-Head -->
                <div class="page-content">
                    <section class="section-lg contact">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="section-head">
                                        <h3 class="section-title no-before">تواصل معنا من اي مكان</h3><!-- End Section-Title -->
                                        <p>
                                            <?php echo e($data->get('contact')); ?>

                                        </p>
                                    </div><!-- End Section-Head -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                            <div class="section-content">
                                <div class="row">
                                    <div class="col-md-8">
                                        <form class="form" action="<?php echo e(route('site.message')); ?>" enctype="multipart/form-data" method="post" onsubmit="return false;">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="الاسم الكامل" name="name">
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="tel" class="form-control" placeholder="الهاتف" name="phone">
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="email" class="form-control" placeholder="البريد الالكتروني" name="email">
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <input type="text" class="form-control" placeholder="الموضوع" name="subject">
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <textarea class="form-control" placeholder="اكتب رسالتك" rows="6" name="message"></textarea>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <button type="submit" class="custom-btn addBTN">أرسل رسالة</button>
                                                    </div><!-- End Form-Group -->
                                                </div><!-- End col -->
                                            </div><!-- End row -->
                                        </form>
                                    </div><!-- End col-->
                                    <div class="col-md-4">
                                        <div class="contact-info">
                                            <div class="contact-widget has-bg">
                                                <div class="contact-icon">
                                                    <img src="<?php echo e(asset('assets/site/images/icons/contact-icon-1.png')); ?>">
                                                </div><!-- End Contact-Widget-Head -->
                                                <div class="contact-body">
                                                    <span> الهاتف </span>
                                                    <span class="en-text"> <?php echo e($contact->get('phone')); ?></span>
                                                </div><!-- End Contact-Body -->
                                            </div><!-- End Contact-Widget -->
                                            <div class="contact-widget has-bg">
                                                <div class="contact-icon">
                                                    <img src="<?php echo e(asset('assets/site/images/icons/contact-icon-2.png')); ?>">
                                                </div><!-- End Contact-Widget-Head -->
                                                <div class="contact-body">
                                                    <span> البريد الالكتروني </span>
                                                    <span class="en-text">  <?php echo e($contact->get('email')); ?> </span>
                                                </div><!-- End Contact-Body -->
                                            </div><!-- End Contact-Widget -->
                                            <div class="contact-widget has-bg">
                                                <div class="contact-icon">
                                                    <img src="<?php echo e(asset('assets/site/images/icons/contact-icon-3.png')); ?>">
                                                </div><!-- End Contact-Widget-Head -->
                                                <div class="contact-body">
                                                    <span> العنوان </span>
                                                    <span>  <?php echo e($contact->get('address')); ?></span>
                                                </div><!-- End Contact-Body -->
                                            </div><!-- End Contact-Widget -->
                                        </div><!-- End Contact-Info -->
                                    </div><!-- End col-->
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                </div><!--End page-content-->  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>