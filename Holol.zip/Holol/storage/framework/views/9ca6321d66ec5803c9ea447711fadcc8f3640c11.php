<?php $__env->startSection('content'); ?>

<div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> عن العيادة <?php else: ?> About Us <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> عن العيادة <?php else: ?> About Us <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->

                    <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section class="section-md about style-2">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="section-head">
                                        <h3 class="section-title">
                                           <?php if(Config::get('app.locale') == 'ar'): ?> من نحن <?php else: ?> About Us <?php endif; ?>
                                        </h3>
                                        <h3 class="title title-sm">
                                            <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($a->p1); ?> <?php else: ?> <?php echo e($a->p1_en); ?> <?php endif; ?>
                                        </h3>
                                        <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($a->p2); ?> <?php else: ?> <?php echo e($a->p2_en); ?> <?php endif; ?>
                                        </p>
                                        <p>
                                             <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($a->p3); ?> <?php else: ?> <?php echo e($a->p3_en); ?> <?php endif; ?>
                                        </p>
                                    </div>
                                </div><!-- End col -->
                                <div class="col-md-6">
                                    <div class="section-img">
                                        <img src="<?php echo e(asset('storage/uploads/about').'/'.$a->image); ?>" alt="about">
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->                 
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <section class="section-lg colored">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?> فريق الأطباء <?php else: ?> Doctors Team <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('doctors')); ?> <?php else: ?> <?php echo e($data->get('doctors_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6">
                                        <div class="widget-box">
                                            <div class="widget-box-img">
                                                <img src="<?php echo e(asset('storage/uploads/doctors').'/'.$doctor->image); ?>" alt="...">
                                            </div><!--End Widget-box-img-->
                                            <div class="widget-box-content">
                                                <div class="cont">
                                                    <h3 class="title">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($doctor->name); ?> <?php else: ?> <?php echo e($doctor->name_en); ?> <?php endif; ?>
                                                    </h3>
                                                    <span class="text">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($doctor->title); ?> <?php else: ?> <?php echo e($doctor->title_en); ?> <?php endif; ?>
                                                    </span>
                                                </div><!--End cont-head-->
                                            </div><!--End Widegt-box-content-->
                                        </div><!--End Widget-box-->
                                    </div><!--End Col-md-3-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
                    <section class="section-md testimonial">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?> قصص النجــاح <?php else: ?> Success Stories <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('stories')); ?> <?php else: ?> <?php echo e($data->get('stories_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <div class="col-md-7">
                                        
                                        <div class="slider-widget">

                                            <div id="success-story" class="success-story carousel slide" data-ride="carousel">
                                                <ol class="carousel-indicators">
                                                    <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li data-target="#success-story" data-slide-to="<?php echo e($loop->index); ?>" class="<?php if($loop->index==0): ?> active <?php endif; ?>"></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ol>
                                                <div class="carousel-inner" role="listbox">
                                                    <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="item <?php if($loop->index==0): ?> active <?php endif; ?>" >
                                                        <div class="caption">
                                                            <p>
                                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($story->story); ?> <?php else: ?> <?php echo e($story->story_en); ?> <?php endif; ?>
                                                            </p>
                                                            <div class="Caption-owner">
                                                                <h3 class="title title-sm">
                                                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($story->name); ?> <?php else: ?> <?php echo e($story->name_en); ?> <?php endif; ?>
                                                                </h3>
                                                                <span><?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($story->title); ?> <?php else: ?> <?php echo e($story->title_en); ?> <?php endif; ?></span>
                                                            </div><!-- End caption-Owner -->
                                                        </div><!-- End Caption -->
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>  
                                        </div><!-- End Slider Widget -->
                                    </div><!-- End col -->
                                    <div class="col-md-5">
                                        <div class="section-img">
                                            <img src="<?php echo e(asset('assets/site/images/png.png')); ?>" alt="">
                                        </div><!-- End Section-Img -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>