<?php $__env->startSection('title'); ?>
من نحن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">من نحن</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" method="post" action="<?php echo e(URL::to('admin/about')); ?>" id="update_about">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group ar">
                                                    <label>العنوان</label>
                                                    <input type="text" name="title_ar" class="form-control" value="<?php echo e($about->main_title); ?>" required>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group en">
                                                    <label>title</label>
                                                    <input type="text" name="title_en" class="form-control" value="<?php echo e($about->main_title_en); ?>" required>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->

                                            <div class="col-md-6">
                                                <div class="form-group ar">
                                                    <label>المحتوى</label>
                                                    <textarea class="form-control" name="content_ar" rows="5" required><?php echo e($about->main_content); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group en">
                                                    <label>content</label>
                                                    <textarea class="form-control" name="content_en" rows="5" required><?php echo e($about->main_content_en); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->

                                            <div class="col-md-12">
                                                <div class="form-group en">
                                                    <div class="choose-img">

                                                    </div><!-- End Choose-Img -->
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->

                                            <div class="col-md-6">
                                                <div class="form-group ar">
                                                    <label>رؤيتنا</label>
                                                    <textarea class="form-control" name="vision_ar" rows="5" required><?php echo e($about->vision_content); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group en">
                                                    <label>our vision</label>
                                                    <textarea class="form-control" name="vision_en" rows="5" required><?php echo e($about->vision_content_en); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->

                                            <div class="col-md-6">
                                                <div class="form-group ar">
                                                    <label>مهمتنا</label>
                                                    <textarea class="form-control" name="mission_ar" rows="5" required><?php echo e($about->mission_content); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group en">
                                                    <label>our mission</label>
                                                    <textarea class="form-control" name="mission_en" rows="5" required><?php echo e($about->mission_content_en); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->

                                            <div class="col-md-6">
                                                <div class="form-group ar">
                                                    <label>عنوان الباقة</label>
                                                    <input type="text" class="form-control" name="pack_title_ar" value="<?php echo e($about->package_title); ?>" required>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group en">
                                                    <label>package title</label>
                                                    <input type="text" class="form-control" name="pack_title_en" value="<?php echo e($about->package_title_en); ?>" required>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->

                                            <div class="col-md-6">
                                                <div class="form-group ar">
                                                    <label>محتوى الباقه</label>
                                                    <textarea class="form-control" rows="5" name="pack_content_ar" required><?php echo e($about->package_content); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-md-6">
                                                <div class="form-group en">
                                                    <label>package content</label>
                                                    <textarea class="form-control" rows="5" name="pack_content_en" required><?php echo e($about->package_content_en); ?></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                        </div><!--End Row-->
                                    </div><!--End Form-body-->
                                    <div class="form-action">
                                        <div class="row">
                                            <div class="col-xs-12">
                                                <button class="custom-btn" type="submit">حفظ التغييرات</button>
                                            </div><!--End Col-->
                                        </div><!--End Row-->
                                    </div><!--End Form-action-->
                                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>