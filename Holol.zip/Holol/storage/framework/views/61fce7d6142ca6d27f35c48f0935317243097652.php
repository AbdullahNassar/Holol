<?php $__env->startSection('title'); ?>
بيانات الموقع
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">اتصل بنا</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" action="<?php echo e(route('admin.contacts.update')); ?>" enctype="multipart/form-data" method="post" onsubmit="return false;">
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-body">
                        <div class="row">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>رقم الهاتف</label>
                                    <input value="<?php echo e($contact->phone); ?>" name="phone" type="text" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>E-mail Address</label>
                                    <input value="<?php echo e($contact->email); ?>" name="email" type="text" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label> العنوان</label>
                                    <input type="text" name="address" value="<?php echo e($contact->address); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Facebook</label>
                                    <input type="text" name="facebook" value="<?php echo e($contact->facebook); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Twitter</label>
                                    <input type="text" name="twitter" value="<?php echo e($contact->twitter); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Google+</label>
                                    <input type="text" name="google" value="<?php echo e($contact->google); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Instagram</label>
                                    <input type="text" name="instagram" value="<?php echo e($contact->instagram); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Youtube</label>
                                    <input type="text" name="youtube" value="<?php echo e($contact->youtube); ?>" class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                        </div><!--End Row-->
                    </div><!--End Form-body-->
                    <div class="form-action">
                        <div class="row">
                            <div class="col-xs-12">
                                <button class="custom-btn addBTN" type="submit">حفظ التغييرات</button>
                            </div><!--End Col-->
                        </div><!--End Row-->
                    </div><!--End Form-action-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>