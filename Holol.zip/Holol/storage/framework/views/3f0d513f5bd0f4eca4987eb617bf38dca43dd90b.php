<?php $__env->startComponent('mail::message'); ?>
# Eamaar Mail Services

<?php echo e($subject); ?>


<?php $__env->startComponent('mail::button', ['url' => 'http://localhost/PHP-Apps/Eamaar']); ?>
Visit Website
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>.
<?php echo $__env->renderComponent(); ?>
