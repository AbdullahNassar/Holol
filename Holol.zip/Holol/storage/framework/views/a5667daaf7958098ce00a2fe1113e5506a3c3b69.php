<?php $__env->startSection('title'); ?>
الباقات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
<?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">تعديل</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form form-packages" method="post" action=""  id="dropzone_image">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                        <div class="form-group">
                            <div class="choose-img">
                                <input type="hidden" name="s_id" value="<?php echo e($package->id); ?>">
                                <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                <input type="hidden" value="slider" id="storage" >
                                <input type="hidden" name="image" value="<?php echo e($package->image); ?>" id="img" >
                                <input type="file" name="image" id="image">
                                    <?php if($package->image): ?>
                                    <img src="<?php echo e(asset('storage/uploads/package').'/'.$package->image); ?>"/>
                                    <?php else: ?>
                                    <p>اضغط لتحميل صورة</p>
                                    <?php endif; ?>
                            </div><!-- End Choose-Img -->
                            <div class="upload-action">
                                <button class="upload-btn" type="button" id="upload-btn">
                                    تحميل الصورة
                                </button>
                                <div class="progress">
                                    <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                    </div>
                                </div>
                                <h3 id="status"></h3>
                                <p id="loaded_n_total"></p>
                            </div><!--End upload-action-->
                        </div>
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>أسم الباقة</label>
                                    <input  value="<?php echo e($package->title); ?>" type="text" name="name_ar"  class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->

                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>package Name </label>
                                    <input  value="<?php echo e($package->title_en); ?>" type="text" name="name_en"  class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>المحتوى</label>
                                    <textarea class="form-control" required rows="5" name="content_ar"><?php echo e($package->content); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>content</label>
                                    <textarea class="form-control" required rows="5" name="content_en"><?php echo e($package->content_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>التفاصيل</label>
                                    <textarea class="form-control" required rows="5" name="details_ar"><?php echo e($package->details); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Details</label>
                                    <textarea class="form-control" required rows="5" name="details_en"><?php echo e($package->details_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>عرض فى الرئيسية</label>
                                    <div class="tg-item">
                                        <select class="form-control" required name="view">
                                            <option value="<?php echo e($package->view); ?>"><?php if($package->view == 1): ?>
                                                                                  نعم
                                                                                  <?php elseif($package->view == 0): ?>
                                                                                  لا
                                                                                  <?php endif; ?> 
                                            </option>
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select>
                                    </div>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>التفعيل</label>
                                    <div class="tg-item">
                                        <select class="form-control" required name="active">
                                            <option value="<?php echo e($package->active); ?>"><?php if($package->active == 1): ?>
                                                                                  نعم
                                                                                  <?php elseif($package->active == 0): ?>
                                                                                  لا
                                                                                  <?php endif; ?> 
                                            </option>
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select>
                                    </div>
                                </div><!-- End Form-Group -->
                            </div>
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الترتيب</label>
                                    <input required="" value="<?php echo e($package->_order); ?>" type="text" name="_order"  class="form-control" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>تاريخ الباقة من :</label>
                                    <input type="text" class="form-control date" name="date_from" value="<?php echo e($package->date_from); ?>">
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>تاريخ الباقة الى :</label>
                                    <input type="text" class="form-control date" name="date_to" value="<?php echo e($package->date_to); ?>">
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الإقامة</label>
                                    <textarea class="form-control" required rows="5" name="residence_ar"><?php echo e($package->residence); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Residence</label>
                                    <textarea class="form-control" required rows="5" name="residence_en"><?php echo e($package->residence_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!--End Col-md-6-->
                        </div>
                        <div class="form-action">
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="custom-btn" type="submit">حذف الباقة</button>
                                </div><!--End Col-->
                            </div><!--End Row-->
                        </div><!--End Form-action-->
                    </div>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>