<header class="main-header">
                <button class="btn btn-responsive-nav" >
                    <i class="fa fa-bars"></i>
                </button>
                <div class="navbar-custom-menu">
                    <ul class="nav navbar-nav">
                        <li class="dropdown notifications-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                            <i class="glyphicon glyphicon-globe" title="Notifications"></i>
                            <?php if(count(Auth::guard('admins')->user()->unreadNotifications)): ?>
                            <span class="label label-warning">
                                
                                <?php echo e(count(Auth::guard('admins')->user()->unreadNotifications)); ?>

                                
                            </span>
                            <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="dropdown-header">لديك <?php echo e(count(Auth::guard('admins')->user()->unreadNotifications)); ?> إشعارات جديدة</li>
                                <li>
                                    <ul class="menu">
                                        <?php $__currentLoopData = Auth::guard('admins')->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li style="background-color: lightgray;">
                                            <?php echo $__env->make('admin.layouts.partials.notifications.'.snake_case(class_basename($notification->type)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = Auth::guard('admins')->user()->readNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo $__env->make('admin.layouts.partials.notifications.'.snake_case(class_basename($notification->type)), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                              <li class="dropdown-footer"><a href="<?php echo e(route('markAsRead')); ?>" style="color: red;">تحديد الكل مقروؤه</a></li>
                            </ul>
                        </li>
                        <li class="dropdown user-menu">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                              <img src="<?php echo e(asset('assets/admin/images/avatar.jpg')); ?>" class="user-image" alt="User Image">
                              <span><?php echo e(Auth::guard('admins')->user()->username); ?></span>
                            </a>
                            <ul class="dropdown-menu">
                              <!-- User image -->
                                <li class="user-header">
                                    <img src="<?php echo e(asset('assets/admin/images/avatar.jpg')); ?>" class="img-circle">
                                    <p><?php echo e(Auth::guard('admins')->user()->username); ?></p>
                                </li><!--End User-header-->
                                <li class="user-footer">
                                    <div class="pull-left">
                                      <a href="<?php echo e(route('admin.home')); ?>" class="dropdown-btn">حسابى</a>
                                    </div>
                                    <div class="pull-right">
                                      <a href="<?php echo e(route('admin.logout')); ?>" class="dropdown-btn">خروج</a>
                                    </div>
                                </li><!--End User-footer-->
                            </ul><!--Enddropdown-menu-->
                        </li><!--End user-menu-->
                    </ul>
                </div><!--End search-head--> 
            </header><!--End main-Header-->