<?php $__env->startSection('content'); ?>
<div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/icons/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> خدماتنا <?php else: ?> Our Services <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> خدماتنا <?php else: ?> Our Services <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->
                    <?php $__currentLoopData = $services_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Sdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section class="section-lg services">
                        <div class="container">
                            <div class="section-content">
                                <div class="row">
                                    <div class="col-md-8">
                                        <div class="content-head">
                                            <h2 class="content-title">
                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($Sdata->p1); ?> <?php else: ?> <?php echo e($Sdata->p1_en); ?> <?php endif; ?>
                                            </h2>
                                            <p>
                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($Sdata->p2); ?> <?php else: ?> <?php echo e($Sdata->p2_en); ?> <?php endif; ?>
                                            </p>
                                        </div>
                                        <div class="content-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="widget-icon">
                                                        <div class="widget-icon-head">
                                                            <img src="<?php echo e(asset('assets/site/images/icons/service-icon-1.png')); ?>" alt="...">
                                                        </div><!--End Widget-icon-head-->
                                                        <div class="widget-icon-cont">
                                                            <P>
                                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($Sdata->block1); ?> <?php else: ?> <?php echo e($Sdata->block1_en); ?> <?php endif; ?>
                                                            </P>
                                                        </div><!--End Widget-icon-cont-->
                                                    </div><!--End Widget-icon-->
                                                </div><!--End Col-md-6-->
                                                <div class="col-md-6">
                                                    <div class="widget-icon">
                                                        <div class="widget-icon-head">
                                                            <img src="<?php echo e(asset('assets/site/images/icons/service-icon-1.png')); ?>" alt="...">
                                                        </div><!--End Widget-icon-head-->
                                                        <div class="widget-icon-cont">
                                                            <P>
                                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($Sdata->block2); ?> <?php else: ?> <?php echo e($Sdata->block2_en); ?> <?php endif; ?>
                                                            </P>
                                                        </div><!--End Widget-icon-cont-->
                                                    </div><!--End Widget-icon-->
                                                </div><!--End Col-md-6-->
                                                <div class="col-md-6">
                                                    <div class="widget-icon">
                                                        <div class="widget-icon-head">
                                                            <img src="<?php echo e(asset('assets/site/images/icons/service-icon-1.png')); ?>" alt="...">
                                                        </div><!--End Widget-icon-head-->
                                                        <div class="widget-icon-cont">
                                                            <P>
                                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($Sdata->block3); ?> <?php else: ?> <?php echo e($Sdata->block3_en); ?> <?php endif; ?>
                                                            </P>
                                                        </div><!--End Widget-icon-cont-->
                                                    </div><!--End Widget-icon-->
                                                </div><!--End Col-md-6-->
                                                <div class="col-md-6">
                                                    <div class="widget-icon">
                                                        <div class="widget-icon-head">
                                                            <img src="<?php echo e(asset('assets/site/images/icons/service-icon-1.png')); ?>" alt="...">
                                                        </div><!--End Widget-icon-head-->
                                                        <div class="widget-icon-cont">
                                                            <P>
                                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($Sdata->block4); ?> <?php else: ?> <?php echo e($Sdata->block4_en); ?> <?php endif; ?>
                                                            </P>
                                                        </div><!--End Widget-icon-cont-->
                                                    </div><!--End Widget-icon-->
                                                </div><!--End Col-md-6-->
                                            </div><!--End Row-->
                                        </div>
                                    </div><!--End Col-md-6-->
                                    <div class="col-md-4 section-img">
                                        <img src="<?php echo e(asset('assets/site/images/services/service-sec-3.png')); ?>" alt="...">
                                    </div><!--End Col-md-6-->
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <section class="section-lg colored">
                        <div class="container">
                            <div class="section-head">
                                <h2 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?> خدمات العيادة <?php else: ?> Clinic Services <?php endif; ?>
                                </h2>
                                <p>
                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('services')); ?> <?php else: ?> <?php echo e($data->get('services_en')); ?> <?php endif; ?>
                                </p>
                            </div>
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4">
                                        <div class="widget-box service">
                                            <div class="widget-box-img">
                                                <img src="<?php echo e(asset('storage/uploads/services').'/'.$service->image); ?>" alt="...">
                                            </div><!--End Widget-box-img-->
                                            <div class="widget-box-content">
                                                <div class="cont">
                                                    <a class="title" href="<?php echo e(route('site.service' , ['id' => $service->id])); ?>">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->_header); ?> <?php else: ?> <?php echo e($service->_header_en); ?> <?php endif; ?>
                                                    </a>
                                                    <span class="icon">
                                                        <img src="<?php echo e(asset('assets/site/images/icons/tooth-1.png')); ?>" alt="">
                                                    </span>
                                                    <p>
                                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->_paragraph); ?> <?php else: ?> <?php echo e($service->_paragraph_en); ?> <?php endif; ?>
                                                    </p>
                                                </div><!--End cont-head-->
                                            </div><!--End Widegt-box-content-->
                                        </div><!--End Widget-box-->
                                    </div><!--End Col-md-4-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!--End Row-->
                            </div><!--End Section-content-->
                        </div><!--End Container-->
                    </section><!--End Section-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>