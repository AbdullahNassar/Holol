<a href="<?php echo e(route('admin.messages')); ?>">
	<strong style="color: red;"><?php echo e(Auth::guard('admins')->user()->name); ?></strong> لديك رسالة جديدة<strong style="margin-right: 40px;"><?php echo e($notification->created_at); ?></strong>
</a>