
<!DOCTYPE html>
<html>
    <head>
        <!-- Meta Tags
        ========================== -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <!-- Site Title
        ========================== -->
        <title>الحلول للمرافق التجارية</title>

        
        <!-- Favicon
		===========================-->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/site/images/Logo.png')); ?>">
        
        <!-- Base & Vendors
        ========================== -->
        <link href="<?php echo e(asset('assets/site/vendor/bootstrap/css/bootstrap-ar.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/site/vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/rs-plugin/css/settings.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/owl-carousel/css/owl.carousel.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/owl-carousel/css/owl.theme.css')); ?>">
        <!-- Site Style
        ========================== -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/style.css')); ?>">
        <link href="<?php echo e(asset('assets/site/sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('assets/site/custom.css')); ?>" rel="stylesheet">
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js')}}"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js')}}"></script>
        <![endif]-->
    </head>
    <body>
        <div class="wrapper">
            <?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="main">
                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div><!--End Page-main-->
        </div><!-- End Wrapper -->

        <!-- JS Base & Vendors
        ========================== -->
        <script src="<?php echo e(asset('assets/site/vendor/jquery/jquery.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/bootstrap/js/bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/rs-plugin/js/jquery.themepunch.tools.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/rs-plugin/js/jquery.themepunch.revolution.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/owl-carousel/js/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/site/vendor/nicescroll/jquery.nicescroll.min.js')); ?>"></script>
        
        <!-- Site JS
        ========================== -->
        <script src="<?php echo e(asset('assets/site/js/main.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/site/process.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/admin/sweetalert.min.js')); ?>" type="text/javascript"></script>
    </body>
</html>