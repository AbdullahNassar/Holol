                    <section class="contact">
                        <div class="container">
                            <div class="contact-info">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="icon-box">
                                            <div class="icon-box-head">
                                                <i class="fa fa-flag"></i>
                                            </div><!-- End Icon-Box-Head -->
                                            <div class="icon-box-body">
                                                <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?> عنوان العيادة <?php else: ?> Clinic Address <?php endif; ?></h3>
                                                <p>
                                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($contact->get('address')); ?> <?php else: ?> <?php echo e($contact->get('address_en')); ?> <?php endif; ?>
                                                </p>
                                            </div><!-- Wnd Icon-Box-Body -->
                                        </div><!-- End Icon-Box -->
                                    </div><!-- End col -->
                                    <div class="col-md-4">
                                        <div class="icon-box">
                                            <div class="icon-box-head">
                                                <i class="fa fa-envelope"></i>
                                            </div><!-- End Icon-Box-Head -->
                                            <div class="icon-box-body">
                                                <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?> معلومات التواصل <?php else: ?> Contact Information <?php endif; ?></h3>
                                                <p>
                                                   <span><?php if(Config::get('app.locale') == 'ar'): ?> الهاتف :  <?php else: ?> Phone :  <?php endif; ?></span> 
                                                   <span><?php echo e($contact->get('phone')); ?></span> 
                                                </p>
                                                <p>
                                                   <span><?php if(Config::get('app.locale') == 'ar'): ?> البريد :  <?php else: ?> E-mail <?php endif; ?></span> 
                                                   <span><?php echo e($contact->get('email')); ?></span> 
                                                </p>
                                            </div><!-- Wnd Icon-Box-Body -->
                                        </div><!-- End Icon-Box -->
                                    </div><!-- End col -->
                                    <div class="col-md-4">
                                        <div class="icon-box">
                                            <div class="icon-box-head">
                                                <i class="fa fa-clock-o"></i>
                                            </div><!-- End Icon-Box-Head -->
                                            <div class="icon-box-body">
                                                <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?> مواعيد العمل <?php else: ?> Time Of Work <?php endif; ?></h3>
                                                <?php
                                                $ss1=json_decode($contact->get('time'));
                                                $ss2=json_decode($contact->get('time_en'));
                                                ?>
                                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                                <p>
                                                    <?php $__currentLoopData = $ss1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span><?php echo e($s1); ?></span><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </p><br>
                                                <?php else: ?>
                                                <p>
                                                    <?php $__currentLoopData = $ss2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span><?php echo e($s2); ?></span><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </p>
                                                <?php endif; ?>
                                            </div><!-- Wnd Icon-Box-Body -->
                                        </div><!-- End Icon-Box -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End Contact-Info -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <footer class="footer">
                    <div class="container">
                        <div class="col-md-4">
                            <div class="footer-widget">
                                <div class="widget-head">
                                    <img src="<?php echo e(asset('assets/site/images/icons8-Tooth-104.png')); ?>" alt="icon">
                                    <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?> عن العيادة <?php else: ?> About Clinic <?php endif; ?></h3>
                                </div><!-- End Widget-Head -->
                                <div class="widget-content">
                                    <p>
                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($abouts->get('p1')); ?> <?php else: ?> <?php echo e($abouts->get('p1_en')); ?>  <?php endif; ?>
                                    </p>
                                    <img src="<?php echo e(asset('assets/site/images/Logo.png')); ?>" alt="logo">
                                </div><!-- End Widget-Content -->
                            </div><!-- End footer-Widget -->
                        </div><!-- End col -->
                        <div class="col-md-4">
                            <div class="footer-widget">
                                <div class="widget-head">
                                    <img src="<?php echo e(asset('assets/site/images/icons8-Tooth-104.png')); ?>" alt="icon">
                                    <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?> روابط سريعة <?php else: ?> Fast Links <?php endif; ?></h3>
                                </div><!-- End Widget-Head -->
                                <div class="widget-content">
                                    <ul class="important-links list-second ">
                                        <li><a href="<?php echo e(URL::to('/')); ?>"><?php echo e(trans('app.home')); ?></a></li>
                                        <li><a href="<?php echo e(URL::to('/services')); ?>"><?php echo e(trans('app.services')); ?></a></li>
                                        <li><a href="<?php echo e(URL::to('/team')); ?>"><?php echo e(trans('app.doctors')); ?></a></li>
                                        <li><a href="<?php echo e(URL::to('/posts')); ?>"><?php echo e(trans('app.blog')); ?></a></li>
                                        <li><a href="<?php echo e(URL::to('/about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                        <li><a href="<?php echo e(URL::to('/gallery')); ?>"><?php echo e(trans('app.gallery')); ?></a></li>
                                        <li><a href="<?php echo e(URL::to('/contact')); ?>"><?php echo e(trans('app.contact')); ?></a></li>
                                    </ul><!-- End Important-links -->
                                </div><!-- End Widget-Content -->
                            </div><!-- End footer-Widget -->
                        </div><!-- End col -->
                        <div class="col-md-4">
                            <div class="footer-widget">
                                <div class="widget-head">
                                    <img src="<?php echo e(asset('assets/site/images/icons8-Tooth-104.png')); ?>" alt="icon">
                                    <h3 class="title"><?php if(Config::get('app.locale') == 'ar'): ?> اشترك معنا <?php else: ?> Subscribe With Us <?php endif; ?></h3>
                                </div><!-- End Widget-Head -->
                                <div class="widget-content">
                                    <p>
                                        <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($data->get('subscribe')); ?> <?php else: ?> <?php echo e($data->get('subscribe_en')); ?> <?php endif; ?>
                                    </p>
                                    <form class="subscribe-form">
                                        <input type="email" class="form-control" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> ادخل بريدك الالكتروني <?php else: ?> Enter Your E-mail <?php endif; ?>">
                                        <button class="custom-btn"><?php if(Config::get('app.locale') == 'ar'): ?> اشترك <?php else: ?> Subscribe <?php endif; ?></button>
                                    </form><!--End subscribe-form-->
                                </div><!-- End Widget-Content -->
                            </div><!-- End footer-Widget -->
                        </div><!-- End col -->
                    </div><!-- End container -->
                    </footer><!-- End Footer -->