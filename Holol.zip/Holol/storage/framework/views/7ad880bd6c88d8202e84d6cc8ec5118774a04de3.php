<?php $__env->startSection('title'); ?>
الخدمات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">تعديل</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" method="post" action="" >
                    <div class="form-body">
                        <div class="row">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="choose-img">
                                        <input type="hidden" name="s_id" value="<?php echo e($service->id); ?>">
                                        <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                        <input type="hidden" value="services" id="storage" >
                                        <input type="hidden" name="image" value="<?php echo e($service->image); ?>" id="img" >
                                        <input type="file" name="image" id="image" required>
                                        <img src="<?php echo e(asset('storage/uploads/services').'/'.$service->image); ?>"/>
                                    </div><!-- End Choose-Img -->
                                    <div class="upload-action"><br>
                                        <button class="upload-btn" type="button" id="upload-btn">
                                            تحميل الصورة
                                        </button>
                                        <div class="progress">
                                            <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                            </div>
                                        </div>
                                        <h3 id="status"></h3>
                                        <p id="loaded_n_total"></p><br>
                                    </div><!--End upload-action-->

                                </div><!-- End Form-Group -->
                            </div><!-- End col -->

                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الترتيب</label>
                                    <input type="number" name="_order" class="form-control" value="<?php echo e($service->_order); ?>" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>التفعيل</label>
                                    <select class="form-control" name="active" required>
                                        <option value="<?php echo e($service->active); ?>"><?php if($service->active == 1): ?>
                                                                                نعم
                                                                                <?php elseif($service->active == 0): ?>
                                                                                لا
                                                                                <?php endif; ?> 
                                        </option>
                                        <option value="1">نعم</option>
                                        <option value="0">لا</option>
                                    </select>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>أسم الخدمة</label>
                                    <input type="text" name="_header"  class="form-control" value="<?php echo e($service->_header); ?>" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->

                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>service Name </label>
                                    <input type="text" name="_header_en"  class="form-control" value="<?php echo e($service->_header_en); ?>" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->

                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>المحتوى </label>
                                    <textarea class="form-control" rows="10" name="_paragraph" required><?php echo e($service->_paragraph); ?></textarea>

                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>content </label>
                                    <textarea class="form-control" rows="10" name="_paragraph_en" required><?php echo e($service->_paragraph_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <?php
                                    $advantage = json_decode($service->advantages);
                                    ?>
                                    <label>مميزات تركيب الاسنان</label>
                                    <?php $count = 1 ?>
                                    <?php $__currentLoopData = $advantage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="text" value="<?php echo e($a); ?>" name="a<?php echo e($count); ?>" class="form-control" required><br>
                                    <?php $count = $count+1 ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <?php
                                    $advantage_en = json_decode($service->advantages_en);
                                    ?>
                                    <label>Advantages of dental implants</label>
                                    <?php $count_en = 1 ?>
                                    <?php $__currentLoopData = $advantage_en; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="text" value="<?php echo e($ad); ?>" name="ad<?php echo e($count_en); ?>" class="form-control" required><br>
                                    <?php $count_en = $count_en+1 ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-12">
                                <div class="form-group en">
                                    <label>Video Link</label>
                                    <input type="text" name="video"  class="form-control" value="<?php echo e($service->video); ?>" required>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>محتوى الخدمة 1</label>
                                    <textarea class="form-control" rows="10" name="p1" required><?php echo e($service->p1); ?></textarea>

                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Service Content 1</label>
                                    <textarea class="form-control" rows="10" name="p1_en" required><?php echo e($service->p1_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>محتوى الخدمة 2</label>
                                    <textarea class="form-control" rows="10" name="p2" required><?php echo e($service->p2); ?></textarea>

                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Service Content 2</label>
                                    <textarea class="form-control" rows="10" name="p2_en" required><?php echo e($service->p2_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                        </div><!--End Row-->
                    </div><!--End Form-body-->
                    <div class="form-action">
                        <div class="row">
                            <div class="col-xs-12">
                                <button class="custom-btn" type="submit">حفظ التغييرات</button>
                            </div><!--End Col-->
                        </div><!--End Row-->
                    </div><!--End Form-action-->
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>