<?php $__env->startSection('title'); ?>
الخدمات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">جدول  الخدمات</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <div class="row">
                    <div class="col-md-6">
                        <div class="btn-group">
                            <a href="<?php echo e(route('admin.services.add')); ?>" class="box-btn ">
                                اضافة خدمة جديدة
                                <i class="fa fa-plus"></i>
                            </a>
                        </div>
                    </div><!-- End col -->
                </div><!--End Row-->
                <div id="sample_editable_1_wrapper" class="dataTables_wrapper no-footer">
                    <div class="row">

                    </div>
                    <div class="table-scrollable">
                        <table class="table table-striped dataTable no-footer" role="grid">
                            <thead>
                                <tr role="row">
                                    <th> # </th>
                                    <th> العنوان </th>
                                    <th> التفعيل  </th>
                                    <th> الترتيب </th>
                                    <th> تعديل </th>
                                    <th> حذف </th>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="even">
                                    <td class="sorting_1"><?php echo e($service->id); ?> </td>
                                    <td>
                                        <?php echo e($service->name); ?> |
                                    </td>
                                    <td> 
                                        <?php if($service->active): ?>
                                        نعم
                                        <?php else: ?>
                                        لا
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($service->_order); ?>

                                    </td>
                                    <td>
                                        <a class="custom-btn small green" href="<?php echo e(route('admin.service.edit' , ['id' => $service->id])); ?>"> تعديل </a>
                                    </td>
                                    <td>
                                        <a class="delete custom-btn small red" href="<?php echo e(route('admin.service.delete' , ['id' => $service->id])); ?>"> حذف </a>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div><!-- End Box-Item-Content -->
            </div><!-- End Box-Item -->
    </section>

</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>