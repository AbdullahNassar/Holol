<?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="main">
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            <?php if(Config::get('app.locale') == 'ar'): ?>
                            خدماتنا
                            <?php else: ?>
                            Our Services
                            <?php endif; ?>
                        </h2>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(URL::to('/packages')); ?>">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        الرئيسية
                                        <?php else: ?>
                                        Home
                                        <?php endif; ?>
                                    </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                خدماتنا
                                <?php else: ?>
                                Our Services
                                <?php endif; ?>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div><!--End page head-->
                <div class="page-content">
                    <section class="section-md pattern-bg">
                        <div class="container">
                            <div class="row">
                                <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6">
                                    <div class="service-box">
                                        <div class="service-box-img">
                                            <img src="<?php echo e(asset('assets/site/images/'.$s->image)); ?>">
                                        </div><!-- End Service-Box-Img -->
                                        <div class="service-box-head">
                                            <a href="<?php echo e(route('site.service.packages' , ['name' => $s->id])); ?>" class="more">
                                                <h3 class="title">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                    <?php echo e($s->name); ?>

                                                    <?php else: ?>
                                                    <?php echo e($s->name_en); ?>

                                                    <?php endif; ?>
                                                </h3>
                                            </a>
                                            <p>
                                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                                <?php echo e($s->content); ?>

                                                <?php else: ?>
                                                <?php echo e($s->content_en); ?>

                                                <?php endif; ?>
                                            </p>
                                        </div><!-- End Service-Head -->
                                    </div><!-- End Service-Box -->
                                </div><!-- End col -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                </div><!--End page-content--> 
                <?php echo e(csrf_field()); ?>

<?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 