<footer class="footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-push-3 col-md-3 col-sm-6">
                                <div class="contact-widget">
                                    <div class="contact-icon">
                                        <i class="fa fa-phone"></i>
                                    </div><!-- End Contact-Widget-Head -->
                                    <div class="contact-body">
                                        <span> الهاتف </span>
                                        <span class="en-text"> <?php echo e($contact->get('phone')); ?></span>
                                    </div><!-- End Contact-Body -->
                                </div><!-- End Contact-Widget -->
                            </div><!-- End col -->
                            <div class="col-md-push-3 col-md-3 col-sm-6">
                                <div class="contact-widget">
                                    <div class="contact-icon">
                                        <i class="fa fa-envelope"></i>
                                    </div><!-- End Contact-Widget-Head -->
                                    <div class="contact-body">
                                        <span> البريد الالكتروني </span>
                                        <span class="en-text"> <?php echo e($contact->get('email')); ?></span>
                                    </div><!-- End Contact-Body -->
                                </div><!-- End Contact-Widget -->
                            </div><!-- End col -->
                            <div class="col-md-push-3 col-md-3 col-sm-6">
                                <div class="contact-widget">
                                    <div class="contact-icon">
                                        <i class="fa fa-map-marker"></i>
                                    </div><!-- End Contact-Widget-Head -->
                                    <div class="contact-body">
                                        <span> العنوان </span>
                                        <span> <?php echo e($contact->get('address')); ?></span>
                                    </div><!-- End Contact-Body -->
                                </div><!-- End Contact-Widget -->
                            </div><!-- End col -->
                        </div><!-- End row -->
                        <div class="row">
                            <div class="col-md-3 col-sm-6">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title title-sm">عن الشركة</h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <p>
                                            <?php echo e($data->get('footer')); ?>

                                        </p>
                                        <ul class="social-list">
                                            <li>
                                            <a href="<?php echo e($contact->get('youtube')); ?>">
                                                <i class="fa fa-youtube"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('instagram')); ?>">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('google')); ?>">
                                                <i class="fa fa-google-plus"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('twitter')); ?>">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('facebook')); ?>">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        </ul>
                                    </div><!-- End Widget-Content -->
                                </div>
                            </div><!-- End col -->
                            <div class="col-md-3 col-sm-6">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title title-sm">شركاؤنا</h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <ul class="important-links">
                                            <?php 
                                            $count = 1;
                                            ?>
                                            <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($count <= 6): ?>
                                            <li>
                                                <a href="<?php echo e(route('site.mark' , ['id' => $mark->id])); ?>">
                                                    <?php echo e($mark->title); ?> 
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                            <?php 
                                            $count = $count+1;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div><!-- End Widget-Content -->
                                </div>
                            </div><!-- End col -->
                            <div class="col-md-3 col-sm-6">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title title-sm">الاقسام</h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <ul class="important-links second-list">
                                            <?php 
                                            $count1 = 1;
                                            ?>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($count1 <= 6): ?>
                                            <li>
                                                <a href="<?php echo e(route('site.category' , ['id' => $category->cat_id])); ?>">
                                                    <?php echo e($category->cat_name); ?> 
                                                </a>
                                            </li>
                                            <?php endif; ?>
                                            <?php 
                                            $count1 = $count1+1;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div><!-- End Widget-Content -->
                                </div>
                            </div><!-- End col -->
                            <div class="col-md-3 col-sm-6 subscribe">
                                <div class="footer-widget">
                                    <div class="widget-head">
                                        <h3 class="title title-sm">النشرة البريدية</h3>
                                    </div><!-- End Widget-Head -->
                                    <div class="widget-content">
                                        <p>
                                            <?php echo e($data->get('news')); ?>

                                        </p>
                                        <form class="subscribe-form" enctype="multipart/form-data" method="post" onsubmit="return false;" action="<?php echo e(route('site.subscribe')); ?>">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="form-group">
                                                <input class="form-control" type="text" placeholder="ادخل البريد الالكتروني" name="subscribe">
                                                <button class="subscribe-btn addBTN" type="submit">اشترك</button>
                                            </div><!--End Form-group-->
                                        </form>
                                    </div><!-- End Widget-Content -->
                                </div>
                            </div><!-- End col -->
                        </div><!-- End row -->
                    </div><!-- End container -->
                </footer><!-- End Footer -->
                <div class="copy-right">
                    <div class="container">
                        <div class="pull-left">
                            © جميع الحقوق محفوظة لصالح <a href="#">حلول المرافق</a>
                        </div>
                        <div class="pull-right">
                            تصميم و برمجة <a href="#" class="en-text">Upureka</a>
                        </div>
                    </div><!-- End container -->
                </div><!--End Copy-Right -->
