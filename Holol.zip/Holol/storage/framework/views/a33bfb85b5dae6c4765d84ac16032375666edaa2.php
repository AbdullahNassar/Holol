<aside class="main-sidebar">
                <!-- Logo -->
                <a href="<?php echo e(route('admin.home')); ?>" class="logo">
                  <!-- mini logo for sidebar mini 50x50 pixels -->
                    <img class="logo-mini" src="<?php echo e(asset('assets/admin/images/icon.png')); ?>">
                  <!-- logo for regular state and mobile devices -->
                    <img class="logo-lg" src="<?php echo e(asset('assets/admin/images/icon.png')); ?>">
                </a>
                <ul class="sidebar-links">
                    <li class="<?php if(Request::route()->getName() == 'admin.home'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.home')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>الرئيسية</span>
                        </a>
                    </li>   
                    <li class="<?php if(Request::route()->getName() == 'admin.slider'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.slider')); ?>">
                            <i class="fa fa-cubes"></i>
                            <span>الإسلايد شو</span>
                        </a>
                    </li> 
                    <li class="<?php if(Request::route()->getName() == 'admin.services'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.services')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>الخدمات</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.posts'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.posts')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>المدونة</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.portfolios'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.portfolios')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>المشاريع</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.category'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.category')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>فئات المشاريع</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.data'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.data')); ?>">
                            <i class="fa fa-cubes"></i>
                            <span>البيانات الثابتة</span>
                        </a>
                    </li>      
                    <li class="<?php if(Request::route()->getName() == 'admin.contacts'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.contacts')); ?>">
                            <i class="fa fa-dashboard"></i>
                            <span>بيانات الموقع</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.users'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.users')); ?>">
                            <i class="fa fa-cubes"></i>
                            <span>المستخدمون</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.messages'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.messages')); ?>">
                            <i class="fa fa-newspaper-o"></i>
                            <span>الرسائل</span>
                        </a>
                    </li>
                    <li class="<?php if(Request::route()->getName() == 'admin.subscribers'): ?> <?php echo e('active'); ?> <?php endif; ?>">
                        <a href="<?php echo e(route('admin.subscribers')); ?>">
                            <i class="fa fa-newspaper-o"></i>
                            <span>المشتركين</span>
                        </a>
                    </li>
                </ul><!--End sidebar-->
            </aside><!--End Main-aside-->
