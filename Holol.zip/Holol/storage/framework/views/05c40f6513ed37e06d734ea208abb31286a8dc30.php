<!DOCTYPE html>
<html>
    <head>
        <!-- Meta Tags
        ========================== -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <!-- Site Title
        ========================== -->
        <title>Login</title>

        <!-- Favicon
                ===========================-->
        <!--		<link rel="shortcut icon" type="image/x-icon" href="images/fav.jpg">-->

        <!-- Web Fonts
        ========================== -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet"> 

        <!-- Base & Vendors
        ========================== -->
        <link href="<?php echo e(asset('assets/admin/vendor/bootstrap/css/bootstrap-ar.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('assets/admin/vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <!-- ========================== -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/style.css')); ?>">        

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div class="wrapper">
            <section class="login">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="">
            
                                <form class="login-form" action="<?php echo e(route('admin.login')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

            
                                    <div class="alert alert-success" style="display: none;" role="alert">
                                        تم تسجيل الدخول بنجاح
                                    </div>
            
                                    <div class="alert alert-danger" style="display: none;" role="alert">
                                       البيانات المدخله غير صحيحه
                                    </div>
            
            
                                    <div class="form-group">
            
                            <input class="form-control form-control-solid placeholder-no-fix" type="text"  placeholder="اسم المستخدم " name="email" />
                                        <i class="fa fa-user"></i>
                                    </div>
                                    <div class="form-group">
            
                                        <input class="form-control form-control-solid placeholder-no-fix" type="password" placeholder="الرقم السري" name="password" /> 
                                        <i class="fa fa-unlock-alt"></i>
                                    </div>
            
            
                                    <div class="form-actions">
            
                                        <button type="submit" class="custom-btn">تسجيل الدخول</button>
            
            
                                    </div>
                                </form>
                            </div><!-- End Login-Form -->
                        </div><!-- End col -->
                        <div class="col-sm-6 hidden-xs">
                            <div class="section-img">
                                <img src="<?php echo e(asset('assets/admin/images/logo-2.png')); ?>" alt="logo">
                            </div><!-- End Section-Img -->
                        </div><!-- End col -->
                    </div><!-- End row -->
                </div><!-- End container -->
            </section><!-- End Section -->

        </div><!-- End Wrapper -->

        <!-- JS Base And Vendor
        ========================== -->
        <script src="<?php echo e(asset('assets/admin/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/admin/vendor/bootstrap/js/bootstrap.js')); ?>"></script>
        <!-- Jquery validation-->
        <script src="<?php echo e(asset('assets/admin/vendor/jquery-validation/js/jquery.validate.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('assets/admin/js/login.js')); ?>"></script>
    </body>
</html>