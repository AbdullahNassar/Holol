                <div class="top-header">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-8 col-xs-5">
                                <div class="right-side">
                                    <button class="btn btn-responsive-nav" data-toggle="collapse" data-target=".contact-list">
                                        <i class="fa fa-bars"></i>
                                    </button>
                                    <ul class="contact-list collapse">
                                        <li>
                                            <i class="fa fa-phone"></i>
                                            <span><?php echo e($contact->get('phone')); ?></span>
                                        </li>
                                        <li>
                                            <i class="fa fa-envelope"></i>
                                            <span><?php echo e($contact->get('email')); ?></span>
                                        </li>
                                        <li>
                                            <i class="fa fa-map-marker"></i>
                                            <span><?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($contact->get('address')); ?> <?php else: ?> <?php echo e($contact->get('address_en')); ?> <?php endif; ?></span>
                                        </li>
                                    </ul><!-- End Contact-List -->
                                </div><!-- End Right-Side -->
                            </div><!-- End col -->
                            <div class="col-md-4 col-xs-7">
                                <div class="left-side">
                                    <ul class="social-list">
                                        <li>
                                            <a href="<?php echo e($contact->get('youtube')); ?>">
                                                <i class="fa fa-youtube"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('instagram')); ?>">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('google')); ?>">
                                                <i class="fa fa-google-plus"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('twitter')); ?>">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e($contact->get('facebook')); ?>">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                    </ul><!-- End Social-List -->
                                    
                                </div><!-- End Left-Side -->
                            </div><!-- End col -->
                        </div><!-- End row -->
                    </div><!-- End container -->
                </div><!-- End Top-Header -->
                <div class="container">
                    <a href="<?php echo e(URL::to('/')); ?>" class="logo">
                        <img src="<?php echo e(asset('assets/site/images/Logo.png')); ?>" alt="logo-img">
                    </a>
                    <button class="btn btn-responsive-nav" data-toggle="collapse" data-target=".navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a href="<?php echo e(URL::to('/book')); ?>" class="custom-btn"><?php if(Config::get('app.locale') == 'ar'): ?> احجز الآن <?php else: ?> Book Now <?php endif; ?></a>
                </div><!-- End container -->
                <div class="navbar-collapse collapse">
                    <div class="container">
                        <nav class="nav-main">
                            <ul class="nav navbar-nav">
                                <li class="<?php if(Route::currentRouteName()=='site.home'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/')); ?>"><?php echo e(trans('app.home')); ?></a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.services'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/services')); ?>"><?php echo e(trans('app.services')); ?></a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.team'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/team')); ?>"><?php echo e(trans('app.doctors')); ?></a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.posts'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/posts')); ?>"><?php echo e(trans('app.blog')); ?></a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.about'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.gallery'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/gallery')); ?>"><?php echo e(trans('app.gallery')); ?></a></li>
                                <li class="<?php if(Route::currentRouteName()=='site.contact'): ?> active <?php endif; ?>"><a href="<?php echo e(URL::to('/contact')); ?>"><?php echo e(trans('app.contact')); ?></a></li>
                                <li>
                                    <?php if(Config::get('app.locale') == 'en'): ?>
                                    <a href="<?php echo e(route('site.lang','ar')); ?>" class="langSwitch" data-lang="ar" title="Arabic">
                                        <i class="fa fa-language"></i>
                                    </a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('site.lang','en')); ?>" class="langSwitch" data-lang="en" title="English">
                                        <i class="fa fa-language"></i>
                                    </a>
                                    <?php endif; ?>
                                <?php echo e(csrf_field()); ?>

                                </li>
                            </ul>
                        </nav><!-- End nav-main -->
                    </div><!-- End container -->
                </div><!-- End navbar-collapse -->