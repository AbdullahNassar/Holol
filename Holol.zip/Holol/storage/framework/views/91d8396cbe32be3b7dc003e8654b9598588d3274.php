<?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="main">
                <div class="home-slider">
                    <div class="container">
                        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <?php $counter=1 ?>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($slider->active==1): ?> 
                                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($slider->id-1); ?>" class="<?php if($counter<=1): ?> active <?php endif; ?>"></li>
                                <?php $counter=$counter+1 ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                            <div class="carousel-inner">
                                <?php $counter=1 ?>
                                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($slider->active==1): ?> 
                                <div class="carousel-item  <?php if($counter==1): ?> active <?php endif; ?>">
                                    <img src="<?php echo e(asset('assets/site/images/'. $slider->image)); ?>" alt="<?php echo e($slider->image); ?>">
                                </div>
                                <?php $counter=$counter-1 ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div><!-- End container -->
                </div><!-- End Home-Slider -->
                
                <div class="page-content">
                    <section class="section-lg about">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8">
                                    <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="section-head">
                                        <h3 class="section-title bg-title">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        <?php echo e($about->main_title); ?>

                                        <?php else: ?>
                                        <?php echo e($about->main_title_en); ?>

                                        <?php endif; ?>
                                        </h3>
                                    </div><!-- End Section-Head -->
                                    <div class="section-content">
                                        <p>
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        <?php echo e($about->main_content); ?>

                                        <?php else: ?>
                                        <?php echo e($about->main_content_en); ?>

                                        <?php endif; ?>
                                        </p>
                                    </div><!-- End Section-Content -->
                                </div><!-- End col -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="section-img-2">
                                        <div class="img-2-pattern">
                                            <img src="<?php echo e(asset('assets/site/images/about-img-2.jpg')); ?>">
                                        </div><!-- End With-Pattern -->
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <section class="section-md color-bg">
                        <div class="container">
                            <div class="section-head">
                                <h3 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                    باقات الحج والعمرة
                                    <?php else: ?>
                                    Hajj And Umrah Packages
                                    <?php endif; ?>
                                </h3>
                            </div><!-- End Section-Head -->
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4">
                                        <div class="widget">
                                            <div class="widget-head">
                                                <img src="<?php echo e(asset('assets/site/images/'.$package->image)); ?>">
                                            </div><!-- End Widget-Head -->
                                            <div class="widget-content">
                                                <a href="<?php echo e(route('site.package' , ['id' => $package->id])); ?>" class="more">
                                                    <h3 class="title">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($package->title); ?>

                                                        <?php else: ?>
                                                        <?php echo e($package->title_en); ?>

                                                        <?php endif; ?>
                                                    </h3>
                                                </a>
                                            </div><!-- End Widget-Content -->
                                        </div><!-- End Widget -->
                                    </div><!-- End col -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section>
                    <section class="section-md">
                        <div class="container">
                            <div class="section-head">
                                <h3 class="section-title">
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                    برامج السياحة الخارجية
                                    <?php else: ?>
                                    Foreign Tourism Programs
                                    <?php endif; ?>
                                </h3>
                            </div><!-- End Section-Head -->
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($program->id < '3'): ?>
                                    <div class="col-lg-6">
                                        <div class="block-box">
                                            <div class="block-box-head">
                                                <img src="<?php echo e(asset('assets/site/images/'.$package->image)); ?>">
                                            </div><!-- End Program-Widget-Head -->
                                            <div class="block-box-body">
                                                <div class="program-title">
                                                    <h3 class="title">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($program->name); ?>

                                                        <?php else: ?>
                                                        <?php echo e($program->name_en); ?>

                                                        <?php endif; ?>
                                                    </h3>
                                                    <span>
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($program->price); ?> درهم
                                                        <?php else: ?>
                                                        <?php echo e($program->price); ?> AED
                                                        <?php endif; ?>
                                                    </span>
                                                </div><!-- End Program-Title -->
                                                
                                                <a href="<?php echo e(route('site.services')); ?>" class="custom-btn">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                    المزيد
                                                    <?php else: ?>
                                                    More
                                                    <?php endif; ?>
                                                </a>
                                            </div><!-- End Program-Widget-Content -->
                                        </div><!-- End Program-Widget -->
                                    </div><!-- End col -->
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!-- End row -->
                                <div class="row">
                                    <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4 col-md-6">
                                        <div class="block-box small-box">
                                            <div class="block-box-head">
                                                <img src="<?php echo e(asset('assets/site/images/block-box.png')); ?>">
                                            </div><!-- End Program-Widget-Head -->
                                            <div class="block-box-body">
                                                <div class="program-title">
                                                    <h3 class="title">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($program->name); ?>

                                                        <?php else: ?>
                                                        <?php echo e($program->name_en); ?>

                                                        <?php endif; ?></h3>
                                                    <span>
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        <?php echo e($program->price); ?> درهم
                                                        <?php else: ?>
                                                        <?php echo e($program->price); ?> AED
                                                        <?php endif; ?></span>
                                                </div><!-- End Program-Title -->
                                                <a href="<?php echo e(route('site.services')); ?>" class="custom-btn">
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                    المزيد
                                                    <?php else: ?>
                                                    More
                                                    <?php endif; ?>
                                                </a>
                                            </div><!-- End Program-Widget-Content -->
                                        </div><!-- End Program-Widget -->
                                    </div><!-- End col -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section>
                    <section class="section-md call-to-action">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-7">
                                    <div class="section-head">
                                        <h3 class="title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            تاشيرة زيارة الى الامارات العربية المتحدة
                                            <?php else: ?>
                                            visa to the United Arab Emirates
                                            <?php endif; ?>
                                        </h3>
                                    </div><!-- End Section-Head -->
                                    <div class="section-content">
                                        <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            عبر إدخال بعض النوادر أو الكلمات العشوائية إلى النص كنت تريد أن تستخدم نص لوريم إيبسوم ما، عليك أن تتحقق أولاً أن ليس هناك أي كلمات أو عبارات محرجة أو غير لائقة مخبأة في هذا النص
                                            عبر إدخال بعض النوادر أو الكلمات العشوائية 
                                            <?php else: ?>
                                            The type of visa required to enter the UAE depends on several factors, such as your nationality, the purpose of your planned visit, the duration of your visit, the good visit to you, and the visit visa to you in any country around the world. , And also provides support from other services after reaching the United Arab Emirates
                                            <?php endif; ?>
                                        </p>
                                        <a href="<?php echo e(URL::to('/visa')); ?>" class="custom-btn green-btn">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                                    المزيد
                                                    <?php else: ?>
                                                    More
                                                    <?php endif; ?>
                                        </a>
                                    </div><!-- End Section-Content -->
                                </div><!-- End col-->
                                <div class="col-lg-5">
                                    <div class="section-img">
                                    </div><!-- End Section-Img -->
                                </div><!-- End col-->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    
                </div><!--End page-content--> 
<?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   