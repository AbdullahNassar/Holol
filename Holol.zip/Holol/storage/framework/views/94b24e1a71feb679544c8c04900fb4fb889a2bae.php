<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="page-header">
                    <div class="page-header-img">
                        <img src="<?php echo e(asset('assets/site/images/icons/page-head.png')); ?>" alt="...">
                    </div>
                    <div class="container">
                        <div class="breadcramb">
                            <ol class="breadcrumb">
                              <li><a href="<?php echo e(URL::to('/')); ?>"><?php if(Config::get('app.locale') == 'ar'): ?> الرئيسية <?php else: ?> Home <?php endif; ?></a></li>
                              <li class="active"><?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->_header); ?> <?php else: ?> <?php echo e($service->_header_en); ?> <?php endif; ?></li>
                            </ol>
                        </div><!--End Breadcamp-->
                        <div class="page-title">
                            <h2 class="title">
                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->_header); ?> <?php else: ?> <?php echo e($service->_header_en); ?> <?php endif; ?>
                            </h2>
                        </div>
                    </div><!--End Container-->
                </div><!-- End page-header -->
                    <section class="section-md contact-fix">
                        <div class="container">
                            <div class="row">
                                
                                <div class="col-md-8">
                                    <div class="service-detail">
                                        <div class="service-img">
                                            <img src="<?php echo e(asset('assets/site/images/safe_image(30).jpg')); ?>">
                                        </div><!-- End Service-Img -->
                                        <div class="service-content">
                                            <div class="service-icon-box">
                                                <img src="<?php echo e(asset('assets/site/images/icons/icon.png')); ?>">
                                            </div><!-- End Service-Icon-Box -->
                                            <p>
                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->p1); ?> <?php else: ?> <?php echo e($service->p1_en); ?> <?php endif; ?>
                                            </p>
                                            <p>
                                                <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($service->p2); ?> <?php else: ?> <?php echo e($service->p2_en); ?> <?php endif; ?>
                                            </p>
                                        </div><!-- End Service-Content -->
                                        <div class="feature">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="feature-head">
                                                        <h3 class="title title-md">
                                                            
                                                            <?php if(Config::get('app.locale') == 'ar'): ?> مميزات <?php echo e($service->_header); ?> <?php else: ?> Advantages of <?php echo e($service->_header_en); ?> <?php endif; ?>
                                                        </h3>
                                                    </div><!-- End Feature-Head -->
                                                    <?php
                                                    $ss1=json_decode($service->advantages);
                                                    $ss2=json_decode($service->advantages_en);
                                                    ?>
                                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                                    
                                                    <ul class="feature-list">
                                                        <?php $__currentLoopData = $ss1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($s1); ?></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul><!-- End Feature-List -->
                                                    
                                                    <?php else: ?>
                                                    
                                                    <ul class="feature-list">
                                                        <?php $__currentLoopData = $ss2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                         <li><?php echo e($s2); ?></li>
                                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul><!-- End Feature-List -->
                                                    
                                                    <?php endif; ?>
                                                </div><!-- End col -->
                                                <div class="col-md-6">
                                                    <div class="service-video">
                                                        <a href="<?php echo e($service->video); ?>" class="service-img">
                                                            <img src="<?php echo e(asset('assets/site/images/safe_image(11).jpg')); ?>">
                                                            <div class="video-icon"></div>
                                                        </a>
                                                    </div><!-- End Service-Video -->
                                                </div><!-- End col -->
                                            </div><!-- End row -->
                                            
                                        </div><!-- End Feature -->
                                    </div><!-- End Service-Detail -->
                                </div><!-- End col -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-md-offset-1">
                                    <aside>
                                        <div class="aside-widget">
                                            <div class="widget-title">
                                                <h3><?php if(Config::get('app.locale') == 'ar'): ?> الخدمات <?php else: ?> Services <?php endif; ?></h3>
                                            </div>
                                            <div class="widget-content">
                                                <div class="toggle-container" id="sercices">
                                                    <?php $__currentLoopData = $counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="panel">
                                                        <a href="<?php echo e(route('site.service' , ['id' => $serv->id])); ?>"  class="collapsed">
                                                            <img src="<?php echo e(asset('storage/uploads/services').'/'.$serv->image); ?>" alt="...">
                                                            <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($serv->_header); ?> <?php else: ?> <?php echo e($serv->_header_en); ?> <?php endif; ?>
                                                        </a>
                                                        <div class="panel-collapse collapse" id="item-1">
                                                            <div class="panel-content">
                                                                <p>
                                                                    <?php if(Config::get('app.locale') == 'ar'): ?> <?php echo e($serv->_paragraph); ?> <?php else: ?> <?php echo e($serv->_paragraph_en); ?> <?php endif; ?>
                                                                </p>
                                                            </div><!-- end content -->
                                                        </div><!--End panel-collapse-->
                                                    </div><!--End Panel-->
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div><!--End toggle-container-->
                                            </div><!--End widget-content-->
                                        </div><!--End widget-->
                                    </aside><!-- End Aside -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>