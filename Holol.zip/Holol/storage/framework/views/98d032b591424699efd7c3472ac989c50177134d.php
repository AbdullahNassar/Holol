<?php $__env->startSection('content'); ?>
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            العلامات التجارية
                        </h2>
                        <ol class="breadcrumb">
                          <li><a href="<?php echo e(URL::to('/')); ?>">الرئيسية</a></li>
                          <li class="active">العلامات التجارية</li>
                        </ol>
                    </div><!--End Container-->
                </div><!-- End Page-Head -->
                <div class="page-content">
                    <section class="section-lg brands-page">
                        <div class="container">
                            <div class="row">
                                <?php $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3">
                                    <div class="brand-item">
                                        <div class="brand-head">
                                            <div class="brand-logo">
                                                <img src="<?php echo e(asset('storage/uploads/mark').'/'.$mark->logo); ?>">
                                            </div><!--End brand-logo-->
                                            <div class="brand-name">
                                                <h3 class="title"><?php echo e($mark->name); ?></h3>
                                            </div><!--End brand-name-->
                                        </div><!--End brand-head-->
                                        <div class="brand-cont">
                                            <p>
                                                <?php echo e($mark->head); ?>

                                            </p>
                                            <a href="<?php echo e(route('site.mark' , ['id' => $mark->id])); ?>" class="show-more">رؤية المزيد</a>
                                        </div><!--End brand-cont-->
                                    </div><!--End brand-item-->
                                </div><!--End col-md-3-->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!--End row-->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                </div><!--End page-content-->  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>