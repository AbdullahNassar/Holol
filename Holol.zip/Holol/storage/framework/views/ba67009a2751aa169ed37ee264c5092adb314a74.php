<?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="main">
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            
                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                        تاشيرة زيارة الى الامارات
                                        <?php else: ?>
                                        Visa to UAE
                                        <?php endif; ?>
                        </h2>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="index.html">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        الرئيسية
                                        <?php else: ?>
                                        Home
                                        <?php endif; ?>
                                    </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                    <?php if(Config::get('app.locale') == 'ar'): ?>
                                        تاشيرة زيارة الى الامارات
                                        <?php else: ?>
                                        Visa to UAE
                                        <?php endif; ?>
                                </li>
                            </ol>
                        </nav>
                        
                    </div>
                </div>
                
                <div class="page-content">
                    <section class="section-md visa ">
                        <div class="container">
                            <div class="service-image">
                                <img src="images/emirates.jpg">
                            </div><!--End service-image-->
                            
                            <div class="row">
                                <div class="col-lg-10">
                                    <div class="section-head">
                                        <h3 class="section-title">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        تاشيرة زيارة الى الامارات
                                        <?php else: ?>
                                        Visa to UAE
                                        <?php endif; ?>
                                        </h3>
                                        <p>
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        يعتمد نوع التأشيرة اللازمة لدخول دولة الإمارات العربية المتحدة على عدة عوامل، مثل: جنسيتك، والغرض من زيارتك المخطط لها، ومدة الزيارة المحدد , منسك الخير تساعدك على تحديد نوع الزيارة المناسبة لك , وتوفر تأشيرة الزيارة بأقل سعر , وارسالها لك فى أى دولة حول العالم , وتوفر الدعم أيضا من خدمات أخري بعد الوصول الى دولة الإمارات العربية المتحدة 
                                        <?php else: ?>
                                        The type of visa required to enter the UAE depends on several factors, such as your nationality, the purpose of your planned visit, the duration of your visit, the good visit to you, and the visit visa to you in any country around the world. , And also provides support from other services after reaching the United Arab Emirates
                                        <?php endif; ?>
                                        </p>
                                    </div><!-- End Section-Head -->
                                </div>
                                <div class="col-lg-8">
                                    <form class="contact-form" method="post" action="">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <h3 class="title-lg">
                                                <?php if(Config::get('app.locale') == 'ar'): ?>
                                        إطلب الان
                                        <?php else: ?>
                                        Apply Now
                                        <?php endif; ?>
                                            </h3>
                                        </div><!-- End form-group -->
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" required name="name" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الاسم <?php else: ?> Name <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" required name="phone" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الهاتف <?php else: ?> Phone <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-4">
                                                <div class="form-group">
                                                    <input type="email" class="form-control" required name="email" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> البريد الالكتروني <?php else: ?> E-mail Address <?php endif; ?>">
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <textarea class="form-control" required name="message" placeholder="<?php if(Config::get('app.locale') == 'ar'): ?> الرسالة <?php else: ?> Message <?php endif; ?>" rows="9"></textarea>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <button class="custom-btn" type="submit">
                                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                                        أرسل
                                                        <?php else: ?>
                                                        Send
                                                        <?php endif; ?>
                                                    </button>
                                                </div><!-- End Form-Group -->
                                            </div><!-- End col -->
                                        </div><!-- End row -->
                                    </form><!-- End contact-form -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                </div><!--End page-content-->    
<?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  