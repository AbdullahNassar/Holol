<?php echo $__env->make('site.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="main">
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            <?php if(Config::get('app.locale') == 'ar'): ?>
                            من نحن
                            <?php else: ?>
                            About Us
                            <?php endif; ?>
                        </h2>
                        <nav aria-label="breadcrumb" role="navigation">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="index.html">
                                        <?php if(Config::get('app.locale') == 'ar'): ?>
                                        الرئيسية
                                        <?php else: ?>
                                        Home
                                        <?php endif; ?>
                                    </a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">
                                   <?php if(Config::get('app.locale') == 'ar'): ?>
                                   من نحن
                                   <?php else: ?>
                                   About Us
                                   <?php endif; ?>  
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div><!--End page head-->
                <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="page-content">
                    <section class="section-md about about-2 pattern-bg">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-7">
                                    <div class="section-head">
                                        <h3 class="section-title has-bg">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($a->main_title); ?>

                                            <?php else: ?>
                                            <?php echo e($a->main_title_en); ?>

                                            <?php endif; ?>  
                                        </h3>
                                    </div><!-- End Section-Head -->
                                    <div class="section-content">
                                        <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($a->main_content); ?>

                                            <?php else: ?>
                                            <?php echo e($a->main_content_en); ?>

                                            <?php endif; ?>  
                                        </p>
                                    </div><!-- End Section-Content -->
                                </div><!-- End col -->
                                <div class="col-lg-5">
                                    <div class="section-img-2">
                                        <div class="img-2-pattern">
                                            <img src="<?php echo e(asset('assets/site/images/about-img-2.jpg')); ?>">
                                        </div><!-- End With-Pattern -->
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <section class="section-md color-bg">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="icon-box">
                                        <div class="icon-box-head">
                                            <img src="<?php echo e(asset('assets/site/images/About.png')); ?>" alt="icon">
                                            <h3 class="title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            رؤيتنا
                                            <?php else: ?>
                                            Our vision
                                            <?php endif; ?> 
                                            </h3>
                                        </div><!-- End Icon-Box-Head -->
                                        <div class="icon-box-content">
                                            <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($a->vision_content); ?>

                                            <?php else: ?>
                                            <?php echo e($a->vision_content_en); ?>

                                            <?php endif; ?>  
                                            </p>
                                        </div><!-- End Icon-Box-Content -->
                                    </div><!-- End Icon-Box -->
                                </div><!-- End col -->
                                <div class="col-lg-6">
                                    <div class="icon-box">
                                        <div class="icon-box-head">
                                            <img src="<?php echo e(asset('assets/site/images/About.png')); ?>" alt="icon">
                                            <h3 class="title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            مهمتنا
                                            <?php else: ?>
                                            Our Mission
                                            <?php endif; ?> 
                                            </h3>
                                        </div><!-- End Icon-Box-Head -->
                                        <div class="icon-box-content">
                                            <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($a->mission_content); ?>

                                            <?php else: ?>
                                            <?php echo e($a->mission_content_en); ?>

                                            <?php endif; ?> 
                                            </p>
                                        </div><!-- End Icon-Box-Content -->
                                    </div><!-- End Icon-Box -->
                                </div><!-- End col -->
                            </div><!-- Endrow -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <section class="section-md call-to-action">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-7">
                                    <div class="section-head">
                                        <h3 class="title">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($a->package_title); ?>

                                            <?php else: ?>
                                            <?php echo e($a->package_title_en); ?>

                                            <?php endif; ?> 
                                        </h3>
                                    </div><!-- End Section-Head -->
                                    <div class="section-content">
                                        <p>
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            <?php echo e($a->package_content); ?>

                                            <?php else: ?>
                                            <?php echo e($a->package_content_en); ?>

                                            <?php endif; ?> 
                                        </p>
                                        <a href="<?php echo e(URL::to('/packages')); ?>" class="custom-btn green-btn">
                                            <?php if(Config::get('app.locale') == 'ar'): ?>
                                            عرض الباقات
                                            <?php else: ?>
                                            View Packages
                                            <?php endif; ?>
                                        </a>
                                    </div><!-- End Section-Content -->
                                </div><!-- End col-->
                                <div class="col-lg-5">
                                    <div class="section-img">
                                    </div><!-- End Section-Img -->
                                </div><!-- End col-->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    
                </div><!--End page-content-->                   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e(csrf_field()); ?>

<?php echo $__env->make('site.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>