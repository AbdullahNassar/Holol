<!DOCTYPE html>
<html>
    <head>
        <!-- Meta Tags
        ========================== -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <!-- Site Title
        ========================== -->
        <title>
        <?php if(Config::get('app.locale') == 'ar'): ?> منسك الخير <?php else: ?> Mansak El Kheir <?php endif; ?>
        </title>
        
        <!-- Favicon
        ===========================-->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/site/images/fav-icon.png')); ?>">

        
        <!-- Base & Vendors
        ========================== -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/bootstrap/css/bootstrap.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/font-awesome/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/vendor/flex-slider2/flexslider.css')); ?>">

        <!-- Site Style
        ========================== -->
        <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/style.css')); ?>">
        
        <?php if(Config::get('app.locale') == 'en'): ?>
            <link rel="stylesheet" href="<?php echo e(asset('assets/site/css/style-en.css')); ?>">
        <?php else: ?>
        <?php endif; ?>
        
        
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div class="wrapper">
            <header class="header">
                <div class="top-header">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-7 d-none d-lg-block">
                                <div class="head-contact">
                                    <ul class="contact-list">
                                        <li>
                                            <span><?php echo e($data->get('phone')); ?></span>
                                            <i class="fa fa-phone"></i>
                                        </li>
                                        <li>
                                            <span><?php echo e($data->get('email')); ?></span>
                                            <i class="fa fa-envelope"></i>
                                        </li>
                                    </ul><!-- End Contact-List --> 
                                </div><!-- End Head-Contact -->
                            </div><!-- End col -->
                            <div class="col-lg-5">
                                <div class="social-lang">
                                    <div class="head-social">
                                        <span>
                                        <?php if(Config::get('app.locale') == 'ar'): ?> تواصل معنا <?php else: ?> Contact Us <?php endif; ?>
                                        </span>
                                        <ul class="social-list">
                                            <li>
                                                <a href="<?php echo e($data->get('facebook')); ?>">
                                                    <i class="fa fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e($data->get('twitter')); ?>">
                                                    <i class="fa fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e($data->get('google')); ?>">
                                                    <i class="fa fa-google-plus"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="<?php echo e($data->get('linkedin')); ?>">
                                                    <i class="fa fa-linkedin"></i>
                                                </a>
                                            </li>
                                        </ul><!-- End Social-List -->
                                    </div><!-- End Head-Social -->
                                    <div class="head-lang">
                            
                                        <?php if(Config::get('app.locale') == 'en'): ?>
                                        <a href="<?php echo e(route('site.lang')); ?>" class="langSwitch custom-btn" data-lang="ar">عربي</a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('site.lang')); ?>" class="langSwitch custom-btn" data-lang="en">english</a>
                                        <?php endif; ?>
                           
                                    <?php echo e(csrf_field()); ?>


                                    </div><!-- End Head-Lang -->
                                </div><!-- End Head-Social -->
                                
                            </div><!-- End col -->
                        </div><!-- End row -->
                    </div><!-- End container -->
                </div><!-- End Top-Header -->
                <div class="container">
                    <a href="index.html" class="logo">
                        <img src="<?php echo e(asset('assets/site/images/logo.png')); ?>">
                    </a>
                    <button class="btn btn-responsive-nav" data-toggle="collapse" data-target="#nav-main">
                        <i class="fa fa-bars"></i>
                    </button>
                </div><!-- End container-->
                <nav class="navbar navbar-expand-lg">
                    <div class="container">
                        <div class="collapse navbar-collapse" id="nav-main">
                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item <?php if(Route::currentRouteName()=='site.home'): ?> active <?php endif; ?>">
                                    <a class="nav-link" href="<?php echo e(URL::to('/')); ?>"><?php echo e(trans('app.home')); ?></a>
                                </li>   
                                <li class="nav-item <?php if(Route::currentRouteName()=='site.about'): ?> active <?php endif; ?>">
                                    <a class="nav-link" href="<?php echo e(URL::to('/about')); ?>"><?php echo e(trans('app.about')); ?></a>
                                </li>
                                <li class="nav-item <?php if(Route::currentRouteName()=='site.packages'): ?> active <?php endif; ?>">
                                    <a class="nav-link" href="<?php echo e(URL::to('/packages')); ?>"><?php echo e(trans('app.packages')); ?></a>
                                </li>
                                <li class="nav-item <?php if(Route::currentRouteName()=='site.services'): ?> active <?php endif; ?>">
                                    <a class="nav-link" href="<?php echo e(URL::to('/services')); ?>"><?php echo e(trans('app.services')); ?></a>
                                </li>
                                <li class="nav-item <?php if(Route::currentRouteName()=='site.visa'): ?> active <?php endif; ?>">
                                    <a class="nav-link" href="<?php echo e(URL::to('/visa')); ?>"><?php echo e(trans('app.visa')); ?></a>
                                </li>
                                <li class="nav-item <?php if(Route::currentRouteName()=='site.contact'): ?> active <?php endif; ?>">
                                    <a class="nav-link" href="<?php echo e(URL::to('/contact')); ?>"><?php echo e(trans('app.contact')); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div><!-- End container -->
                </nav>
            </header><!-- End Header -->
