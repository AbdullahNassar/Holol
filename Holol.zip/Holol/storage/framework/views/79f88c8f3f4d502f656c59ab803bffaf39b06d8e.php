<?php $__env->startSection('title'); ?>
البيانات الثابتة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">البيانات الثابتة</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" method="post" id="">
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-body">
                        <div class="row">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الخدمات</label>
                                    <textarea rows="5" name="services" class="form-control" required><?php echo e($contact->services); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Services</label>
                                    <textarea rows="5" name="services_en" class="form-control" required><?php echo e($contact->services_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الأطباء</label>
                                    <textarea rows="5" name="doctors" class="form-control" required><?php echo e($contact->doctors); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Doctors</label>
                                    <textarea rows="5" name="doctors_en" class="form-control" required><?php echo e($contact->doctors_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>قصص النجاح</label>
                                    <textarea rows="5" name="stories" class="form-control" required><?php echo e($contact->stories); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Stories</label>
                                    <textarea rows="5" name="stories_en" class="form-control" required><?php echo e($contact->stories_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>اتصل بنا</label>
                                    <textarea rows="5" name="contacts" class="form-control" required><?php echo e($contact->contacts); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Contact Us</label>
                                    <textarea rows="5" name="contacts_en" class="form-control" required><?php echo e($contact->contacts_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>اشترك معنا</label>
                                    <textarea rows="5" name="subscribe" class="form-control" required><?php echo e($contact->subscribe); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Subscribe with us</label>
                                    <textarea rows="5" name="subscribe_en" class="form-control" required><?php echo e($contact->subscribe_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الأخبار</label>
                                    <textarea rows="5" name="blog" class="form-control" required><?php echo e($contact->blog); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Blog</label>
                                    <textarea rows="5" name="blog_en" class="form-control" required><?php echo e($contact->blog_en); ?></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-xs-12">
                                <div class="alert alert-success" style="display: none;" role="alert">
                                    تم تحديث البيانات بنجاح
                                </div>

                                <div class="alert alert-danger" style="display: none;" role="alert">

                                </div>
                            </div><!--End Col-->

                        </div><!--End Row-->


                    </div><!--End Form-body-->
                    <div class="form-action">
                        <div class="row">
                            <div class="col-xs-12">
                                <button class="custom-btn" type="submit">حفظ التغييرات</button>
                            </div><!--End Col-->
                        </div><!--End Row-->
                    </div><!--End Form-action-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>