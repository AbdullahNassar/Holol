<header class="main-header">
    <button class="btn btn-responsive-nav" >
        <i class="fa fa-bars"></i>
    </button>
    <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
            
            
            
            
            
        </ul>
    </div><!--End search-head--> 
</header><!--End main-Header-->