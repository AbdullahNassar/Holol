<?php $__env->startSection('content'); ?>
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            خطا 404
                        </h2>
                        <ol class="breadcrumb">
                          <li class="active">لا يوجد محتوى فى هذه الصفحة</li>
                        </ol>
                    </div><!--End Container-->
                </div><!-- End Page-Head -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>