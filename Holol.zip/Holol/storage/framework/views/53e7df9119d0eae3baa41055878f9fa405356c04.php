<?php $__env->startSection('content'); ?>
                <div class="page-head">
                    <div class="container">
                        <h2 class="page-head-title">
                            من نحن
                        </h2>
                        <ol class="breadcrumb">
                          <li><a href="<?php echo e(URL::to('/')); ?>">الرئيسية</a></li>
                          <li class="active">من نحن</li>
                        </ol>
                    </div><!--End Container-->
                </div><!-- End Page-Head -->
                <div class="page-content">
                    <section class="section-md about">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="section-head">
                                        <h3 class="section-title">
                                            من نحن
                                        </h3>
                                        <p>
                                            <?php echo e($data->get('about_content')); ?>

                                        </p>
                                        
                                    </div>
                                </div><!-- End col -->
                                <div class="col-md-5">
                                    <div class="section-img">
                                        <img src="<?php echo e(asset('storage/uploads/static').'/'.$data->get('about_image')); ?>" alt="about">
                                    </div><!-- End Section-Img -->
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->
                    <section class="section-md feature">
                        <div class="container">
                            <div class="section-content">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="icon-box">
                                            <div class="icon-box-head">
                                                <img src="<?php echo e(asset('assets/site/images/icons/mission.png')); ?>" alt="">
                                                
                                            </div><!-- End Icon-Box-Head -->
                                            <div class="icon-box-content">
                                                <h3 class="title">رؤيتنا</h3>
                                                <p>
                                                    <?php echo e($data->get('vision')); ?>

                                                </p>
                                            </div><!-- End Icon-Box-Content -->
                                        </div><!-- End Icon-Box -->
                                    </div><!-- End col -->
                                    <div class="col-md-4">
                                        <div class="icon-box">
                                            <div class="icon-box-head">
                                                <img src="<?php echo e(asset('assets/site/images/icons/target.png')); ?>" alt="">
                                            </div><!-- End Icon-Box-Head -->
                                            <div class="icon-box-content">
                                                <h3 class="title">مهمتنا</h3>
                                                <p>
                                                    <?php echo e($data->get('mission')); ?>

                                                </p>
                                            </div><!-- End Icon-Box-Content -->
                                        </div><!-- End Icon-Box -->
                                    </div><!-- End col -->
                                    <div class="col-md-4">
                                        <div class="icon-box">
                                            <div class="icon-box-head">
                                                <img src="<?php echo e(asset('assets/site/images/icons/target.png')); ?>" alt="">
                                            </div><!-- End Icon-Box-Head -->
                                            <div class="icon-box-content">
                                                <h3 class="title">رسالتنا</h3>
                                                <p>
                                                    <?php echo e($data->get('message')); ?>

                                                </p>
                                            </div><!-- End Icon-Box-Content -->
                                        </div><!-- End Icon-Box -->
                                    </div><!-- End col -->
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section>
                    <section class="section-md team">
                        <div class="container">
                            <div class="section-head center-section-head">
                                <h3 class="section-title">
                                    فريق الشركة
                                </h3>
                            </div><!-- End Section-Head -->
                            <div class="section-content">
                                <div class="row">
                                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 col-sm-6">
                                        <div class="team-member">
                                            <div class="team-member-head">
                                                <img src="<?php echo e(asset('storage/uploads/team').'/'.$team->image); ?>">
                                            </div><!-- End Widget-Head -->
                                            <div class="team-member-content">
                                                <h3 class="title"<?php echo e($team->name); ?></h3>
                                                <span><?php echo e($team->title); ?></span>
                                                <ul class="social-list has-background">
                                                    <li>
                                                        <a href="<?php echo e($team->linkedin); ?>">
                                                            <i class="fa fa-linkedin"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e($team->twitter); ?>">
                                                            <i class="fa fa-twitter"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e($team->facebook); ?>">
                                                            <i class="fa fa-facebook"></i>
                                                        </a>
                                                    </li>
                                                </ul><!-- End Social-List -->
                                            </div><!-- End Widget-Content -->
                                        </div><!-- End Widget -->
                                    </div><!-- End col -->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div><!-- End row -->
                            </div><!-- End Section-Content -->
                        </div><!-- End container -->
                    </section>
                </div><!--End page-content-->    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>