<?php $__env->startSection('title'); ?>
العملاء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">تعديل</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" action="<?php echo e(route('admin.client.edit' , ['id' => $client->id])); ?>" enctype="multipart/form-data" method="post" onsubmit="return false;">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="choose-img">
                                        <input type="hidden" name="s_id" value="<?php echo e($client->id); ?>">
                                        <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                        <input type="hidden" value="client" id="storage" >
                                        <input type="hidden" name="image" value="<?php echo e($client->image); ?>" id="img" required>
                                        <input type="file" name="image" id="image">
                                        <?php if($client->image): ?>
                                        <img src="<?php echo e(asset('storage/uploads/client').'/'.$client->image); ?>"/>
                                        <?php else: ?>
                                        <p>اضغط لتحميل صورة</p>
                                        <?php endif; ?>
                                    </div><!-- End Choose-Img -->
                                    <div class="upload-action"><br>
                                        <button class="upload-btn" type="button" id="upload-btn">
                                            تحميل الصورة
                                        </button>
                                        <div class="progress">
                                            <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                            </div>
                                        </div>

                                        <h3 id="status"></h3>
                                        <p id="loaded_n_total"></p><br>
                                        <h5>التفعيل</h5><br>
                                        <select class="form-control" name="active" required>
                                            <option value="<?php echo e($client->active); ?>"><?php if($client->active == 1): ?>
                                                                                  نعم
                                                                                  <?php elseif($client->active == 0): ?>
                                                                                  لا
                                                                                  <?php endif; ?> 
                                            </option>
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select><br><br><br>
                                    </div><!--End upload-action-->
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                        </div>
                        <div class="form-action">
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="custom-btn addBTN" type="submit">حفظ التغييرات</button>
                                </div><!--End Col-->
                            </div><!--End Row-->
                        </div><!--End Form-action-->
                    </div>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">جدول  العملاء</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <div id="sample_editable_1_wrapper" class="dataTables_wrapper no-footer">
                    <div class="table-scrollable">
                        <table class="table table-striped dataTable no-footer" role="grid">
                            <thead>
                                <tr role="row">
                                    <th> # </th>
                                    <th> الصورة </th>
                                    <th> التفعيل  </th>
                                    <th> تعديل </th>
                                    <th> حذف </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pclients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr role="row" class="even">
                                    <td class="sorting_1"><?php echo e($loop->index + 1); ?> </td>
                                    <td>
                                        <img src="<?php echo e(asset('storage/uploads/client/'. $cl->image)); ?>">
                                    </td>
                                    <td> 
                                        <?php if($cl->active): ?>
                                        نعم
                                        <?php else: ?>
                                        لا
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="custom-btn small green" href="<?php echo e(route('admin.client.edit' , ['id' => $cl->id])); ?>"> تعديل </a>
                                    </td>
                                    <td>
                                        <button type="button" class="delete custom-btn small red btndelet" data-url="<?php echo e(route('admin.client.delete' , ['id' => $cl->id])); ?>"> حذف </button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div><!-- End Box-Item-Content -->
            </div><!-- End Box-Item -->
    </section>
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>