<?php $__env->startSection('content'); ?>
<div class="page-content">
    <section>
        <div class="box-item">
            <div class="box-item-head">
                <h3 class="title">اضافة</h3>
                <i class="fa fa-angle-down"></i>
            </div><!-- End Box-Item-Head -->
            <div class="box-item-content">
                <form class="form" action="<?php echo e(route('admin.post.add')); ?>" enctype="multipart/form-data" method="post" onsubmit="return false;">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="choose-img">
                                        <input type="hidden" value="<?php echo e(route('admin.upload.post')); ?>" id="url" >
                                        <input type="hidden" value="blog" id="storage" >
                                        <input type="hidden" name="image"  id="img" >
                                        <input type="file" name="image" id="image">
                                        <p style="font-size: large;">اضغط لتحميل صورة</p>
                                    </div><!-- End Choose-Img -->
                                    <div class="upload-action"><br>
                                        <button class="upload-btn" type="button" id="upload-btn">
                                            تحميل الصورة
                                        </button>
                                        <div class="progress">
                                            <div id="progressBar" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                            </div>
                                        </div>
                                        <h3 id="status"></h3>
                                        <p id="loaded_n_total"></p>
                                    </div><!--End upload-action-->
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <div class="choose-img">
                                        <input type="hidden" value="<?php echo e(route('admin.upload.icon')); ?>" id="url2" >
                                        <input type="hidden" value="blog" id="storage2" >
                                        <input type="hidden" name="image2" id="img2" >
                                        <input type="file" name="image2" id="image2" required>
                                        <p style="font-size: large;">اضغط لتحميل أيكونة</p>
                                    </div><!-- End Choose-Img -->
                                    <div class="upload-action">
                                        <button class="upload-btn" type="button" id="upload-btn2">
                                            تحميل أيكونة
                                        </button>
                                        <div class="progress">
                                            <div id="progressBar2" value="0" max="100" class="progress-bar" role="progressbar" style="width: 0%;">0%
                                            </div>
                                        </div>
                                        <h3 id="status2"></h3>
                                        <p id="loaded_n_total2"></p><br>

                                        <h5>التفعيل</h5><br>
                                        <select class="form-control" name="active">
                                            <option value="----------"></option>
                                            <option value="1">نعم</option>
                                            <option value="0">لا</option>
                                        </select>
                                        <br>
                                    </div><!--End upload-action-->
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>عنوان المنشور باللغة العربية</label>
                                    <input type="text" class="form-control" name="title_ar">
                                </div><!--End Form-group-->
                            </div><!--End Col-md-6-->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Post Title in English</label>
                                    <input type="text" class="form-control" name="title_en">
                                </div><!--End Form-group-->
                            </div><!--End Col-md-6-->
                            
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>محتوى المنشور باللغة العربية</label>
                                    <textarea class="form-control tiny-editor" rows="10" name="content_ar"></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group en">
                                    <label>Post Content in English</label>
                                    <textarea class="form-control tiny-editor" rows="10" name="content_en"></textarea>
                                </div><!-- End Form-Group -->
                            </div><!-- End col -->
                            <div class="col-md-6">
                                <div class="form-group ar">
                                    <label>الفئة</label>
                                    <div class="tg-item">
                                        <select class="form-control" name="cat_id">
                                            <option value="-------------"></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>">
                                                    <?php echo e($category->cat_name_ar); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div><!-- End Form-Group -->
                            </div>
                        </div>
                        <div class="form-action">
                            <div class="row">
                                <div class="col-xs-12">
                                    <button class="custom-btn addBTN" type="submit">حفظ التغييرات</button>
                                    <a href="<?php echo e(route('admin.posts')); ?>" class="custom-btn" style="margin-right: 20px;">أغلق</a>
                                </div><!--End Col-->
                            </div><!--End Row-->
                        </div><!--End Form-action-->
                    </div>
                </form><!-- End row -->
            </div><!-- End Box-Item-Content -->
        </div><!-- End Box-Item -->
    </section><!--End Section-->
</div><!--End page-content-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>