<?php
return [
	'lang' => 'عربى',
    'home' => 'Home',
    'services' => 'Our Services',
    'doctors' => 'Our Doctors',
    'blog' => 'Blog',
    'about' => 'About Us',
    'gallery' => 'Gallery',
    'contact' => 'Contact Us'
];