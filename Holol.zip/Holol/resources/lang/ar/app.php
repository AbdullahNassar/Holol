<?php
return [
	'lang' => 'English',
    'home' => 'الرئيسية',
    'services' => 'خدماتنا',
    'doctors' => 'أطباؤنا',
    'blog' => 'الأخبار',
    'about' => 'عن العيادة',
    'gallery' => 'معرض الصور',
    'contact' => 'تواصل معنا'
];