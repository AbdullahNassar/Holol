<div class="row">
    <div class="col-md-12">
        <div class="form-group">
            <input type="text" name="list[]"  class="form-control " >
            <button type="button" class="list-btn-add btn btn blue-soft"><li class="fa fa-plus-circle"></li></button>
            <button type="button" class="list-btn-del btn btn red-soft"><li class="fa fa-minus-circle"></li></button>
        </div>
    </div>
</div>