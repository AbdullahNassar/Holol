<script id="loading" type="text/html">
    <div class="overlay">
        <i class="fa fa-refresh fa-spin"></i>
    </div>
</script>




<div id="loadmodel" class="modal fade in" id="ajax" role="dialog" style="display:none; padding-right: 17px;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <img src="{{asset('assets/loading.gif')}}" alt="" class="loading">
                <span> &nbsp;&nbsp;جاري... </span>
            </div>
        </div>
    </div>
</div>