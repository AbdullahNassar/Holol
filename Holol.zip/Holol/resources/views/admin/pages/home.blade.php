@extends('admin.layouts.master')
@section('title')
لوحة التحكم
@endsection
@section('content')
   <section>
                        <div class="box-item">
                            <div class="box-item-head">
                                <h3 class="title">لوحة التحكم</h3>
                                <i class="fa fa-angle-down"></i>
                            </div><!-- End Box-Item-Head -->
                            <div class="box-item-content">
                                
                            </div><!-- End Box-Item-Content -->
                        </div><!-- End Box-Item -->
                    </section><!--End Section-->

                    <div class="page-content">
                    <section class="section-md about about-2 pattern-bg">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12">
                                    <img src="{{asset('assets/site/images/about.png')}}" alt="">
                                </div><!-- End col -->
                            </div><!-- End row -->
                        </div><!-- End container -->
                    </section><!-- End Section -->                    
                </div><!--End page-content-->    

@endsection